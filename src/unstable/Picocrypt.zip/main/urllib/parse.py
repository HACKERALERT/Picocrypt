'Parse (absolute and relative) URLs.\n\nurlparse module is based upon the following RFC specifications.\n\nRFC 3986 (STD66): "Uniform Resource Identifiers" by T. Berners-Lee, R. Fielding\nand L.  Masinter, January 2005.\n\nRFC 2732 : "Format for Literal IPv6 Addresses in URL\'s by R.Hinden, B.Carpenter\nand L.Masinter, December 1999.\n\nRFC 2396:  "Uniform Resource Identifiers (URI)": Generic Syntax by T.\nBerners-Lee, R. Fielding, and L. Masinter, August 1998.\n\nRFC 2368: "The mailto URL scheme", by P.Hoffman , L Masinter, J. Zawinski, July 1998.\n\nRFC 1808: "Relative Uniform Resource Locators", by R. Fielding, UC Irvine, June\n1995.\n\nRFC 1738: "Uniform Resource Locators (URL)" by T. Berners-Lee, L. Masinter, M.\nMcCahill, December 1994\n\nRFC 3986 is considered the current standard and any future changes to\nurlparse module should conform with it.  The urlparse module is\ncurrently not entirely compliant with this RFC due to defacto\nscenarios for parsing, and for backward compatibility purposes, some\nparsing quirks from older RFCs are retained. The testcases in\ntest_urlparse.py provides a good indicator of parsing behavior.\n'
_u='news'
_t='telnet'
_s='wss'
_r='svn+ssh'
_q='svn'
_p='SplitResult'
_o='ParseResult'
_n='DefragResult'
_m=True
_l=b':'
_k=b'%'
_j='sips'
_i='sip'
_h='hdl'
_g='snews'
_f='sftp'
_e='file'
_d='nntp'
_c='+'
_b='//'
_a=';'
_Z='@'
_Y='strict'
_X='ascii'
_W='rtspu'
_V='rtsp'
_U='prospero'
_T='mms'
_S='ftp'
_R=False
_Q='replace'
_P=']'
_O='['
_N='shttp'
_M='https'
_L='wais'
_K='imap'
_J='gopher'
_I=' '
_H='='
_G='utf-8'
_F='?'
_E='http'
_D=':'
_C='#'
_B='/'
_A=None
import re,sys,collections,warnings
__all__=['urlparse','urlunparse','urljoin','urldefrag','urlsplit','urlunsplit','urlencode','parse_qs','parse_qsl','quote','quote_plus','quote_from_bytes','unquote','unquote_plus','unquote_to_bytes',_n,_o,_p,'DefragResultBytes','ParseResultBytes','SplitResultBytes']
uses_relative=['',_S,_E,_J,_d,_K,_L,_e,_M,_N,_T,_U,_V,_W,_f,_q,_r,'ws',_s]
uses_netloc=['',_S,_E,_J,_d,_t,_K,_L,_e,_T,_M,_N,_g,_U,_V,_W,'rsync',_q,_r,_f,'nfs','git','git+ssh','ws',_s]
uses_params=['',_S,_h,_U,_E,_K,_M,_N,_V,_W,_i,_j,_T,_f,'tel']
non_hierarchical=[_J,_h,'mailto',_u,_t,_L,_K,_g,_i,_j]
uses_query=['',_E,_L,_K,_M,_N,_T,_J,_V,_W,_i,_j]
uses_fragment=['',_S,_h,_E,_J,_u,_d,_L,_M,_N,_g,_e,_U]
scheme_chars='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-.'
MAX_CACHE_SIZE=20
_parse_cache={}
def clear_cache():'Clear the parse cache and the quoters cache.';_parse_cache.clear();_safe_quoters.clear()
_implicit_encoding=_X
_implicit_errors=_Y
def _noop(obj):return obj
def _encode_result(obj,encoding=_implicit_encoding,errors=_implicit_errors):return obj.encode(encoding,errors)
def _decode_args(args,encoding=_implicit_encoding,errors=_implicit_errors):return tuple((A.decode(encoding,errors)if A else''for A in args))
def _coerce_args(*A):
	B=isinstance(A[0],str)
	for C in A[1:]:
		if C and isinstance(C,str)!=B:raise TypeError('Cannot mix str and non-str arguments')
	if B:return A+(_noop,)
	return _decode_args(A)+(_encode_result,)
class _ResultMixinStr:
	'Standard approach to encoding parsed results from str to bytes';__slots__=()
	def encode(A,encoding=_X,errors=_Y):return A._encoded_counterpart(*(B.encode(encoding,errors)for B in A))
class _ResultMixinBytes:
	'Standard approach to decoding parsed results from bytes to str';__slots__=()
	def decode(A,encoding=_X,errors=_Y):return A._decoded_counterpart(*(B.decode(encoding,errors)for B in A))
class _NetlocResultMixinBase:
	'Shared methods for the parsed result objects containing a netloc element';__slots__=()
	@property
	def username(self):return self._userinfo[0]
	@property
	def password(self):return self._userinfo[1]
	@property
	def hostname(self):
		A=self._hostinfo[0]
		if not A:return _A
		B='%'if isinstance(A,str)else _k;A,C,D=A.partition(B);return A.lower()+C+D
	@property
	def port(self):
		A=self._hostinfo[1]
		if A is not _A:
			try:A=int(A,10)
			except ValueError:B=f"Port could not be cast to integer value as {A!r}";raise ValueError(B) from _A
			if not 0<=A<=65535:raise ValueError('Port out of range 0-65535')
		return A
class _NetlocResultMixinStr(_NetlocResultMixinBase,_ResultMixinStr):
	__slots__=()
	@property
	def _userinfo(self):
		C=self.netloc;D,E,G=C.rpartition(_Z)
		if E:
			B,F,A=D.partition(_D)
			if not F:A=_A
		else:B=A=_A
		return B,A
	@property
	def _hostinfo(self):
		D=self.netloc;_,_,B=D.rpartition(_Z);_,E,F=B.partition(_O)
		if E:C,_,A=F.partition(_P);_,_,A=A.partition(_D)
		else:C,_,A=B.partition(_D)
		if not A:A=_A
		return C,A
class _NetlocResultMixinBytes(_NetlocResultMixinBase,_ResultMixinBytes):
	__slots__=()
	@property
	def _userinfo(self):
		C=self.netloc;D,E,G=C.rpartition(b'@')
		if E:
			B,F,A=D.partition(_l)
			if not F:A=_A
		else:B=A=_A
		return B,A
	@property
	def _hostinfo(self):
		D=self.netloc;_,_,B=D.rpartition(b'@');_,E,F=B.partition(b'[')
		if E:C,_,A=F.partition(b']');_,_,A=A.partition(_l)
		else:C,_,A=B.partition(_l)
		if not A:A=_A
		return C,A
from collections import namedtuple
_DefragResultBase=namedtuple(_n,'url fragment')
_SplitResultBase=namedtuple(_p,'scheme netloc path query fragment')
_ParseResultBase=namedtuple(_o,'scheme netloc path params query fragment')
_DefragResultBase.__doc__='\nDefragResult(url, fragment)\n\nA 2-tuple that contains the url without fragment identifier and the fragment\nidentifier as a separate argument.\n'
_DefragResultBase.url.__doc__='The URL with no fragment identifier.'
_DefragResultBase.fragment.__doc__='\nFragment identifier separated from URL, that allows indirect identification of a\nsecondary resource by reference to a primary resource and additional identifying\ninformation.\n'
_SplitResultBase.__doc__='\nSplitResult(scheme, netloc, path, query, fragment)\n\nA 5-tuple that contains the different components of a URL. Similar to\nParseResult, but does not split params.\n'
_SplitResultBase.scheme.__doc__='Specifies URL scheme for the request.'
_SplitResultBase.netloc.__doc__='\nNetwork location where the request is made to.\n'
_SplitResultBase.path.__doc__='\nThe hierarchical path, such as the path to a file to download.\n'
_SplitResultBase.query.__doc__="\nThe query component, that contains non-hierarchical data, that along with data\nin path component, identifies a resource in the scope of URI's scheme and\nnetwork location.\n"
_SplitResultBase.fragment.__doc__='\nFragment identifier, that allows indirect identification of a secondary resource\nby reference to a primary resource and additional identifying information.\n'
_ParseResultBase.__doc__='\nParseResult(scheme, netloc, path, params, query, fragment)\n\nA 6-tuple that contains components of a parsed URL.\n'
_ParseResultBase.scheme.__doc__=_SplitResultBase.scheme.__doc__
_ParseResultBase.netloc.__doc__=_SplitResultBase.netloc.__doc__
_ParseResultBase.path.__doc__=_SplitResultBase.path.__doc__
_ParseResultBase.params.__doc__='\nParameters for last path element used to dereference the URI in order to provide\naccess to perform some operation on the resource.\n'
_ParseResultBase.query.__doc__=_SplitResultBase.query.__doc__
_ParseResultBase.fragment.__doc__=_SplitResultBase.fragment.__doc__
ResultBase=_NetlocResultMixinStr
class DefragResult(_DefragResultBase,_ResultMixinStr):
	__slots__=()
	def geturl(A):
		if A.fragment:return A.url+_C+A.fragment
		else:return A.url
class SplitResult(_SplitResultBase,_NetlocResultMixinStr):
	__slots__=()
	def geturl(A):return urlunsplit(A)
class ParseResult(_ParseResultBase,_NetlocResultMixinStr):
	__slots__=()
	def geturl(A):return urlunparse(A)
class DefragResultBytes(_DefragResultBase,_ResultMixinBytes):
	__slots__=()
	def geturl(A):
		if A.fragment:return A.url+b'#'+A.fragment
		else:return A.url
class SplitResultBytes(_SplitResultBase,_NetlocResultMixinBytes):
	__slots__=()
	def geturl(A):return urlunsplit(A)
class ParseResultBytes(_ParseResultBase,_NetlocResultMixinBytes):
	__slots__=()
	def geturl(A):return urlunparse(A)
def _fix_result_transcoding():
	C=(DefragResult,DefragResultBytes),(SplitResult,SplitResultBytes),(ParseResult,ParseResultBytes)
	for (A,B) in C:A._encoded_counterpart=B;B._decoded_counterpart=A
_fix_result_transcoding()
del _fix_result_transcoding
def urlparse(url,scheme='',allow_fragments=_m):
	"Parse a URL into 6 components:\n    <scheme>://<netloc>/<path>;<params>?<query>#<fragment>\n    Return a 6-tuple: (scheme, netloc, path, params, query, fragment).\n    Note that we don't break the components up in smaller bits\n    (e.g. netloc is a single string) and we don't expand % escapes.";B=scheme;A=url;A,B,D=_coerce_args(A,B);E=urlsplit(A,B,allow_fragments);B,F,A,G,H=E
	if B in uses_params and _a in A:A,C=_splitparams(A)
	else:C=''
	I=ParseResult(B,F,A,C,G,H);return D(I)
def _splitparams(url):
	A=url
	if _B in A:
		B=A.find(_a,A.rfind(_B))
		if B<0:return A,''
	else:B=A.find(_a)
	return A[:B],A[B+1:]
def _splitnetloc(url,start=0):
	C=start;A=url;B=len(A)
	for E in '/?#':
		D=A.find(E,C)
		if D>=0:B=min(B,D)
	return A[C:B],A[B:]
def _checknetloc(netloc):
	B=netloc
	if not B or B.isascii():return
	import unicodedata as D;A=B.replace(_Z,'');A=A.replace(_D,'');A=A.replace(_C,'');A=A.replace(_F,'');C=D.normalize('NFKC',A)
	if A==C:return
	for E in '/?#@:':
		if E in C:raise ValueError("netloc '"+B+"' contains invalid "+'characters under NFKC normalization')
def urlsplit(url,scheme='',allow_fragments=_m):
	"Parse a URL into 5 components:\n    <scheme>://<netloc>/<path>?<query>#<fragment>\n    Return a 5-tuple: (scheme, netloc, path, query, fragment).\n    Note that we don't break the components up in smaller bits\n    (e.g. netloc is a single string) and we don't expand % escapes.";N='Invalid IPv6 URL';E=allow_fragments;C=scheme;A=url;A,C,I=_coerce_args(A,C);E=bool(E);J=A,C,E,type(A),type(C);L=_parse_cache.get(J,_A)
	if L:return I(L)
	if len(_parse_cache)>=MAX_CACHE_SIZE:clear_cache()
	B=G=H='';D=A.find(_D)
	if D>0:
		if A[:D]==_E:
			A=A[D+1:]
			if A[:2]==_b:
				B,A=_splitnetloc(A,2)
				if _O in B and _P not in B or _P in B and _O not in B:raise ValueError(N)
			if E and _C in A:A,H=A.split(_C,1)
			if _F in A:A,G=A.split(_F,1)
			_checknetloc(B);F=SplitResult(_E,B,A,G,H);_parse_cache[J]=F;return I(F)
		for M in A[:D]:
			if M not in scheme_chars:break
		else:
			K=A[D+1:]
			if not K or any((A not in'0123456789'for A in K)):C,A=A[:D].lower(),K
	if A[:2]==_b:
		B,A=_splitnetloc(A,2)
		if _O in B and _P not in B or _P in B and _O not in B:raise ValueError(N)
	if E and _C in A:A,H=A.split(_C,1)
	if _F in A:A,G=A.split(_F,1)
	_checknetloc(B);F=SplitResult(C,B,A,G,H);_parse_cache[J]=F;return I(F)
def urlunparse(components):
	'Put a parsed URL back together again.  This may result in a\n    slightly different, but equivalent URL, if the URL that was parsed\n    originally had redundant delimiters, e.g. a ? with an empty query\n    (the draft states that these are equivalent).';C,D,A,B,E,F,G=_coerce_args(*components)
	if B:A='%s;%s'%(A,B)
	return G(urlunsplit((C,D,A,E,F)))
def urlunsplit(components):
	'Combine the elements of a tuple as returned by urlsplit() into a\n    complete URL as a string. The data argument can be any five-item iterable.\n    This may result in a slightly different, but equivalent URL, if the URL that\n    was parsed originally had unnecessary delimiters (for example, a ? with an\n    empty query; the RFC states that these are equivalent).';B,C,A,D,E,F=_coerce_args(*components)
	if C or B and B in uses_netloc and A[:2]!=_b:
		if A and A[:1]!=_B:A=_B+A
		A=_b+(C or'')+A
	if B:A=B+_D+A
	if D:A=A+_F+D
	if E:A=A+_C+E
	return F(A)
def urljoin(base,url,allow_fragments=_m):
	'Join a base URL and a possibly relative URL to form an absolute\n    interpretation of the latter.';U='.';T='..';N=allow_fragments;D=base;B=url
	if not D:return B
	if not B:return D
	D,B,I=_coerce_args(D,B);O,Q,P,R,S,V=urlparse(D,'',N);C,E,A,F,G,K=urlparse(B,O,N)
	if C!=O or C not in uses_relative:return I(B)
	if C in uses_netloc:
		if E:return I(urlunparse((C,E,A,F,G,K)))
		E=Q
	if not A and not F:
		A=P;F=R
		if not G:G=S
		return I(urlunparse((C,E,A,F,G,K)))
	L=P.split(_B)
	if L[-1]!='':del L[-1]
	if A[:1]==_B:H=A.split(_B)
	else:H=L+A.split(_B);H[1:-1]=filter(_A,H[1:-1])
	J=[]
	for M in H:
		if M==T:
			try:J.pop()
			except IndexError:pass
		elif M==U:continue
		else:J.append(M)
	if H[-1]in(U,T):J.append('')
	return I(urlunparse((C,E,_B.join(J)or _B,F,G,K)))
def urldefrag(url):
	'Removes any existing fragment from URL.\n\n    Returns a tuple of the defragmented URL and the fragment.  If\n    the URL contained no fragments, the second element is the\n    empty string.\n    ';A=url;A,D=_coerce_args(A)
	if _C in A:E,F,G,H,I,B=urlparse(A);C=urlunparse((E,F,G,H,I,''))
	else:B='';C=A
	return D(DefragResult(C,B))
_hexdig='0123456789ABCDEFabcdef'
_hextobyte=_A
def unquote_to_bytes(string):
	"unquote_to_bytes('abc%20def') -> b'abc def'.";F=b'';A=string
	if not A:A.split;return F
	if isinstance(A,str):A=A.encode(_G)
	C=A.split(_k)
	if len(C)==1:return A
	E=[C[0]];B=E.append;global _hextobyte
	if _hextobyte is _A:_hextobyte={(A+B).encode():bytes.fromhex(A+B)for A in _hexdig for B in _hexdig}
	for D in C[1:]:
		try:B(_hextobyte[D[:2]]);B(D[2:])
		except KeyError:B(_k);B(D)
	return F.join(E)
_asciire=re.compile('([\x00-\x7f]+)')
def unquote(string,encoding=_G,errors=_Q):
	"Replace %xx escapes by their single-character equivalent. The optional\n    encoding and errors parameters specify how to decode percent-encoded\n    sequences into Unicode characters, as accepted by the bytes.decode()\n    method.\n    By default, percent-encoded sequences are decoded with UTF-8, and invalid\n    sequences are replaced by a placeholder character.\n\n    unquote('abc%20def') -> 'abc def'.\n    ";D=errors;C=encoding;A=string
	if isinstance(A,bytes):raise TypeError('Expected str, got bytes')
	if'%'not in A:A.split;return A
	if C is _A:C=_G
	if D is _A:D=_Q
	B=_asciire.split(A);E=[B[0]];F=E.append
	for G in range(1,len(B),2):F(unquote_to_bytes(B[G]).decode(C,D));F(B[G+1])
	return ''.join(E)
def parse_qs(qs,keep_blank_values=_R,strict_parsing=_R,encoding=_G,errors=_Q,max_num_fields=_A,separator='&'):
	'Parse a query given as a string argument.\n\n        Arguments:\n\n        qs: percent-encoded query string to be parsed\n\n        keep_blank_values: flag indicating whether blank values in\n            percent-encoded queries should be treated as blank strings.\n            A true value indicates that blanks should be retained as\n            blank strings.  The default false value indicates that\n            blank values are to be ignored and treated as if they were\n            not included.\n\n        strict_parsing: flag indicating what to do with parsing errors.\n            If false (the default), errors are silently ignored.\n            If true, errors raise a ValueError exception.\n\n        encoding and errors: specify how to decode percent-encoded sequences\n            into Unicode characters, as accepted by the bytes.decode() method.\n\n        max_num_fields: int. If set, then throws a ValueError if there\n            are more than n fields read by parse_qsl().\n\n        separator: str. The symbol to use for separating the query arguments.\n            Defaults to &.\n\n        Returns a dictionary.\n    ';A={};D=parse_qsl(qs,keep_blank_values,strict_parsing,encoding=encoding,errors=errors,max_num_fields=max_num_fields,separator=separator)
	for (B,C) in D:
		if B in A:A[B].append(C)
		else:A[B]=[C]
	return A
def parse_qsl(qs,keep_blank_values=_R,strict_parsing=_R,encoding=_G,errors=_Q,max_num_fields=_A,separator='&'):
	'Parse a query given as a string argument.\n\n        Arguments:\n\n        qs: percent-encoded query string to be parsed\n\n        keep_blank_values: flag indicating whether blank values in\n            percent-encoded queries should be treated as blank strings.\n            A true value indicates that blanks should be retained as blank\n            strings.  The default false value indicates that blank values\n            are to be ignored and treated as if they were  not included.\n\n        strict_parsing: flag indicating what to do with parsing errors. If\n            false (the default), errors are silently ignored. If true,\n            errors raise a ValueError exception.\n\n        encoding and errors: specify how to decode percent-encoded sequences\n            into Unicode characters, as accepted by the bytes.decode() method.\n\n        max_num_fields: int. If set, then throws a ValueError\n            if there are more than n fields read by parse_qsl().\n\n        separator: str. The symbol to use for separating the query arguments.\n            Defaults to &.\n\n        Returns a list, as G-d intended.\n    ';J=max_num_fields;I=errors;H=encoding;G=strict_parsing;F=keep_blank_values;D=separator;qs,K=_coerce_args(qs)
	if not D or not isinstance(D,(str,bytes)):raise ValueError('Separator must be of type string or bytes.')
	if J is not _A:
		M=1+qs.count(D)
		if J<M:raise ValueError('Max number of fields exceeded')
	N=[A for A in qs.split(D)];L=[]
	for E in N:
		if not E and not G:continue
		A=E.split(_H,1)
		if len(A)!=2:
			if G:raise ValueError('bad query field: %r'%(E,))
			if F:A.append('')
			else:continue
		if len(A[1])or F:B=A[0].replace(_c,_I);B=unquote(B,encoding=H,errors=I);B=K(B);C=A[1].replace(_c,_I);C=unquote(C,encoding=H,errors=I);C=K(C);L.append((B,C))
	return L
def unquote_plus(string,encoding=_G,errors=_Q):"Like unquote(), but also replace plus signs by spaces, as required for\n    unquoting HTML form values.\n\n    unquote_plus('%7e/abc+def') -> '~/abc def'\n    ";A=string;A=A.replace(_c,_I);return unquote(A,encoding,errors)
_ALWAYS_SAFE=frozenset(b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-~')
_ALWAYS_SAFE_BYTES=bytes(_ALWAYS_SAFE)
_safe_quoters={}
class Quoter(collections.defaultdict):
	'A mapping from bytes (in range(0,256)) to strings.\n\n    String values are percent-encoded byte values, unless the key < 128, and\n    in the "safe" set (either the specified safe set, or default set).\n    '
	def __init__(A,safe):'safe: bytes object.';A.safe=_ALWAYS_SAFE.union(safe)
	def __repr__(A):return'<%s %r>'%(A.__class__.__name__,dict(A))
	def __missing__(A,b):B=chr(b)if b in A.safe else '%{:02X}'.format(b);A[b]=B;return B
def quote(string,safe=_B,encoding=_A,errors=_A):
	'quote(\'abc def\') -> \'abc%20def\'\n\n    Each part of a URL, e.g. the path info, the query, etc., has a\n    different set of reserved characters that must be quoted. The\n    quote function offers a cautious (not minimal) way to quote a\n    string for most of these parts.\n\n    RFC 3986 Uniform Resource Identifier (URI): Generic Syntax lists\n    the following (un)reserved characters.\n\n    unreserved    = ALPHA / DIGIT / "-" / "." / "_" / "~"\n    reserved      = gen-delims / sub-delims\n    gen-delims    = ":" / "/" / "?" / "#" / "[" / "]" / "@"\n    sub-delims    = "!" / "$" / "&" / "\'" / "(" / ")"\n                  / "*" / "+" / "," / ";" / "="\n\n    Each of the reserved characters is reserved in some component of a URL,\n    but not necessarily in all of them.\n\n    The quote function %-escapes all characters that are neither in the\n    unreserved chars ("always safe") nor the additional chars set via the\n    safe arg.\n\n    The default for the safe arg is \'/\'. The character is reserved, but in\n    typical usage the quote function is being called on a path where the\n    existing slash characters are to be preserved.\n\n    Python 3.7 updates from using RFC 2396 to RFC 3986 to quote URL strings.\n    Now, "~" is included in the set of unreserved characters.\n\n    string and safe may be either str or bytes objects. encoding and errors\n    must not be specified if string is a bytes object.\n\n    The optional encoding and errors parameters specify how to deal with\n    non-ASCII characters, as accepted by the str.encode method.\n    By default, encoding=\'utf-8\' (characters are encoded with UTF-8), and\n    errors=\'strict\' (unsupported characters raise a UnicodeEncodeError).\n    ';C=errors;B=encoding;A=string
	if isinstance(A,str):
		if not A:return A
		if B is _A:B=_G
		if C is _A:C=_Y
		A=A.encode(B,C)
	else:
		if B is not _A:raise TypeError("quote() doesn't support 'encoding' for bytes")
		if C is not _A:raise TypeError("quote() doesn't support 'errors' for bytes")
	return quote_from_bytes(A,safe)
def quote_plus(string,safe='',encoding=_A,errors=_A):
	"Like quote(), but also replace ' ' with '+', as required for quoting\n    HTML form values. Plus signs in the original string are escaped unless\n    they are included in safe. It also does not have safe default to '/'.\n    ";F=b' ';D=errors;C=encoding;B=safe;A=string
	if isinstance(A,str)and _I not in A or isinstance(A,bytes)and F not in A:return quote(A,B,C,D)
	if isinstance(B,str):E=_I
	else:E=F
	A=quote(A,B+E,C,D);return A.replace(_I,_c)
def quote_from_bytes(bs,safe=_B):
	"Like quote(), but accepts a bytes object rather than a str, and does\n    not perform string-to-bytes encoding.  It always returns an ASCII string.\n    quote_from_bytes(b'abc def?') -> 'abc%20def%3f'\n    ";B=bs;A=safe
	if not isinstance(B,(bytes,bytearray)):raise TypeError('quote_from_bytes() expected bytes')
	if not B:return''
	if isinstance(A,str):A=A.encode(_X,'ignore')
	else:A=bytes([B for B in A if B<128])
	if not B.rstrip(_ALWAYS_SAFE_BYTES+A):return B.decode()
	try:C=_safe_quoters[A]
	except KeyError:_safe_quoters[A]=C=Quoter(A).__getitem__
	return ''.join([C(A)for A in B])
def urlencode(query,doseq=_R,safe='',encoding=_A,errors=_A,quote_via=quote_plus):
	'Encode a dict or sequence of two-element tuples into a URL query string.\n\n    If any values in the query arg are sequences and doseq is true, each\n    sequence element is converted to a separate parameter.\n\n    If the query arg is a sequence of two-element tuples, the order of the\n    parameters in the output will match the order of parameters in the\n    input.\n\n    The components of a query arg may each be either a string or a bytes type.\n\n    The safe, encoding, and errors parameters are passed down to the function\n    specified by quote_via (encoding and errors only if a component is a str).\n    ';G=errors;F=encoding;E=query;D=quote_via;C=safe
	if hasattr(E,'items'):E=E.items()
	else:
		try:
			if len(E)and not isinstance(E[0],tuple):raise TypeError
		except TypeError:K,L,J=sys.exc_info();raise TypeError('not a valid non-string sequence or mapping object').with_traceback(J)
	H=[]
	if not doseq:
		for (B,A) in E:
			if isinstance(B,bytes):B=D(B,C)
			else:B=D(str(B),C,F,G)
			if isinstance(A,bytes):A=D(A,C)
			else:A=D(str(A),C,F,G)
			H.append(B+_H+A)
	else:
		for (B,A) in E:
			if isinstance(B,bytes):B=D(B,C)
			else:B=D(str(B),C,F,G)
			if isinstance(A,bytes):A=D(A,C);H.append(B+_H+A)
			elif isinstance(A,str):A=D(A,C,F,G);H.append(B+_H+A)
			else:
				try:M=len(A)
				except TypeError:A=D(str(A),C,F,G);H.append(B+_H+A)
				else:
					for I in A:
						if isinstance(I,bytes):I=D(I,C)
						else:I=D(str(I),C,F,G)
						H.append(B+_H+I)
	return '&'.join(H)
def to_bytes(url):warnings.warn('urllib.parse.to_bytes() is deprecated as of 3.8',DeprecationWarning,stacklevel=2);return _to_bytes(url)
def _to_bytes(url):
	'to_bytes(u"URL") --> \'URL\'.';A=url
	if isinstance(A,str):
		try:A=A.encode('ASCII').decode()
		except UnicodeError:raise UnicodeError('URL '+repr(A)+' contains non-ASCII characters')
	return A
def unwrap(url):
	"Transform a string like '<URL:scheme://host/path>' into 'scheme://host/path'.\n\n    The string is returned unchanged if it's not a wrapped URL.\n    ";A=url;A=str(A).strip()
	if A[:1]=='<'and A[-1:]=='>':A=A[1:-1].strip()
	if A[:4]=='URL:':A=A[4:].strip()
	return A
def splittype(url):warnings.warn('urllib.parse.splittype() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splittype(url)
_typeprog=_A
def _splittype(url):
	"splittype('type:opaquestring') --> 'type', 'opaquestring'.";global _typeprog
	if _typeprog is _A:_typeprog=re.compile('([^/:]+):(.*)',re.DOTALL)
	A=_typeprog.match(url)
	if A:B,C=A.groups();return B.lower(),C
	return _A,url
def splithost(url):warnings.warn('urllib.parse.splithost() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splithost(url)
_hostprog=_A
def _splithost(url):
	"splithost('//host[:port]/path') --> 'host[:port]', '/path'.";global _hostprog
	if _hostprog is _A:_hostprog=re.compile('//([^/#?]*)(.*)',re.DOTALL)
	B=_hostprog.match(url)
	if B:
		C,A=B.groups()
		if A and A[0]!=_B:A=_B+A
		return C,A
	return _A,url
def splituser(host):warnings.warn('urllib.parse.splituser() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splituser(host)
def _splituser(host):"splituser('user[:passwd]@host[:port]') --> 'user[:passwd]', 'host[:port]'.";A=host;B,C,A=A.rpartition(_Z);return B if C else _A,A
def splitpasswd(user):warnings.warn('urllib.parse.splitpasswd() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splitpasswd(user)
def _splitpasswd(user):"splitpasswd('user:passwd') -> 'user', 'passwd'.";A=user;A,B,C=A.partition(_D);return A,C if B else _A
def splitport(host):warnings.warn('urllib.parse.splitport() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splitport(host)
_portprog=_A
def _splitport(host):
	"splitport('host:port') --> 'host', 'port'.";A=host;global _portprog
	if _portprog is _A:_portprog=re.compile('(.*):([0-9]*)',re.DOTALL)
	B=_portprog.fullmatch(A)
	if B:
		A,C=B.groups()
		if C:return A,C
	return A,_A
def splitnport(host,defport=-1):warnings.warn('urllib.parse.splitnport() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splitnport(host,defport)
def _splitnport(host,defport=-1):
	"Split host and port, returning numeric port.\n    Return given default port if no ':' found; defaults to -1.\n    Return numerical port if a valid number are found after ':'.\n    Return None if ':' but not a valid number.";A=host;A,D,B=A.rpartition(_D)
	if not D:A=B
	elif B:
		try:C=int(B)
		except ValueError:C=_A
		return A,C
	return A,defport
def splitquery(url):warnings.warn('urllib.parse.splitquery() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splitquery(url)
def _splitquery(url):
	"splitquery('/path?query') --> '/path', 'query'.";A,B,C=url.rpartition(_F)
	if B:return A,C
	return url,_A
def splittag(url):warnings.warn('urllib.parse.splittag() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splittag(url)
def _splittag(url):
	"splittag('/path#tag') --> '/path', 'tag'.";A,B,C=url.rpartition(_C)
	if B:return A,C
	return url,_A
def splitattr(url):warnings.warn('urllib.parse.splitattr() is deprecated as of 3.8, use urllib.parse.urlparse() instead',DeprecationWarning,stacklevel=2);return _splitattr(url)
def _splitattr(url):"splitattr('/path;attr1=value1;attr2=value2;...') ->\n        '/path', ['attr1=value1', 'attr2=value2', ...].";A=url.split(_a);return A[0],A[1:]
def splitvalue(attr):warnings.warn('urllib.parse.splitvalue() is deprecated as of 3.8, use urllib.parse.parse_qsl() instead',DeprecationWarning,stacklevel=2);return _splitvalue(attr)
def _splitvalue(attr):"splitvalue('attr=value') --> 'attr', 'value'.";A=attr;A,B,C=A.partition(_H);return A,C if B else _A