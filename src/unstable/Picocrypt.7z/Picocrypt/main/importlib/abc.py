_C='mtime'
_B='find_spec'
_A=None
from .  import _bootstrap,_bootstrap_external,machinery
try:import _frozen_importlib
except ImportError as exc:
	if exc.name!='_frozen_importlib':raise
	_frozen_importlib=_A
try:import _frozen_importlib_external
except ImportError as exc:_frozen_importlib_external=_bootstrap_external
import abc,warnings
def _register(abstract_cls,*D):
	B=abstract_cls
	for A in D:
		B.register(A)
		if _frozen_importlib is not _A:
			try:C=getattr(_frozen_importlib,A.__name__)
			except AttributeError:C=getattr(_frozen_importlib_external,A.__name__)
			B.register(C)
class Finder(metaclass=abc.ABCMeta):
	@abc.abstractmethod
	def find_module(self,fullname,path=_A):0
class MetaPathFinder(Finder):
	def find_module(A,fullname,path):
		warnings.warn('MetaPathFinder.find_module() is deprecated since Python 3.4 in favor of MetaPathFinder.find_spec() (available since 3.4)',DeprecationWarning,stacklevel=2)
		if not hasattr(A,_B):return _A
		B=A.find_spec(fullname,path);return B.loader if B is not _A else _A
	def invalidate_caches(A):0
_register(MetaPathFinder,machinery.BuiltinImporter,machinery.FrozenImporter,machinery.PathFinder,machinery.WindowsRegistryFinder)
class PathEntryFinder(Finder):
	def find_loader(B,fullname):
		warnings.warn('PathEntryFinder.find_loader() is deprecated since Python 3.4 in favor of PathEntryFinder.find_spec() (available since 3.4)',DeprecationWarning,stacklevel=2)
		if not hasattr(B,_B):return _A,[]
		A=B.find_spec(fullname)
		if A is not _A:
			if not A.submodule_search_locations:C=[]
			else:C=A.submodule_search_locations
			return A.loader,C
		else:return _A,[]
	find_module=_bootstrap_external._find_module_shim
	def invalidate_caches(A):0
_register(PathEntryFinder,machinery.FileFinder)
class Loader(metaclass=abc.ABCMeta):
	def create_module(A,spec):return _A
	def load_module(A,fullname):
		if not hasattr(A,'exec_module'):raise ImportError
		return _bootstrap._load_module_shim(A,fullname)
	def module_repr(A,module):raise NotImplementedError
class ResourceLoader(Loader):
	@abc.abstractmethod
	def get_data(self,path):raise OSError
class InspectLoader(Loader):
	def is_package(A,fullname):raise ImportError
	def get_code(A,fullname):
		B=A.get_source(fullname)
		if B is _A:return _A
		return A.source_to_code(B)
	@abc.abstractmethod
	def get_source(self,fullname):raise ImportError
	@staticmethod
	def source_to_code(data,path='<string>'):return compile(data,path,'exec',dont_inherit=True)
	exec_module=_bootstrap_external._LoaderBasics.exec_module;load_module=_bootstrap_external._LoaderBasics.load_module
_register(InspectLoader,machinery.BuiltinImporter,machinery.FrozenImporter)
class ExecutionLoader(InspectLoader):
	@abc.abstractmethod
	def get_filename(self,fullname):raise ImportError
	def get_code(A,fullname):
		C=fullname;B=A.get_source(C)
		if B is _A:return _A
		try:D=A.get_filename(C)
		except ImportError:return A.source_to_code(B)
		else:return A.source_to_code(B,D)
_register(ExecutionLoader,machinery.ExtensionFileLoader)
class FileLoader(_bootstrap_external.FileLoader,ResourceLoader,ExecutionLoader):0
_register(FileLoader,machinery.SourceFileLoader,machinery.SourcelessFileLoader)
class SourceLoader(_bootstrap_external.SourceLoader,ResourceLoader,ExecutionLoader):
	def path_mtime(A,path):
		if A.path_stats.__func__ is SourceLoader.path_stats:raise OSError
		return int(A.path_stats(path)[_C])
	def path_stats(A,path):
		if A.path_mtime.__func__ is SourceLoader.path_mtime:raise OSError
		return{_C:A.path_mtime(path)}
	def set_data(A,path,data):0
_register(SourceLoader,machinery.SourceFileLoader)
class ResourceReader(metaclass=abc.ABCMeta):
	@abc.abstractmethod
	def open_resource(self,resource):raise FileNotFoundError
	@abc.abstractmethod
	def resource_path(self,resource):raise FileNotFoundError
	@abc.abstractmethod
	def is_resource(self,name):raise FileNotFoundError
	@abc.abstractmethod
	def contents(self):return[]
_register(ResourceReader,machinery.SourceFileLoader)