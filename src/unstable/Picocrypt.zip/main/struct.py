__all__=['calcsize','pack','pack_into','unpack','unpack_from','iter_unpack','Struct','error']
from _struct import *
from _struct import _clearcache,__doc__