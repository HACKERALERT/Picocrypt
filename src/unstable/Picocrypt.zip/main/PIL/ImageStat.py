import functools,math,operator
class Stat:
	def __init__(A,image_or_list,mask=None):
		B=image_or_list
		try:
			if mask:A.h=B.histogram(mask)
			else:A.h=B.histogram()
		except AttributeError:A.h=B
		if not isinstance(A.h,list):raise TypeError('first argument must be image or list')
		A.bands=list(range(len(A.h)//256))
	def __getattr__(A,id):
		C='_get'
		if id[:4]==C:raise AttributeError(id)
		B=getattr(A,C+id)();setattr(A,id,B);return B
	def _getextrema(A):
		def C(histogram):
			A=255;B=0
			for C in range(256):
				if histogram[C]:A=min(A,C);B=max(B,C)
			return A,B
		B=[]
		for D in range(0,len(A.h),256):B.append(C(A.h[D:]))
		return B
	def _getcount(A):
		B=[]
		for C in range(0,len(A.h),256):B.append(functools.reduce(operator.add,A.h[C:C+256]))
		return B
	def _getsum(A):
		B=[]
		for E in range(0,len(A.h),256):
			C=0.0
			for D in range(256):C+=D*A.h[E+D]
			B.append(C)
		return B
	def _getsum2(A):
		B=[]
		for E in range(0,len(A.h),256):
			C=0.0
			for D in range(256):C+=D**2*float(A.h[E+D])
			B.append(C)
		return B
	def _getmean(A):
		B=[]
		for C in A.bands:B.append(A.sum[C]/A.count[C])
		return B
	def _getmedian(A):
		C=[]
		for D in A.bands:
			B=0;F=A.count[D]//2;G=D*256
			for E in range(256):
				B=B+A.h[G+E]
				if B>F:break
			C.append(E)
		return C
	def _getrms(A):
		B=[]
		for C in A.bands:B.append(math.sqrt(A.sum2[C]/A.count[C]))
		return B
	def _getvar(A):
		C=[]
		for B in A.bands:D=A.count[B];C.append((A.sum2[B]-A.sum[B]**2.0/D)/D)
		return C
	def _getstddev(A):
		B=[]
		for C in A.bands:B.append(math.sqrt(A.var[C]))
		return B
Global=Stat