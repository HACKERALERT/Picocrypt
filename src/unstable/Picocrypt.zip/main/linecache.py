_A=None
import functools,sys,os,tokenize
__all__=['getline','clearcache','checkcache']
def getline(filename,lineno,module_globals=_A):
	A=lineno;B=getlines(filename,module_globals)
	if 1<=A<=len(B):return B[A-1]
	else:return''
cache={}
def clearcache():global cache;cache={}
def getlines(filename,module_globals=_A):
	A=filename
	if A in cache:
		B=cache[A]
		if len(B)!=1:return cache[A][2]
	try:return updatecache(A,module_globals)
	except MemoryError:clearcache();return[]
def checkcache(filename=_A):
	A=filename
	if A is _A:B=list(cache.keys())
	elif A in cache:B=[A]
	else:return
	for A in B:
		C=cache[A]
		if len(C)==1:continue
		F,D,H,G=C
		if D is _A:continue
		try:E=os.stat(G)
		except OSError:cache.pop(A,_A);continue
		if F!=E.st_size or D!=E.st_mtime:cache.pop(A,_A)
def updatecache(filename,module_globals=_A):
	F='\n';A=filename
	if A in cache:
		if len(cache[A])!=1:cache.pop(A,_A)
	if not A or A.startswith('<')and A.endswith('>'):return[]
	B=A
	try:D=os.stat(B)
	except OSError:
		G=A
		if lazycache(A,module_globals):
			try:E=cache[A][0]()
			except (ImportError,OSError):pass
			else:
				if E is _A:return[]
				cache[A]=len(E),_A,[A+F for A in E.splitlines()],B;return cache[A][2]
		if os.path.isabs(A):return[]
		for H in sys.path:
			try:B=os.path.join(H,G)
			except (TypeError,AttributeError):continue
			try:D=os.stat(B);break
			except OSError:pass
		else:return[]
	try:
		with tokenize.open(B)as I:C=I.readlines()
	except OSError:return[]
	if C and not C[-1].endswith(F):C[-1]+=F
	J,K=D.st_size,D.st_mtime;cache[A]=J,K,C,B;return C
def lazycache(filename,module_globals):
	I='__loader__';H=True;E=False;B=module_globals;A=filename
	if A in cache:
		if len(cache[A])==1:return H
		else:return E
	if not A or A.startswith('<')and A.endswith('>'):return E
	if B and I in B:
		C=B.get('__name__');F=B[I];D=getattr(F,'get_source',_A)
		if C and D:G=functools.partial(D,C);cache[A]=G,;return H
	return E