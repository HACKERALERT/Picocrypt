_F='items'
_E='<%s at %#x>'
_D='func'
_C=False
_B=True
_A=None
from _weakref import getweakrefcount,getweakrefs,ref,proxy,CallableProxyType,ProxyType,ReferenceType,_remove_dead_weakref
from _weakrefset import WeakSet,_IterationGuard
import _collections_abc,sys,itertools
ProxyTypes=ProxyType,CallableProxyType
__all__=['ref','proxy','getweakrefcount','getweakrefs','WeakKeyDictionary','ReferenceType','ProxyType','CallableProxyType','ProxyTypes','WeakValueDictionary','WeakSet','WeakMethod','finalize']
class WeakMethod(ref):
	__slots__='_func_ref','_meth_type','_alive','__weakref__'
	def __new__(E,meth,callback=_A):
		C=callback;B=meth
		try:F=B.__self__;G=B.__func__
		except AttributeError:raise TypeError('argument should be a bound method, not {}'.format(type(B))) from _A
		def D(arg):
			A=H()
			if A._alive:
				A._alive=_C
				if C is not _A:C(A)
		A=ref.__new__(E,F,D);A._func_ref=ref(G,D);A._meth_type=type(B);A._alive=_B;H=ref(A);return A
	def __call__(A):
		B=super().__call__();C=A._func_ref()
		if B is _A or C is _A:return _A
		return A._meth_type(C,B)
	def __eq__(B,other):
		A=other
		if isinstance(A,WeakMethod):
			if not B._alive or not A._alive:return B is A
			return ref.__eq__(B,A)and B._func_ref==A._func_ref
		return _C
	def __ne__(B,other):
		A=other
		if isinstance(A,WeakMethod):
			if not B._alive or not A._alive:return B is not A
			return ref.__ne__(B,A)or B._func_ref!=A._func_ref
		return _B
	__hash__=ref.__hash__
class WeakValueDictionary(_collections_abc.MutableMapping):
	def __init__(A,B=(),**C):
		def D(wr,selfref=ref(A),_atomic_removal=_remove_dead_weakref):
			A=selfref()
			if A is not _A:
				if A._iterating:A._pending_removals.append(wr.key)
				else:_atomic_removal(A.data,wr.key)
		A._remove=D;A._pending_removals=[];A._iterating=set();A.data={};A.update(B,**C)
	def _commit_removals(A):
		B=A._pending_removals;C=A.data
		while B:D=B.pop();_remove_dead_weakref(C,D)
	def __getitem__(A,key):
		if A._pending_removals:A._commit_removals()
		B=A.data[key]()
		if B is _A:raise KeyError(key)
		else:return B
	def __delitem__(A,key):
		if A._pending_removals:A._commit_removals()
		del A.data[key]
	def __len__(A):
		if A._pending_removals:A._commit_removals()
		return len(A.data)
	def __contains__(A,key):
		if A._pending_removals:A._commit_removals()
		try:B=A.data[key]()
		except KeyError:return _C
		return B is not _A
	def __repr__(A):return _E%(A.__class__.__name__,id(A))
	def __setitem__(A,key,value):
		if A._pending_removals:A._commit_removals()
		A.data[key]=KeyedRef(value,A._remove,key)
	def copy(A):
		if A._pending_removals:A._commit_removals()
		B=WeakValueDictionary()
		with _IterationGuard(A):
			for (D,E) in A.data.items():
				C=E()
				if C is not _A:B[D]=C
		return B
	__copy__=copy
	def __deepcopy__(A,memo):
		from copy import deepcopy as D
		if A._pending_removals:A._commit_removals()
		B=A.__class__()
		with _IterationGuard(A):
			for (E,F) in A.data.items():
				C=F()
				if C is not _A:B[D(E,memo)]=C
		return B
	def get(A,key,default=_A):
		B=default
		if A._pending_removals:A._commit_removals()
		try:D=A.data[key]
		except KeyError:return B
		else:
			C=D()
			if C is _A:return B
			else:return C
	def items(A):
		if A._pending_removals:A._commit_removals()
		with _IterationGuard(A):
			for (C,D) in A.data.items():
				B=D()
				if B is not _A:yield(C,B)
	def keys(A):
		if A._pending_removals:A._commit_removals()
		with _IterationGuard(A):
			for (B,C) in A.data.items():
				if C()is not _A:yield B
	__iter__=keys
	def itervaluerefs(A):
		if A._pending_removals:A._commit_removals()
		with _IterationGuard(A):yield from A.data.values()
	def values(A):
		if A._pending_removals:A._commit_removals()
		with _IterationGuard(A):
			for C in A.data.values():
				B=C()
				if B is not _A:yield B
	def popitem(A):
		if A._pending_removals:A._commit_removals()
		while _B:
			C,D=A.data.popitem();B=D()
			if B is not _A:return C,B
	def pop(A,key,*C):
		if A._pending_removals:A._commit_removals()
		try:B=A.data.pop(key)()
		except KeyError:B=_A
		if B is _A:
			if C:return C[0]
			else:raise KeyError(key)
		else:return B
	def setdefault(A,key,default=_A):
		D=default;B=key
		try:C=A.data[B]()
		except KeyError:C=_A
		if C is _A:
			if A._pending_removals:A._commit_removals()
			A.data[B]=KeyedRef(D,A._remove,B);return D
		else:return C
	def update(A,B=_A,**F):
		if A._pending_removals:A._commit_removals()
		E=A.data
		if B is not _A:
			if not hasattr(B,_F):B=dict(B)
			for (C,D) in B.items():E[C]=KeyedRef(D,A._remove,C)
		for (C,D) in F.items():E[C]=KeyedRef(D,A._remove,C)
	def valuerefs(A):
		if A._pending_removals:A._commit_removals()
		return list(A.data.values())
class KeyedRef(ref):
	__slots__='key',
	def __new__(type,ob,callback,key):A=ref.__new__(type,ob,callback);A.key=key;return A
	def __init__(A,ob,callback,key):super().__init__(ob,callback)
class WeakKeyDictionary(_collections_abc.MutableMapping):
	def __init__(A,dict=_A):
		A.data={}
		def B(k,selfref=ref(A)):
			A=selfref()
			if A is not _A:
				if A._iterating:A._pending_removals.append(k)
				else:del A.data[k]
		A._remove=B;A._pending_removals=[];A._iterating=set();A._dirty_len=_C
		if dict is not _A:A.update(dict)
	def _commit_removals(A):
		B=A._pending_removals;C=A.data
		while B:
			try:del C[B.pop()]
			except KeyError:pass
	def _scrub_removals(A):C=A.data;A._pending_removals=[B for B in A._pending_removals if B in C];A._dirty_len=_C
	def __delitem__(A,key):A._dirty_len=_B;del A.data[ref(key)]
	def __getitem__(A,key):return A.data[ref(key)]
	def __len__(A):
		if A._dirty_len and A._pending_removals:A._scrub_removals()
		return len(A.data)-len(A._pending_removals)
	def __repr__(A):return _E%(A.__class__.__name__,id(A))
	def __setitem__(A,key,value):A.data[ref(key,A._remove)]=value
	def copy(A):
		B=WeakKeyDictionary()
		with _IterationGuard(A):
			for (D,E) in A.data.items():
				C=D()
				if C is not _A:B[C]=E
		return B
	__copy__=copy
	def __deepcopy__(A,memo):
		from copy import deepcopy as D;B=A.__class__()
		with _IterationGuard(A):
			for (E,F) in A.data.items():
				C=E()
				if C is not _A:B[C]=D(F,memo)
		return B
	def get(A,key,default=_A):return A.data.get(ref(key),default)
	def __contains__(A,key):
		try:B=ref(key)
		except TypeError:return _C
		return B in A.data
	def items(A):
		with _IterationGuard(A):
			for (C,D) in A.data.items():
				B=C()
				if B is not _A:yield(B,D)
	def keys(A):
		with _IterationGuard(A):
			for C in A.data:
				B=C()
				if B is not _A:yield B
	__iter__=keys
	def values(A):
		with _IterationGuard(A):
			for (B,C) in A.data.items():
				if B()is not _A:yield C
	def keyrefs(A):return list(A.data)
	def popitem(A):
		A._dirty_len=_B
		while _B:
			C,D=A.data.popitem();B=C()
			if B is not _A:return B,D
	def pop(A,key,*B):A._dirty_len=_B;return A.data.pop(ref(key),*B)
	def setdefault(A,key,default=_A):return A.data.setdefault(ref(key,A._remove),default)
	def update(A,dict=_A,**B):
		C=A.data
		if dict is not _A:
			if not hasattr(dict,_F):dict=type({})(dict)
			for (D,E) in dict.items():C[ref(D,A._remove)]=E
		if len(B):A.update(B)
class finalize:
	__slots__=();_registry={};_shutdown=_C;_index_iter=itertools.count();_dirty=_C;_registered_with_atexit=_C
	class _Info:__slots__='weakref',_D,'args','kwargs','atexit','index'
	def __init__(*A,**D):
		J='obj';I='finalize expected at least 2 positional arguments, got %d'
		if len(A)>=3:B,E,G,*A=A
		elif not A:raise TypeError("descriptor '__init__' of 'finalize' object needs an argument")
		else:
			if _D not in D:raise TypeError(I%(len(A)-1))
			G=D.pop(_D)
			if len(A)>=2:B,E,*A=A;import warnings as F;F.warn("Passing 'func' as keyword argument is deprecated",DeprecationWarning,stacklevel=2)
			else:
				if J not in D:raise TypeError(I%(len(A)-1))
				E=D.pop(J);B,*A=A;import warnings as F;F.warn("Passing 'obj' as keyword argument is deprecated",DeprecationWarning,stacklevel=2)
		A=tuple(A)
		if not B._registered_with_atexit:import atexit as H;H.register(B._exitfunc);finalize._registered_with_atexit=_B
		C=B._Info();C.weakref=ref(E,B);C.func=G;C.args=A;C.kwargs=D or _A;C.atexit=_B;C.index=next(B._index_iter);B._registry[B]=C;finalize._dirty=_B
	__init__.__text_signature__='($self, obj, func, /, *args, **kwargs)'
	def __call__(B,_=_A):
		A=B._registry.pop(B,_A)
		if A and not B._shutdown:return A.func(*A.args,**A.kwargs or{})
	def detach(B):
		A=B._registry.get(B);C=A and A.weakref()
		if C is not _A and B._registry.pop(B,_A):return C,A.func,A.args,A.kwargs or{}
	def peek(B):
		A=B._registry.get(B);C=A and A.weakref()
		if C is not _A:return C,A.func,A.args,A.kwargs or{}
	@property
	def alive(self):return self in self._registry
	@property
	def atexit(self):A=self._registry.get(self);return bool(A)and A.atexit
	@atexit.setter
	def atexit(self,value):
		A=self._registry.get(self)
		if A:A.atexit=bool(value)
	def __repr__(A):
		C=A._registry.get(A);B=C and C.weakref()
		if B is _A:return'<%s object at %#x; dead>'%(type(A).__name__,id(A))
		else:return'<%s object at %#x; for %r at %#x>'%(type(A).__name__,id(A),type(B).__name__,id(B))
	@classmethod
	def _select_for_exit(B):A=[(C,A)for(C,A)in B._registry.items()if A.atexit];A.sort(key=lambda item:item[1].index);return[B for(B,C)in A]
	@classmethod
	def _exitfunc(B):
		C=_C
		try:
			if B._registry:
				import gc
				if gc.isenabled():C=_B;gc.disable()
				A=_A
				while _B:
					if A is _A or finalize._dirty:A=B._select_for_exit();finalize._dirty=_C
					if not A:break
					D=A.pop()
					try:D()
					except Exception:sys.excepthook(*sys.exc_info())
					assert D not in B._registry
		finally:
			finalize._shutdown=_B
			if C:gc.enable()