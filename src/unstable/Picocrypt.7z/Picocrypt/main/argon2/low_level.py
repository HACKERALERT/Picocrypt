from __future__ import absolute_import,division,print_function
_B='char[]'
_A='uint8_t[]'
from enum import Enum
from six import PY3
from ._ffi import ffi,lib
from .exceptions import HashingError,VerificationError,VerifyMismatchError
__all__=['ARGON2_VERSION','Type','ffi','hash_secret','hash_secret_raw','verify_secret']
ARGON2_VERSION=lib.ARGON2_VERSION_NUMBER
class Type(Enum):D=lib.Argon2_d;I=lib.Argon2_i;ID=lib.Argon2_id
def hash_secret(secret,salt,time_cost,memory_cost,parallelism,hash_len,type,version=ARGON2_VERSION):
	F=hash_len;E=parallelism;D=memory_cost;C=time_cost;B=secret;A=salt;G=lib.argon2_encodedlen(C,D,E,len(A),F,type.value)+1;H=ffi.new(_B,G);I=lib.argon2_hash(C,D,E,ffi.new(_A,B),len(B),ffi.new(_A,A),len(A),ffi.NULL,F,H,G,type.value,version)
	if I!=lib.ARGON2_OK:raise HashingError(error_to_str(I))
	return ffi.string(H)
def hash_secret_raw(secret,salt,time_cost,memory_cost,parallelism,hash_len,type,version=ARGON2_VERSION):
	B=secret;A=hash_len;C=ffi.new(_A,A);D=lib.argon2_hash(time_cost,memory_cost,parallelism,ffi.new(_A,B),len(B),ffi.new(_A,salt),len(salt),C,A,ffi.NULL,0,type.value,version)
	if D!=lib.ARGON2_OK:raise HashingError(error_to_str(D))
	return bytes(ffi.buffer(C,A))
def verify_secret(hash,secret,type):
	B=secret;A=lib.argon2_verify(ffi.new(_B,hash),ffi.new(_A,B),len(B),type.value)
	if A==lib.ARGON2_OK:return True
	elif A==lib.ARGON2_VERIFY_MISMATCH:raise VerifyMismatchError(error_to_str(A))
	else:raise VerificationError(error_to_str(A))
def core(context,type):return lib.argon2_ctx(context,type)
def error_to_str(error):
	A=ffi.string(lib.argon2_error_message(error))
	if PY3:A=A.decode('ascii')
	return A