import sys,warnings
from .  import _version
__version__=_version.__version__
def _raise_version_warning():warnings.warn('PILLOW_VERSION is deprecated and will be removed in Pillow 9 (2022-01-02). Use __version__ instead.',DeprecationWarning,stacklevel=3)
if sys.version_info>=(3,7):
	def __getattr__(name):
		if name=='PILLOW_VERSION':_raise_version_warning();return __version__
		raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
else:
	class _Deprecated_Version(str):
		def __str__(A):_raise_version_warning();return super().__str__()
		def __getitem__(A,key):_raise_version_warning();return super().__getitem__(key)
		def __eq__(A,other):_raise_version_warning();return super().__eq__(other)
		def __ne__(A,other):_raise_version_warning();return super().__ne__(other)
		def __gt__(A,other):_raise_version_warning();return super().__gt__(other)
		def __lt__(A,other):_raise_version_warning();return super().__lt__(other)
		def __ge__(A,other):_raise_version_warning();return super().__gt__(other)
		def __le__(A,other):_raise_version_warning();return super().__lt__(other)
	PILLOW_VERSION=_Deprecated_Version(__version__)
del _version
_plugins=['BlpImagePlugin','BmpImagePlugin','BufrStubImagePlugin','CurImagePlugin','DcxImagePlugin','DdsImagePlugin','EpsImagePlugin','FitsStubImagePlugin','FliImagePlugin','FpxImagePlugin','FtexImagePlugin','GbrImagePlugin','GifImagePlugin','GribStubImagePlugin','Hdf5StubImagePlugin','IcnsImagePlugin','IcoImagePlugin','ImImagePlugin','ImtImagePlugin','IptcImagePlugin','JpegImagePlugin','Jpeg2KImagePlugin','McIdasImagePlugin','MicImagePlugin','MpegImagePlugin','MpoImagePlugin','MspImagePlugin','PalmImagePlugin','PcdImagePlugin','PcxImagePlugin','PdfImagePlugin','PixarImagePlugin','PngImagePlugin','PpmImagePlugin','PsdImagePlugin','SgiImagePlugin','SpiderImagePlugin','SunImagePlugin','TgaImagePlugin','TiffImagePlugin','WebPImagePlugin','WmfImagePlugin','XbmImagePlugin','XpmImagePlugin','XVThumbImagePlugin']
class UnidentifiedImageError(OSError):0