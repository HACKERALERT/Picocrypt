_A=False
import codecs
class Codec(codecs.Codec):encode=codecs.latin_1_encode;decode=codecs.latin_1_decode
class IncrementalEncoder(codecs.IncrementalEncoder):
	def encode(A,input,final=_A):return codecs.latin_1_encode(input,A.errors)[0]
class IncrementalDecoder(codecs.IncrementalDecoder):
	def decode(A,input,final=_A):return codecs.latin_1_decode(input,A.errors)[0]
class StreamWriter(Codec,codecs.StreamWriter):0
class StreamReader(Codec,codecs.StreamReader):0
class StreamConverter(StreamWriter,StreamReader):encode=codecs.latin_1_decode;decode=codecs.latin_1_encode
def getregentry():return codecs.CodecInfo(name='iso8859-1',encode=Codec.encode,decode=Codec.decode,incrementalencoder=IncrementalEncoder,incrementaldecoder=IncrementalDecoder,streamreader=StreamReader,streamwriter=StreamWriter)