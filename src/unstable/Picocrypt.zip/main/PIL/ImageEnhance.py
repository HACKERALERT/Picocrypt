_A='A'
from .  import Image,ImageFilter,ImageStat
class _Enhance:
	def enhance(A,factor):return Image.blend(A.degenerate,A.image,factor)
class Color(_Enhance):
	def __init__(A,image):
		B=image;A.image=B;A.intermediate_mode='L'
		if _A in B.getbands():A.intermediate_mode='LA'
		A.degenerate=B.convert(A.intermediate_mode).convert(B.mode)
class Contrast(_Enhance):
	def __init__(B,image):
		A=image;B.image=A;C=int(ImageStat.Stat(A.convert('L')).mean[0]+0.5);B.degenerate=Image.new('L',A.size,C).convert(A.mode)
		if _A in A.getbands():B.degenerate.putalpha(A.getchannel(_A))
class Brightness(_Enhance):
	def __init__(B,image):
		A=image;B.image=A;B.degenerate=Image.new(A.mode,A.size,0)
		if _A in A.getbands():B.degenerate.putalpha(A.getchannel(_A))
class Sharpness(_Enhance):
	def __init__(B,image):
		A=image;B.image=A;B.degenerate=A.filter(ImageFilter.SMOOTH)
		if _A in A.getbands():B.degenerate.putalpha(A.getchannel(_A))