_AP='getmode'
_AO='close'
_AN='autosetmode'
_AM='title'
_AL='radio'
_AK='command'
_AJ='raise'
_AI='pages'
_AH='includes'
_AG='entrycget'
_AF='parent'
_AE='chdir'
_AD='insert'
_AC='fancy'
_AB='unbind'
_AA='forget'
_A9='active'
_A8='labelside'
_A7='nearest'
_A6='entryconfigure'
_A5='decr'
_A4='incr'
_A3='image'
_A2='text'
_A1='window'
_A0='help'
_z='listbox'
_y='menu'
_x='menubutton'
_w='exists'
_v='fsbox'
_u='popdown'
_t='popup'
_s='file'
_r='dir'
_q='types'
_p='cross'
_o='tick'
_n='slistbox'
_m='arrow'
_l='orientation'
_k='create'
_j='apply'
_i='size'
_h='dropsite'
_g='dragsite'
_f='hidden'
_e='cget'
_d='row'
_c='item'
_b='filter'
_a='dircbx'
_Z='indicator'
_Y='header'
_X='invoke'
_W='column'
_V='filelist'
_U='ok'
_T='cancel'
_S='add'
_R='tixForm'
_Q='anchor'
_P='-'
_O='clear'
_N='set'
_M='selection'
_L='dirlist'
_K='configure'
_J='tix'
_I='entry'
_H='label'
_G='hlist'
_F='delete'
_E='hsb'
_D='vsb'
_C='info'
_B='options'
_A=None
import os,tkinter
from tkinter import *
from tkinter import _cnfmerge
import _tkinter
WINDOW=_A1
TEXT=_A2
STATUS='status'
IMMEDIATE='immediate'
IMAGE=_A3
IMAGETEXT='imagetext'
BALLOON='balloon'
AUTO='auto'
ACROSSTOP='acrosstop'
ASCII='ascii'
CELL='cell'
COLUMN=_W
DECREASING='decreasing'
INCREASING='increasing'
INTEGER='integer'
MAIN='main'
MAX='max'
REAL='real'
ROW=_d
S_REGION='s-region'
X_REGION='x-region'
Y_REGION='y-region'
TCL_DONT_WAIT=1<<1
TCL_WINDOW_EVENTS=1<<2
TCL_FILE_EVENTS=1<<3
TCL_TIMER_EVENTS=1<<4
TCL_IDLE_EVENTS=1<<5
TCL_ALL_EVENTS=0
class tixCommand:
	def tix_addbitmapdir(self,directory):return self.tk.call(_J,'addbitmapdir',directory)
	def tix_cget(self,option):return self.tk.call(_J,_e,option)
	def tix_configure(self,cnf=_A,**kw):
		if kw:cnf=_cnfmerge((cnf,kw))
		elif cnf:cnf=_cnfmerge(cnf)
		if cnf is _A:return self._getconfigure(_J,_K)
		if isinstance(cnf,str):return self._getconfigure1(_J,_K,_P+cnf)
		return self.tk.call((_J,_K)+self._options(cnf))
	def tix_filedialog(self,dlgclass=_A):
		A='filedialog'
		if dlgclass is not _A:return self.tk.call(_J,A,dlgclass)
		else:return self.tk.call(_J,A)
	def tix_getbitmap(self,name):return self.tk.call(_J,'getbitmap',name)
	def tix_getimage(self,name):return self.tk.call(_J,'getimage',name)
	def tix_option_get(self,name):return self.tk.call(_J,'option','get',name)
	def tix_resetoptions(self,newScheme,newFontSet,newScmPrio=_A):
		A='resetoptions'
		if newScmPrio is not _A:return self.tk.call(_J,A,newScheme,newFontSet,newScmPrio)
		else:return self.tk.call(_J,A,newScheme,newFontSet)
class Tk(tkinter.Tk,tixCommand):
	def __init__(self,screenName=_A,baseName=_A,className='Tix'):
		tkinter.Tk.__init__(self,screenName,baseName,className);tixlib=os.environ.get('TIX_LIBRARY');self.tk.eval('global auto_path; lappend auto_path [file dir [info nameof]]')
		if tixlib is not _A:self.tk.eval('global auto_path; lappend auto_path {%s}'%tixlib);self.tk.eval('global tcl_pkgPath; lappend tcl_pkgPath {%s}'%tixlib)
		self.tk.eval('package require Tix')
	def destroy(self):self.protocol('WM_DELETE_WINDOW','');tkinter.Tk.destroy(self)
class Form:
	def config(self,cnf={},**kw):self.tk.call(_R,self._w,*self._options(cnf,kw))
	form=config
	def __setitem__(self,key,value):Form.form(self,{key:value})
	def check(self):return self.tk.call(_R,'check',self._w)
	def forget(self):self.tk.call(_R,_AA,self._w)
	def grid(self,xsize=0,ysize=0):
		A='grid'
		if not xsize and not ysize:
			x=self.tk.call(_R,A,self._w);y=self.tk.splitlist(x);z=()
			for x in y:z=z+(self.tk.getint(x),)
			return z
		return self.tk.call(_R,A,self._w,xsize,ysize)
	def info(self,option=_A):
		if not option:return self.tk.call(_R,_C,self._w)
		if option[0]!=_P:option=_P+option
		return self.tk.call(_R,_C,self._w,option)
	def slaves(self):return[self._nametowidget(x)for x in self.tk.splitlist(self.tk.call(_R,'slaves',self._w))]
tkinter.Widget.__bases__=tkinter.Widget.__bases__+(Form,)
class TixWidget(tkinter.Widget):
	def __init__(self,master=_A,widgetName=_A,static_options=_A,cnf={},kw={}):
		if kw:cnf=_cnfmerge((cnf,kw))
		else:cnf=_cnfmerge(cnf)
		extra=()
		if static_options:static_options.append(_B)
		else:static_options=[_B]
		for (k,v) in list(cnf.items()):
			if k in static_options:extra=extra+(_P+k,v);del cnf[k]
		self.widgetName=widgetName;Widget._setup(self,master,cnf)
		if widgetName:self.tk.call(widgetName,self._w,*extra)
		if cnf:Widget.config(self,cnf)
		self.subwidget_list={}
	def __getattr__(self,name):
		if name in self.subwidget_list:return self.subwidget_list[name]
		raise AttributeError(name)
	def set_silent(self,value):self.tk.call('tixSetSilent',self._w,value)
	def subwidget(self,name):
		n=self._subwidget_name(name)
		if not n:raise TclError('Subwidget '+name+' not child of '+self._name)
		n=n[len(self._w)+1:];return self._nametowidget(n)
	def subwidgets_all(self):
		names=self._subwidget_names()
		if not names:return[]
		retlist=[]
		for name in names:
			name=name[len(self._w)+1:]
			try:retlist.append(self._nametowidget(name))
			except:pass
		return retlist
	def _subwidget_name(self,name):
		try:return self.tk.call(self._w,'subwidget',name)
		except TclError:return _A
	def _subwidget_names(self):
		try:x=self.tk.call(self._w,'subwidgets','-all');return self.tk.splitlist(x)
		except TclError:return _A
	def config_all(self,option,value):
		if option=='':return
		elif not isinstance(option,str):option=repr(option)
		if not isinstance(value,str):value=repr(value)
		names=self._subwidget_names()
		for name in names:self.tk.call(name,_K,_P+option,value)
	def image_create(self,imgtype,cnf={},master=_A,**kw):
		if not master:master=self
		if kw and cnf:cnf=_cnfmerge((cnf,kw))
		elif kw:cnf=kw
		options=()
		for (k,v) in cnf.items():
			if callable(v):v=self._register(v)
			options=options+(_P+k,v)
		return master.tk.call((_A3,_k,imgtype)+options)
	def image_delete(self,imgname):
		try:self.tk.call(_A3,_F,imgname)
		except TclError:pass
class TixSubWidget(TixWidget):
	def __init__(self,master,name,destroy_physically=1,check_intermediate=1):
		B='name';A='.'
		if check_intermediate:
			path=master._subwidget_name(name)
			try:path=path[len(master._w)+1:];plist=path.split(A)
			except:plist=[]
		if not check_intermediate:TixWidget.__init__(self,master,_A,_A,{B:name})
		else:
			parent=master
			for i in range(len(plist)-1):
				n=A.join(plist[:i+1])
				try:w=master._nametowidget(n);parent=w
				except KeyError:parent=TixSubWidget(parent,plist[i],destroy_physically=0,check_intermediate=0)
			if plist:name=plist[-1]
			TixWidget.__init__(self,parent,_A,_A,{B:name})
		self.destroy_physically=destroy_physically
	def destroy(self):
		for c in list(self.children.values()):c.destroy()
		if self._name in self.master.children:del self.master.children[self._name]
		if self._name in self.master.subwidget_list:del self.master.subwidget_list[self._name]
		if self.destroy_physically:self.tk.call('destroy',self._w)
class DisplayStyle:
	def __init__(self,itemtype,cnf={},*,master=_A,**kw):
		A='refwindow'
		if not master:
			if A in kw:master=kw[A]
			elif A in cnf:master=cnf[A]
			else:master=tkinter._get_default_root('create display style')
		self.tk=master.tk;self.stylename=self.tk.call('tixDisplayStyle',itemtype,*self._options(cnf,kw))
	def __str__(self):return self.stylename
	def _options(self,cnf,kw):
		if kw and cnf:cnf=_cnfmerge((cnf,kw))
		elif kw:cnf=kw
		opts=()
		for (k,v) in cnf.items():opts=opts+(_P+k,v)
		return opts
	def delete(self):self.tk.call(self.stylename,_F)
	def __setitem__(self,key,value):self.tk.call(self.stylename,_K,'-%s'%key,value)
	def config(self,cnf={},**kw):return self._getconfigure(self.stylename,_K,*self._options(cnf,kw))
	def __getitem__(self,key):return self.tk.call(self.stylename,_e,'-%s'%key)
class Balloon(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):A='message';static=[_B,'installcolormap','initwait','statusbar','cursor'];TixWidget.__init__(self,master,'tixBalloon',static,cnf,kw);self.subwidget_list[_H]=_dummyLabel(self,_H,destroy_physically=0);self.subwidget_list[A]=_dummyLabel(self,A,destroy_physically=0)
	def bind_widget(self,widget,cnf={},**kw):self.tk.call(self._w,'bind',widget._w,*self._options(cnf,kw))
	def unbind_widget(self,widget):self.tk.call(self._w,_AB,widget._w)
class ButtonBox(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixButtonBox',[_l,_B],cnf,kw)
	def add(self,name,cnf={},**kw):btn=self.tk.call(self._w,_S,name,*self._options(cnf,kw));self.subwidget_list[name]=_dummyButton(self,name);return btn
	def invoke(self,name):
		if name in self.subwidget_list:self.tk.call(self._w,_X,name)
class ComboBox(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):
		TixWidget.__init__(self,master,'tixComboBox',['editable','dropdown',_AC,_B],cnf,kw);self.subwidget_list[_H]=_dummyLabel(self,_H);self.subwidget_list[_I]=_dummyEntry(self,_I);self.subwidget_list[_m]=_dummyButton(self,_m);self.subwidget_list[_n]=_dummyScrolledListBox(self,_n)
		try:self.subwidget_list[_o]=_dummyButton(self,_o);self.subwidget_list[_p]=_dummyButton(self,_p)
		except TypeError:pass
	def add_history(self,str):self.tk.call(self._w,'addhistory',str)
	def append_history(self,str):self.tk.call(self._w,'appendhistory',str)
	def insert(self,index,str):self.tk.call(self._w,_AD,index,str)
	def pick(self,index):self.tk.call(self._w,'pick',index)
class Control(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixControl',[_B],cnf,kw);self.subwidget_list[_A4]=_dummyButton(self,_A4);self.subwidget_list[_A5]=_dummyButton(self,_A5);self.subwidget_list[_H]=_dummyLabel(self,_H);self.subwidget_list[_I]=_dummyEntry(self,_I)
	def decrement(self):self.tk.call(self._w,_A5)
	def increment(self):self.tk.call(self._w,_A4)
	def invoke(self):self.tk.call(self._w,_X)
	def update(self):self.tk.call(self._w,'update')
class DirList(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixDirList',[_B],cnf,kw);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
	def chdir(self,dir):self.tk.call(self._w,_AE,dir)
class DirTree(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixDirTree',[_B],cnf,kw);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
	def chdir(self,dir):self.tk.call(self._w,_AE,dir)
class DirSelectBox(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixDirSelectBox',[_B],cnf,kw);self.subwidget_list[_L]=_dummyDirList(self,_L);self.subwidget_list[_a]=_dummyFileComboBox(self,_a)
class ExFileSelectBox(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixExFileSelectBox',[_B],cnf,kw);self.subwidget_list[_T]=_dummyButton(self,_T);self.subwidget_list[_U]=_dummyButton(self,_U);self.subwidget_list[_f]=_dummyCheckbutton(self,_f);self.subwidget_list[_q]=_dummyComboBox(self,_q);self.subwidget_list[_r]=_dummyComboBox(self,_r);self.subwidget_list[_L]=_dummyDirList(self,_L);self.subwidget_list[_s]=_dummyComboBox(self,_s);self.subwidget_list[_V]=_dummyScrolledListBox(self,_V)
	def filter(self):self.tk.call(self._w,_b)
	def invoke(self):self.tk.call(self._w,_X)
class DirSelectDialog(TixWidget):
	def __init__(self,master,cnf={},**kw):A='dirbox';TixWidget.__init__(self,master,'tixDirSelectDialog',[_B],cnf,kw);self.subwidget_list[A]=_dummyDirSelectBox(self,A)
	def popup(self):self.tk.call(self._w,_t)
	def popdown(self):self.tk.call(self._w,_u)
class ExFileSelectDialog(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixExFileSelectDialog',[_B],cnf,kw);self.subwidget_list[_v]=_dummyExFileSelectBox(self,_v)
	def popup(self):self.tk.call(self._w,_t)
	def popdown(self):self.tk.call(self._w,_u)
class FileSelectBox(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixFileSelectBox',[_B],cnf,kw);self.subwidget_list[_L]=_dummyScrolledListBox(self,_L);self.subwidget_list[_V]=_dummyScrolledListBox(self,_V);self.subwidget_list[_b]=_dummyComboBox(self,_b);self.subwidget_list[_M]=_dummyComboBox(self,_M)
	def apply_filter(self):self.tk.call(self._w,_b)
	def invoke(self):self.tk.call(self._w,_X)
class FileSelectDialog(TixWidget):
	def __init__(self,master,cnf={},**kw):A='btns';TixWidget.__init__(self,master,'tixFileSelectDialog',[_B],cnf,kw);self.subwidget_list[A]=_dummyStdButtonBox(self,A);self.subwidget_list[_v]=_dummyFileSelectBox(self,_v)
	def popup(self):self.tk.call(self._w,_t)
	def popdown(self):self.tk.call(self._w,_u)
class FileEntry(TixWidget):
	def __init__(self,master,cnf={},**kw):A='button';TixWidget.__init__(self,master,'tixFileEntry',['dialogtype',_B],cnf,kw);self.subwidget_list[A]=_dummyButton(self,A);self.subwidget_list[_I]=_dummyEntry(self,_I)
	def invoke(self):self.tk.call(self._w,_X)
	def file_dialog(self):0
class HList(TixWidget,XView,YView):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixHList',['columns',_B],cnf,kw)
	def add(self,entry,cnf={},**kw):return self.tk.call(self._w,_S,entry,*self._options(cnf,kw))
	def add_child(self,parent=_A,cnf={},**kw):
		if not parent:parent=''
		return self.tk.call(self._w,'addchild',parent,*self._options(cnf,kw))
	def anchor_set(self,entry):self.tk.call(self._w,_Q,_N,entry)
	def anchor_clear(self):self.tk.call(self._w,_Q,_O)
	def column_width(self,col=0,width=_A,chars=_A):
		A='width'
		if not chars:return self.tk.call(self._w,_W,A,col,width)
		else:return self.tk.call(self._w,_W,A,col,'-char',chars)
	def delete_all(self):self.tk.call(self._w,_F,'all')
	def delete_entry(self,entry):self.tk.call(self._w,_F,_I,entry)
	def delete_offsprings(self,entry):self.tk.call(self._w,_F,'offsprings',entry)
	def delete_siblings(self,entry):self.tk.call(self._w,_F,'siblings',entry)
	def dragsite_set(self,index):self.tk.call(self._w,_g,_N,index)
	def dragsite_clear(self):self.tk.call(self._w,_g,_O)
	def dropsite_set(self,index):self.tk.call(self._w,_h,_N,index)
	def dropsite_clear(self):self.tk.call(self._w,_h,_O)
	def header_create(self,col,cnf={},**kw):self.tk.call(self._w,_Y,_k,col,*self._options(cnf,kw))
	def header_configure(self,col,cnf={},**kw):
		if cnf is _A:return self._getconfigure(self._w,_Y,_K,col)
		self.tk.call(self._w,_Y,_K,col,*self._options(cnf,kw))
	def header_cget(self,col,opt):return self.tk.call(self._w,_Y,_e,col,opt)
	def header_exists(self,col):return self.tk.getboolean(self.tk.call(self._w,_Y,'exist',col))
	header_exist=header_exists
	def header_delete(self,col):self.tk.call(self._w,_Y,_F,col)
	def header_size(self,col):return self.tk.call(self._w,_Y,_i,col)
	def hide_entry(self,entry):self.tk.call(self._w,'hide',_I,entry)
	def indicator_create(self,entry,cnf={},**kw):self.tk.call(self._w,_Z,_k,entry,*self._options(cnf,kw))
	def indicator_configure(self,entry,cnf={},**kw):
		if cnf is _A:return self._getconfigure(self._w,_Z,_K,entry)
		self.tk.call(self._w,_Z,_K,entry,*self._options(cnf,kw))
	def indicator_cget(self,entry,opt):return self.tk.call(self._w,_Z,_e,entry,opt)
	def indicator_exists(self,entry):return self.tk.call(self._w,_Z,_w,entry)
	def indicator_delete(self,entry):self.tk.call(self._w,_Z,_F,entry)
	def indicator_size(self,entry):return self.tk.call(self._w,_Z,_i,entry)
	def info_anchor(self):return self.tk.call(self._w,_C,_Q)
	def info_bbox(self,entry):return self._getints(self.tk.call(self._w,_C,'bbox',entry))or _A
	def info_children(self,entry=_A):c=self.tk.call(self._w,_C,'children',entry);return self.tk.splitlist(c)
	def info_data(self,entry):return self.tk.call(self._w,_C,'data',entry)
	def info_dragsite(self):return self.tk.call(self._w,_C,_g)
	def info_dropsite(self):return self.tk.call(self._w,_C,_h)
	def info_exists(self,entry):return self.tk.call(self._w,_C,_w,entry)
	def info_hidden(self,entry):return self.tk.call(self._w,_C,_f,entry)
	def info_next(self,entry):return self.tk.call(self._w,_C,'next',entry)
	def info_parent(self,entry):return self.tk.call(self._w,_C,_AF,entry)
	def info_prev(self,entry):return self.tk.call(self._w,_C,'prev',entry)
	def info_selection(self):c=self.tk.call(self._w,_C,_M);return self.tk.splitlist(c)
	def item_cget(self,entry,col,opt):return self.tk.call(self._w,_c,_e,entry,col,opt)
	def item_configure(self,entry,col,cnf={},**kw):
		if cnf is _A:return self._getconfigure(self._w,_c,_K,entry,col)
		self.tk.call(self._w,_c,_K,entry,col,*self._options(cnf,kw))
	def item_create(self,entry,col,cnf={},**kw):self.tk.call(self._w,_c,_k,entry,col,*self._options(cnf,kw))
	def item_exists(self,entry,col):return self.tk.call(self._w,_c,_w,entry,col)
	def item_delete(self,entry,col):self.tk.call(self._w,_c,_F,entry,col)
	def entrycget(self,entry,opt):return self.tk.call(self._w,_AG,entry,opt)
	def entryconfigure(self,entry,cnf={},**kw):
		if cnf is _A:return self._getconfigure(self._w,_A6,entry)
		self.tk.call(self._w,_A6,entry,*self._options(cnf,kw))
	def nearest(self,y):return self.tk.call(self._w,_A7,y)
	def see(self,entry):self.tk.call(self._w,'see',entry)
	def selection_clear(self,cnf={},**kw):self.tk.call(self._w,_M,_O,*self._options(cnf,kw))
	def selection_includes(self,entry):return self.tk.call(self._w,_M,_AH,entry)
	def selection_set(self,first,last=_A):self.tk.call(self._w,_M,_N,first,last)
	def show_entry(self,entry):return self.tk.call(self._w,'show',_I,entry)
class InputOnly(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixInputOnly',_A,cnf,kw)
class LabelEntry(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixLabelEntry',[_A8,_B],cnf,kw);self.subwidget_list[_H]=_dummyLabel(self,_H);self.subwidget_list[_I]=_dummyEntry(self,_I)
class LabelFrame(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):A='frame';TixWidget.__init__(self,master,'tixLabelFrame',[_A8,_B],cnf,kw);self.subwidget_list[_H]=_dummyLabel(self,_H);self.subwidget_list[A]=_dummyFrame(self,A)
class ListNoteBook(TixWidget):
	def __init__(self,master,cnf={},**kw):B='shlist';A='pane';TixWidget.__init__(self,master,'tixListNoteBook',[_B],cnf,kw);self.subwidget_list[A]=_dummyPanedWindow(self,A,destroy_physically=0);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[B]=_dummyScrolledHList(self,B)
	def add(self,name,cnf={},**kw):self.tk.call(self._w,_S,name,*self._options(cnf,kw));self.subwidget_list[name]=TixSubWidget(self,name);return self.subwidget_list[name]
	def page(self,name):return self.subwidget(name)
	def pages(self):
		names=self.tk.splitlist(self.tk.call(self._w,_AI));ret=[]
		for x in names:ret.append(self.subwidget(x))
		return ret
	def raise_page(self,name):self.tk.call(self._w,_AJ,name)
class Meter(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixMeter',[_B],cnf,kw)
class NoteBook(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):A='nbframe';TixWidget.__init__(self,master,'tixNoteBook',[_B],cnf,kw);self.subwidget_list[A]=TixSubWidget(self,A,destroy_physically=0)
	def add(self,name,cnf={},**kw):self.tk.call(self._w,_S,name,*self._options(cnf,kw));self.subwidget_list[name]=TixSubWidget(self,name);return self.subwidget_list[name]
	def delete(self,name):self.tk.call(self._w,_F,name);self.subwidget_list[name].destroy();del self.subwidget_list[name]
	def page(self,name):return self.subwidget(name)
	def pages(self):
		names=self.tk.splitlist(self.tk.call(self._w,_AI));ret=[]
		for x in names:ret.append(self.subwidget(x))
		return ret
	def raise_page(self,name):self.tk.call(self._w,_AJ,name)
	def raised(self):return self.tk.call(self._w,'raised')
class NoteBookFrame(TixWidget):0
class OptionMenu(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixOptionMenu',[_B],cnf,kw);self.subwidget_list[_x]=_dummyMenubutton(self,_x);self.subwidget_list[_y]=_dummyMenu(self,_y)
	def add_command(self,name,cnf={},**kw):self.tk.call(self._w,_S,_AK,name,*self._options(cnf,kw))
	def add_separator(self,name,cnf={},**kw):self.tk.call(self._w,_S,'separator',name,*self._options(cnf,kw))
	def delete(self,name):self.tk.call(self._w,_F,name)
	def disable(self,name):self.tk.call(self._w,'disable',name)
	def enable(self,name):self.tk.call(self._w,'enable',name)
class PanedWindow(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixPanedWindow',[_l,_B],cnf,kw)
	def add(self,name,cnf={},**kw):self.tk.call(self._w,_S,name,*self._options(cnf,kw));self.subwidget_list[name]=TixSubWidget(self,name,check_intermediate=0);return self.subwidget_list[name]
	def delete(self,name):self.tk.call(self._w,_F,name);self.subwidget_list[name].destroy();del self.subwidget_list[name]
	def forget(self,name):self.tk.call(self._w,_AA,name)
	def panecget(self,entry,opt):return self.tk.call(self._w,'panecget',entry,opt)
	def paneconfigure(self,entry,cnf={},**kw):
		A='paneconfigure'
		if cnf is _A:return self._getconfigure(self._w,A,entry)
		self.tk.call(self._w,A,entry,*self._options(cnf,kw))
	def panes(self):names=self.tk.splitlist(self.tk.call(self._w,'panes'));return[self.subwidget(x)for x in names]
class PopupMenu(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixPopupMenu',[_B],cnf,kw);self.subwidget_list[_x]=_dummyMenubutton(self,_x);self.subwidget_list[_y]=_dummyMenu(self,_y)
	def bind_widget(self,widget):self.tk.call(self._w,'bind',widget._w)
	def unbind_widget(self,widget):self.tk.call(self._w,_AB,widget._w)
	def post_widget(self,widget,x,y):self.tk.call(self._w,'post',widget._w,x,y)
class ResizeHandle(TixWidget):
	def __init__(self,master,cnf={},**kw):flags=[_B,_AK,'cursorfg','cursorbg','handlesize','hintcolor','hintwidth','x','y'];TixWidget.__init__(self,master,'tixResizeHandle',flags,cnf,kw)
	def attach_widget(self,widget):self.tk.call(self._w,'attachwidget',widget._w)
	def detach_widget(self,widget):self.tk.call(self._w,'detachwidget',widget._w)
	def hide(self,widget):self.tk.call(self._w,'hide',widget._w)
	def show(self,widget):self.tk.call(self._w,'show',widget._w)
class ScrolledHList(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixScrolledHList',[_B],cnf,kw);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class ScrolledListBox(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixScrolledListBox',[_B],cnf,kw);self.subwidget_list[_z]=_dummyListbox(self,_z);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class ScrolledText(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixScrolledText',[_B],cnf,kw);self.subwidget_list[_A2]=_dummyText(self,_A2);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class ScrolledTList(TixWidget):
	def __init__(self,master,cnf={},**kw):A='tlist';TixWidget.__init__(self,master,'tixScrolledTList',[_B],cnf,kw);self.subwidget_list[A]=_dummyTList(self,A);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class ScrolledWindow(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixScrolledWindow',[_B],cnf,kw);self.subwidget_list[_A1]=_dummyFrame(self,_A1);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class Select(TixWidget):
	def __init__(self,master,cnf={},**kw):TixWidget.__init__(self,master,'tixSelect',['allowzero',_AL,_l,_A8,_B],cnf,kw);self.subwidget_list[_H]=_dummyLabel(self,_H)
	def add(self,name,cnf={},**kw):self.tk.call(self._w,_S,name,*self._options(cnf,kw));self.subwidget_list[name]=_dummyButton(self,name);return self.subwidget_list[name]
	def invoke(self,name):self.tk.call(self._w,_X,name)
class Shell(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixShell',[_B,_AM],cnf,kw)
class DialogShell(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixDialogShell',[_B,_AM,'mapped','minheight','minwidth',_AF,'transient'],cnf,kw)
	def popdown(self):self.tk.call(self._w,_u)
	def popup(self):self.tk.call(self._w,_t)
	def center(self):self.tk.call(self._w,'center')
class StdButtonBox(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixStdButtonBox',[_l,_B],cnf,kw);self.subwidget_list[_U]=_dummyButton(self,_U);self.subwidget_list[_j]=_dummyButton(self,_j);self.subwidget_list[_T]=_dummyButton(self,_T);self.subwidget_list[_A0]=_dummyButton(self,_A0)
	def invoke(self,name):
		if name in self.subwidget_list:self.tk.call(self._w,_X,name)
class TList(TixWidget,XView,YView):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixTList',[_B],cnf,kw)
	def active_set(self,index):self.tk.call(self._w,_A9,_N,index)
	def active_clear(self):self.tk.call(self._w,_A9,_O)
	def anchor_set(self,index):self.tk.call(self._w,_Q,_N,index)
	def anchor_clear(self):self.tk.call(self._w,_Q,_O)
	def delete(self,from_,to=_A):self.tk.call(self._w,_F,from_,to)
	def dragsite_set(self,index):self.tk.call(self._w,_g,_N,index)
	def dragsite_clear(self):self.tk.call(self._w,_g,_O)
	def dropsite_set(self,index):self.tk.call(self._w,_h,_N,index)
	def dropsite_clear(self):self.tk.call(self._w,_h,_O)
	def insert(self,index,cnf={},**kw):self.tk.call(self._w,_AD,index,*self._options(cnf,kw))
	def info_active(self):return self.tk.call(self._w,_C,_A9)
	def info_anchor(self):return self.tk.call(self._w,_C,_Q)
	def info_down(self,index):return self.tk.call(self._w,_C,'down',index)
	def info_left(self,index):return self.tk.call(self._w,_C,'left',index)
	def info_right(self,index):return self.tk.call(self._w,_C,'right',index)
	def info_selection(self):c=self.tk.call(self._w,_C,_M);return self.tk.splitlist(c)
	def info_size(self):return self.tk.call(self._w,_C,_i)
	def info_up(self,index):return self.tk.call(self._w,_C,'up',index)
	def nearest(self,x,y):return self.tk.call(self._w,_A7,x,y)
	def see(self,index):self.tk.call(self._w,'see',index)
	def selection_clear(self,cnf={},**kw):self.tk.call(self._w,_M,_O,*self._options(cnf,kw))
	def selection_includes(self,index):return self.tk.call(self._w,_M,_AH,index)
	def selection_set(self,first,last=_A):self.tk.call(self._w,_M,_N,first,last)
class Tree(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixTree',[_B],cnf,kw);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
	def autosetmode(self):self.tk.call(self._w,_AN)
	def close(self,entrypath):self.tk.call(self._w,_AO,entrypath)
	def getmode(self,entrypath):return self.tk.call(self._w,_AP,entrypath)
	def open(self,entrypath):self.tk.call(self._w,'open',entrypath)
	def setmode(self,entrypath,mode='none'):self.tk.call(self._w,'setmode',entrypath,mode)
class CheckList(TixWidget):
	def __init__(self,master=_A,cnf={},**kw):TixWidget.__init__(self,master,'tixCheckList',[_B,_AL],cnf,kw);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
	def autosetmode(self):self.tk.call(self._w,_AN)
	def close(self,entrypath):self.tk.call(self._w,_AO,entrypath)
	def getmode(self,entrypath):return self.tk.call(self._w,_AP,entrypath)
	def open(self,entrypath):self.tk.call(self._w,'open',entrypath)
	def getselection(self,mode='on'):return self.tk.splitlist(self.tk.call(self._w,'getselection',mode))
	def getstatus(self,entrypath):return self.tk.call(self._w,'getstatus',entrypath)
	def setstatus(self,entrypath,mode='on'):self.tk.call(self._w,'setstatus',entrypath,mode)
class _dummyButton(Button,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyCheckbutton(Checkbutton,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyEntry(Entry,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyFrame(Frame,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyLabel(Label,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyListbox(Listbox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyMenu(Menu,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyMenubutton(Menubutton,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyScrollbar(Scrollbar,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyText(Text,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyScrolledListBox(ScrolledListBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_z]=_dummyListbox(self,_z);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class _dummyHList(HList,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyScrolledHList(ScrolledHList,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class _dummyTList(TList,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyComboBox(ComboBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):
		TixSubWidget.__init__(self,master,name,[_AC,destroy_physically]);self.subwidget_list[_H]=_dummyLabel(self,_H);self.subwidget_list[_I]=_dummyEntry(self,_I);self.subwidget_list[_m]=_dummyButton(self,_m);self.subwidget_list[_n]=_dummyScrolledListBox(self,_n)
		try:self.subwidget_list[_o]=_dummyButton(self,_o);self.subwidget_list[_p]=_dummyButton(self,_p)
		except TypeError:pass
class _dummyDirList(DirList,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_G]=_dummyHList(self,_G);self.subwidget_list[_D]=_dummyScrollbar(self,_D);self.subwidget_list[_E]=_dummyScrollbar(self,_E)
class _dummyDirSelectBox(DirSelectBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_L]=_dummyDirList(self,_L);self.subwidget_list[_a]=_dummyFileComboBox(self,_a)
class _dummyExFileSelectBox(ExFileSelectBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_T]=_dummyButton(self,_T);self.subwidget_list[_U]=_dummyButton(self,_U);self.subwidget_list[_f]=_dummyCheckbutton(self,_f);self.subwidget_list[_q]=_dummyComboBox(self,_q);self.subwidget_list[_r]=_dummyComboBox(self,_r);self.subwidget_list[_L]=_dummyScrolledListBox(self,_L);self.subwidget_list[_s]=_dummyComboBox(self,_s);self.subwidget_list[_V]=_dummyScrolledListBox(self,_V)
class _dummyFileSelectBox(FileSelectBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_L]=_dummyScrolledListBox(self,_L);self.subwidget_list[_V]=_dummyScrolledListBox(self,_V);self.subwidget_list[_b]=_dummyComboBox(self,_b);self.subwidget_list[_M]=_dummyComboBox(self,_M)
class _dummyFileComboBox(ComboBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_a]=_dummyComboBox(self,_a)
class _dummyStdButtonBox(StdButtonBox,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically);self.subwidget_list[_U]=_dummyButton(self,_U);self.subwidget_list[_j]=_dummyButton(self,_j);self.subwidget_list[_T]=_dummyButton(self,_T);self.subwidget_list[_A0]=_dummyButton(self,_A0)
class _dummyNoteBookFrame(NoteBookFrame,TixSubWidget):
	def __init__(self,master,name,destroy_physically=0):TixSubWidget.__init__(self,master,name,destroy_physically)
class _dummyPanedWindow(PanedWindow,TixSubWidget):
	def __init__(self,master,name,destroy_physically=1):TixSubWidget.__init__(self,master,name,destroy_physically)
def OptionName(widget):return widget.tk.call('tixOptionName',widget._w)
def FileTypeList(dict):
	s=''
	for type in dict.keys():s=s+'{{'+type+'} {'+type+' - '+dict[type]+'}} '
	return s
class CObjView(TixWidget):0
class Grid(TixWidget,XView,YView):
	def __init__(self,master=_A,cnf={},**kw):static=[];self.cnf=cnf;TixWidget.__init__(self,master,'tixGrid',static,cnf,kw)
	def anchor_clear(self):self.tk.call(self,_Q,_O)
	def anchor_get(self):return self._getints(self.tk.call(self,_Q,'get'))
	def anchor_set(self,x,y):self.tk.call(self,_Q,_N,x,y)
	def delete_row(self,from_,to=_A):
		if to is _A:self.tk.call(self,_F,_d,from_)
		else:self.tk.call(self,_F,_d,from_,to)
	def delete_column(self,from_,to=_A):
		if to is _A:self.tk.call(self,_F,_W,from_)
		else:self.tk.call(self,_F,_W,from_,to)
	def edit_apply(self):self.tk.call(self,'edit',_j)
	def edit_set(self,x,y):self.tk.call(self,'edit',_N,x,y)
	def entrycget(self,x,y,option):
		if option and option[0]!=_P:option=_P+option
		return self.tk.call(self,_AG,x,y,option)
	def entryconfigure(self,x,y,cnf=_A,**kw):return self._configure((_A6,x,y),cnf,kw)
	def info_exists(self,x,y):return self._getboolean(self.tk.call(self,_C,_w,x,y))
	def info_bbox(self,x,y):return self.tk.call(self,_C,'bbox',x,y)
	def move_column(self,from_,to,offset):self.tk.call(self,'move',_W,from_,to,offset)
	def move_row(self,from_,to,offset):self.tk.call(self,'move',_d,from_,to,offset)
	def nearest(self,x,y):return self._getints(self.tk.call(self,_A7,x,y))
	def set(self,x,y,itemtype=_A,**kw):
		args=self._options(self.cnf,kw)
		if itemtype is not _A:args=('-itemtype',itemtype)+args
		self.tk.call(self,_N,x,y,*args)
	def size_column(self,index,**kw):return self.tk.splitlist(self.tk.call(self._w,_i,_W,index,*self._options({},kw)))
	def size_row(self,index,**kw):return self.tk.splitlist(self.tk.call(self,_i,_d,index,*self._options({},kw)))
	def unset(self,x,y):self.tk.call(self._w,'unset',x,y)
class ScrolledGrid(Grid):
	def __init__(self,master=_A,cnf={},**kw):static=[];self.cnf=cnf;TixWidget.__init__(self,master,'tixScrolledGrid',static,cnf,kw)