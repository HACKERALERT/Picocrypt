_A=True
def abstractmethod(funcobj):A=funcobj;A.__isabstractmethod__=_A;return A
class abstractclassmethod(classmethod):
	__isabstractmethod__=_A
	def __init__(A,callable):callable.__isabstractmethod__=_A;super().__init__(callable)
class abstractstaticmethod(staticmethod):
	__isabstractmethod__=_A
	def __init__(A,callable):callable.__isabstractmethod__=_A;super().__init__(callable)
class abstractproperty(property):__isabstractmethod__=_A
try:from _abc import get_cache_token,_abc_init,_abc_register,_abc_instancecheck,_abc_subclasscheck,_get_dump,_reset_registry,_reset_caches
except ImportError:from _py_abc import ABCMeta,get_cache_token;ABCMeta.__module__='abc'
else:
	class ABCMeta(type):
		def __new__(B,name,bases,namespace,**C):A=super().__new__(B,name,bases,namespace,**C);_abc_init(A);return A
		def register(A,subclass):return _abc_register(A,subclass)
		def __instancecheck__(A,instance):return _abc_instancecheck(A,instance)
		def __subclasscheck__(A,subclass):return _abc_subclasscheck(A,subclass)
		def _dump_registry(B,file=None):A=file;print(f"Class: {B.__module__}.{B.__qualname__}",file=A);print(f"Inv. counter: {get_cache_token()}",file=A);C,D,E,F=_get_dump(B);print(f"_abc_registry: {C!r}",file=A);print(f"_abc_cache: {D!r}",file=A);print(f"_abc_negative_cache: {E!r}",file=A);print(f"_abc_negative_cache_version: {F!r}",file=A)
		def _abc_registry_clear(A):_reset_registry(A)
		def _abc_caches_clear(A):_reset_caches(A)
class ABC(metaclass=ABCMeta):__slots__=()