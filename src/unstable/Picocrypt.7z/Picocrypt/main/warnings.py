_L='warnings'
_K='lineno must be an int >= 0'
_J='invalid action: %r'
_I=True
_H='once'
_G='module'
_F='error'
_E='always'
_D=False
_C='default'
_B='ignore'
_A=None
import sys
__all__=['warn','warn_explicit','showwarning','formatwarning','filterwarnings','simplefilter','resetwarnings','catch_warnings']
def showwarning(message,category,filename,lineno,file=_A,line=_A):A=WarningMessage(message,category,filename,lineno,file,line);_showwarnmsg_impl(A)
def formatwarning(message,category,filename,lineno,line=_A):A=WarningMessage(message,category,filename,lineno,_A,line);return _formatwarnmsg_impl(A)
def _showwarnmsg_impl(msg):
	A=msg.file
	if A is _A:
		A=sys.stderr
		if A is _A:return
	B=_formatwarnmsg(msg)
	try:A.write(B)
	except OSError:pass
def _formatwarnmsg_impl(msg):
	B=msg;G=B.category.__name__;C=f"{B.filename}:{B.lineno}: {G}: {B.message}\n"
	if B.line is _A:
		try:import linecache as D;A=D.getline(B.filename,B.lineno)
		except Exception:A=_A;D=_A
	else:A=B.line
	if A:A=A.strip();C+='  %s\n'%A
	if B.source is not _A:
		try:import tracemalloc as H
		except Exception:I=_I;E=_A
		else:
			I=H.is_tracing()
			try:E=H.get_object_traceback(B.source)
			except Exception:E=_A
		if E is not _A:
			C+='Object allocated at (most recent call last):\n'
			for F in E:
				C+='  File "%s", lineno %s\n'%(F.filename,F.lineno)
				try:
					if D is not _A:A=D.getline(F.filename,F.lineno)
					else:A=_A
				except Exception:A=_A
				if A:A=A.strip();C+='    %s\n'%A
		elif not I:C+=f"{G}: Enable tracemalloc to get the object allocation traceback\n"
	return C
_showwarning_orig=showwarning
def _showwarnmsg(msg):
	A=msg
	try:B=showwarning
	except NameError:pass
	else:
		if B is not _showwarning_orig:
			if not callable(B):raise TypeError('warnings.showwarning() must be set to a function or method')
			B(A.message,A.category,A.filename,A.lineno,A.file,A.line);return
	_showwarnmsg_impl(A)
_formatwarning_orig=formatwarning
def _formatwarnmsg(msg):
	A=msg
	try:B=formatwarning
	except NameError:pass
	else:
		if B is not _formatwarning_orig:return B(A.message,A.category,A.filename,A.lineno,A.line)
	return _formatwarnmsg_impl(A)
def filterwarnings(action,message='',category=Warning,module='',lineno=0,append=_D):
	E=lineno;D=category;C=action;B=module;A=message;assert C in(_F,_B,_E,_C,_G,_H),_J%(C,);assert isinstance(A,str),'message must be a string';assert isinstance(D,type),'category must be a class';assert issubclass(D,Warning),'category must be a Warning subclass';assert isinstance(B,str),'module must be a string';assert isinstance(E,int)and E>=0,_K
	if A or B:import re
	if A:A=re.compile(A,re.I)
	else:A=_A
	if B:B=re.compile(B)
	else:B=_A
	_add_filter(C,A,D,B,E,append=append)
def simplefilter(action,category=Warning,lineno=0,append=_D):B=lineno;A=action;assert A in(_F,_B,_E,_C,_G,_H),_J%(A,);assert isinstance(B,int)and B>=0,_K;_add_filter(A,_A,category,_A,B,append=append)
def _add_filter(*A,append):
	if not append:
		try:filters.remove(A)
		except ValueError:pass
		filters.insert(0,A)
	elif A not in filters:filters.append(A)
	_filters_mutated()
def resetwarnings():filters[:]=[];_filters_mutated()
class _OptionError(Exception):0
def _processoptions(args):
	for A in args:
		try:_setoption(A)
		except _OptionError as B:print('Invalid -W option ignored:',B,file=sys.stderr)
def _setoption(arg):
	D=arg.split(':')
	if len(D)>5:raise _OptionError('too many fields (max 5): %r'%(arg,))
	while len(D)<5:D.append('')
	E,B,F,C,A=[A.strip()for A in D];E=_getaction(E);F=_getcategory(F)
	if B or C:import re
	if B:B=re.escape(B)
	if C:C=re.escape(C)+'\\Z'
	if A:
		try:
			A=int(A)
			if A<0:raise ValueError
		except (ValueError,OverflowError):raise _OptionError('invalid lineno %r'%(A,)) from _A
	else:A=0
	filterwarnings(E,B,F,C,A)
def _getaction(action):
	A=action
	if not A:return _C
	if A=='all':return _E
	for B in (_C,_E,_B,_G,_H,_F):
		if B.startswith(A):return B
	raise _OptionError(_J%(A,))
def _getcategory(category):
	F='.';A=category
	if not A:return Warning
	if F not in A:import builtins as C;B=A
	else:
		D,G,B=A.rpartition(F)
		try:C=__import__(D,_A,_A,[B])
		except ImportError:raise _OptionError('invalid module name: %r'%(D,)) from _A
	try:E=getattr(C,B)
	except AttributeError:raise _OptionError('unknown warning category: %r'%(A,)) from _A
	if not issubclass(E,Warning):raise _OptionError('invalid warning category: %r'%(A,))
	return E
def _is_internal_frame(frame):A=frame.f_code.co_filename;return'importlib'in A and'_bootstrap'in A
def _next_external_frame(frame):
	A=frame;A=A.f_back
	while A is not _A and _is_internal_frame(A):A=A.f_back
	return A
def warn(message,category=_A,stacklevel=1,source=_A):
	I='__name__';D=stacklevel;C=message;A=category
	if isinstance(C,Warning):A=C.__class__
	if A is _A:A=UserWarning
	if not(isinstance(A,type)and issubclass(A,Warning)):raise TypeError("category must be a Warning subclass, not '{:s}'".format(type(A).__name__))
	try:
		if D<=1 or _is_internal_frame(sys._getframe(1)):B=sys._getframe(D)
		else:
			B=sys._getframe(1)
			for J in range(D-1):
				B=_next_external_frame(B)
				if B is _A:raise ValueError
	except ValueError:globals=sys.__dict__;E='sys';F=1
	else:globals=B.f_globals;E=B.f_code.co_filename;F=B.f_lineno
	if I in globals:G=globals[I]
	else:G='<string>'
	H=globals.setdefault('__warningregistry__',{});warn_explicit(C,A,E,F,G,H,globals,source)
def warn_explicit(message,category,filename,lineno,module=_A,registry=_A,module_globals=_A,source=_A):
	R='version';J=filename;F=lineno;E=module;D=category;B=message;A=registry;F=int(F)
	if E is _A:
		E=J or'<unknown>'
		if E[-3:].lower()=='.py':E=E[:-3]
	if A is _A:A={}
	if A.get(R,0)!=_filters_version:A.clear();A[R]=_filters_version
	if isinstance(B,Warning):G=str(B);D=B.__class__
	else:G=B;B=D(B)
	H=G,D,F
	if A.get(H):return
	for K in filters:
		C,I,P,L,M=K
		if(I is _A or I.match(G))and issubclass(D,P)and(L is _A or L.match(E))and(M==0 or F==M):break
	else:C=defaultaction
	if C==_B:return
	import linecache as Q;Q.getlines(J,module_globals)
	if C==_F:raise B
	if C==_H:
		A[H]=1;N=G,D
		if onceregistry.get(N):return
		onceregistry[N]=1
	elif C==_E:0
	elif C==_G:
		A[H]=1;O=G,D,0
		if A.get(O):return
		A[O]=1
	elif C==_C:A[H]=1
	else:raise RuntimeError('Unrecognized action (%r) in warnings.filters:\n %s'%(C,K))
	I=WarningMessage(B,D,J,F,source);_showwarnmsg(I)
class WarningMessage(object):
	_WARNING_DETAILS='message','category','filename','lineno','file','line','source'
	def __init__(A,message,category,filename,lineno,file=_A,line=_A,source=_A):B=category;A.message=message;A.category=B;A.filename=filename;A.lineno=lineno;A.file=file;A.line=line;A.source=source;A._category_name=B.__name__ if B else _A
	def __str__(A):return'{message : %r, category : %r, filename : %r, lineno : %s, line : %r}'%(A.message,A._category_name,A.filename,A.lineno,A.line)
class catch_warnings(object):
	def __init__(A,*,record=_D,module=_A):B=module;A._record=record;A._module=sys.modules[_L]if B is _A else B;A._entered=_D
	def __repr__(A):
		B=[]
		if A._record:B.append('record=True')
		if A._module is not sys.modules[_L]:B.append('module=%r'%A._module)
		C=type(A).__name__;return'%s(%s)'%(C,', '.join(B))
	def __enter__(A):
		if A._entered:raise RuntimeError('Cannot enter %r twice'%A)
		A._entered=_I;A._filters=A._module.filters;A._module.filters=A._filters[:];A._module._filters_mutated();A._showwarning=A._module.showwarning;A._showwarnmsg_impl=A._module._showwarnmsg_impl
		if A._record:B=[];A._module._showwarnmsg_impl=B.append;A._module.showwarning=A._module._showwarning_orig;return B
		else:return _A
	def __exit__(A,*B):
		if not A._entered:raise RuntimeError('Cannot exit %r without entering first'%A)
		A._module.filters=A._filters;A._module._filters_mutated();A._module.showwarning=A._showwarning;A._module._showwarnmsg_impl=A._showwarnmsg_impl
def _warn_unawaited_coroutine(coro):
	A=coro;B=[f"coroutine '{A.__qualname__}' was never awaited\n"]
	if A.cr_origin is not _A:
		import linecache as D,traceback as C
		def E():
			for (B,C,E) in reversed(A.cr_origin):F=D.getline(B,C);yield(B,C,E,F)
		B.append('Coroutine created at (most recent call last)\n');B+=C.format_list(list(E()))
	F=''.join(B).rstrip('\n');warn(F,category=RuntimeWarning,stacklevel=2,source=A)
try:from _warnings import filters,_defaultaction,_onceregistry,warn,warn_explicit,_filters_mutated;defaultaction=_defaultaction;onceregistry=_onceregistry;_warnings_defaults=_I
except ImportError:
	filters=[];defaultaction=_C;onceregistry={};_filters_version=1
	def _filters_mutated():global _filters_version;_filters_version+=1
	_warnings_defaults=_D
_processoptions(sys.warnoptions)
if not _warnings_defaults:
	if not hasattr(sys,'gettotalrefcount'):filterwarnings(_C,category=DeprecationWarning,module='__main__',append=1);simplefilter(_B,category=DeprecationWarning,append=1);simplefilter(_B,category=PendingDeprecationWarning,append=1);simplefilter(_B,category=ImportWarning,append=1);simplefilter(_B,category=ResourceWarning,append=1)
del _warnings_defaults