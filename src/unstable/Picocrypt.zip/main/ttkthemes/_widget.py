_G='auto_path'
_F='lappend'
_E='[{}]'
_D='gif'
_C='advanced'
_B='png'
_A=1.0
import os
from shutil import copytree,rmtree
from PIL import Image,ImageEnhance
from .  import _utils as utils
from .  import _imgops as imgops
from ._utils import get_file_directory
class ThemedWidget:
	pixmap_themes=['arc'];PACKAGES={};_EXCLUDED={'scid'}
	def __init__(A,tk_interpreter,gif_override=False):A.tk=tk_interpreter;A.png_support=not gif_override;A._load_themes()
	def _load_themes(A):
		with utils.temporary_chdir(utils.get_file_directory()):A._append_theme_dir('themes');A.tk.eval('source themes/pkgIndex.tcl');B=_D if not A.png_support else _B;A._append_theme_dir(B);A.tk.eval('source {}/pkgIndex.tcl'.format(B))
	def _append_theme_dir(A,name):B=_E.format(get_file_directory()+'/'+name);A.tk.call(_F,_G,B)
	def set_theme(A,theme_name):B=theme_name;C=B if B not in A.PACKAGES else A.PACKAGES[B];A.tk.call('package','require','ttk::theme::{}'.format(C));A.tk.call('ttk::setTheme',B)
	def get_themes(A):return list(set(A.tk.call('ttk::themes'))-A._EXCLUDED)
	@property
	def themes(self):return self.get_themes()
	@property
	def current_theme(self):return self.tk.eval('return $ttk::currentTheme')
	def set_theme_advanced(A,theme_name,brightness=_A,saturation=_A,hue=_A,preserve_transparency=True,output_dir=None,advanced_name=_C):
		D=theme_name;C=advanced_name;B=output_dir
		if not A.png_support:raise RuntimeError('PNG-based themes are not supported in the environment')
		if D not in A.pixmap_themes:raise ValueError('Theme is not a valid pixmap theme')
		if D not in A.themes:raise ValueError('Theme to create new theme from is not available: {}'.format(D))
		if C in A.themes:raise RuntimeError('The same name for an advanced theme cannot be used twice')
		B=os.path.join(utils.get_temp_directory(),C)if B is None else B;A._setup_advanced_theme(D,B,C);E=os.path.join(B,C,C);A._setup_images(E,brightness,saturation,hue,preserve_transparency)
		with utils.temporary_chdir(B):A.tk.call(_F,_G,_E.format(B));A.tk.eval('source pkgIndex.tcl');A.set_theme(C)
	def _setup_advanced_theme(P,theme_name,output_dir,advanced_name):
		O='pkgIndex.tcl';N='w';M='r';G=output_dir;C=theme_name;B=advanced_name;F=os.path.join(G,B);H=os.path.join(F,B);K=os.path.join(utils.get_themes_directory(C,P.png_support),C);Q=os.path.join(K,C);L=os.path.join(utils.get_file_directory(),_C)
		for R in [G,F]:utils.create_directory(R)
		S=C+'.tcl';T=os.path.join(K,S);U=os.path.join(F,'{}.tcl'.format(B))
		with open(T,M)as D,open(U,N)as E:
			for A in D:A=A.replace(C,B);A=A.replace('gif89',_B);A=A.replace(_D,_B);E.write(A)
		I=os.path.join(L,O);J=os.path.join(F,O)
		with open(I,M)as D,open(J,N)as E:
			for A in D:E.write(A.replace(_C,B))
		I=os.path.join(L,'pkgIndex_package.tcl');J=os.path.join(G,O)
		with open(I,M)as D,open(J,N)as E:
			for A in D:E.write(A.replace(_C,B))
		if os.path.exists(H):rmtree(H)
		copytree(Q,H)
	@staticmethod
	def _setup_images(directory,brightness,saturation,hue,preserve_transparency):
		F=saturation;E=brightness;B=directory
		for C in os.listdir(B):
			with open(os.path.join(B,C),'rb')as G:A=Image.open(G).convert('RGBA')
			if E!=_A:D=ImageEnhance.Brightness(A);A=D.enhance(E)
			if F!=_A:D=ImageEnhance.Color(A);A=D.enhance(F)
			if hue!=_A:A=imgops.shift_hue(A,hue)
			if preserve_transparency is True:A=imgops.make_transparent(A)
			A.save(os.path.join(B,C.replace(_D,_B)));A.close()
		for C in (A for A in os.listdir(B)if A.endswith('.gif')):os.remove(os.path.join(B,C))