_B='beta'
_A='alpha'
all_feature_names=['nested_scopes','generators','division','absolute_import','with_statement','print_function','unicode_literals','barry_as_FLUFL','generator_stop','annotations']
__all__=['all_feature_names']+all_feature_names
CO_NESTED=16
CO_GENERATOR_ALLOWED=0
CO_FUTURE_DIVISION=131072
CO_FUTURE_ABSOLUTE_IMPORT=262144
CO_FUTURE_WITH_STATEMENT=524288
CO_FUTURE_PRINT_FUNCTION=1048576
CO_FUTURE_UNICODE_LITERALS=2097152
CO_FUTURE_BARRY_AS_BDFL=4194304
CO_FUTURE_GENERATOR_STOP=8388608
CO_FUTURE_ANNOTATIONS=16777216
class _Feature:
	def __init__(A,optionalRelease,mandatoryRelease,compiler_flag):A.optional=optionalRelease;A.mandatory=mandatoryRelease;A.compiler_flag=compiler_flag
	def getOptionalRelease(A):return A.optional
	def getMandatoryRelease(A):return A.mandatory
	def __repr__(A):return'_Feature'+repr((A.optional,A.mandatory,A.compiler_flag))
nested_scopes=_Feature((2,1,0,_B,1),(2,2,0,_A,0),CO_NESTED)
generators=_Feature((2,2,0,_A,1),(2,3,0,'final',0),CO_GENERATOR_ALLOWED)
division=_Feature((2,2,0,_A,2),(3,0,0,_A,0),CO_FUTURE_DIVISION)
absolute_import=_Feature((2,5,0,_A,1),(3,0,0,_A,0),CO_FUTURE_ABSOLUTE_IMPORT)
with_statement=_Feature((2,5,0,_A,1),(2,6,0,_A,0),CO_FUTURE_WITH_STATEMENT)
print_function=_Feature((2,6,0,_A,2),(3,0,0,_A,0),CO_FUTURE_PRINT_FUNCTION)
unicode_literals=_Feature((2,6,0,_A,2),(3,0,0,_A,0),CO_FUTURE_UNICODE_LITERALS)
barry_as_FLUFL=_Feature((3,1,0,_A,2),(4,0,0,_A,0),CO_FUTURE_BARRY_AS_BDFL)
generator_stop=_Feature((3,5,0,_B,1),(3,7,0,_A,0),CO_FUTURE_GENERATOR_STOP)
annotations=_Feature((3,7,0,_B,1),(3,10,0,_A,0),CO_FUTURE_ANNOTATIONS)