_B=b'\x00'
_A=None
from binascii import unhexlify
from Crypto.Cipher import ChaCha20
from Crypto.Cipher.ChaCha20 import _HChaCha20
from Crypto.Hash import Poly1305,BLAKE2s
from Crypto.Random import get_random_bytes
from Crypto.Util.number import long_to_bytes
from Crypto.Util.py3compat import _copy_bytes,bord
from Crypto.Util._raw_api import is_buffer
def _enum(**A):return type('Enum',(),A)
_CipherStatus=_enum(PROCESSING_AUTH_DATA=1,PROCESSING_CIPHERTEXT=2,PROCESSING_DONE=3)
class ChaCha20Poly1305Cipher:
	def __init__(A,key,nonce):B=nonce;A.nonce=_copy_bytes(_A,_A,B);A._next=A.update,A.encrypt,A.decrypt,A.digest,A.verify;A._authenticator=Poly1305.new(key=key,nonce=B,cipher=ChaCha20);A._cipher=ChaCha20.new(key=key,nonce=B);A._cipher.seek(64);A._len_aad=0;A._len_ct=0;A._mac_tag=_A;A._status=_CipherStatus.PROCESSING_AUTH_DATA
	def update(A,data):
		if A.update not in A._next:raise TypeError('update() method cannot be called')
		A._len_aad+=len(data);A._authenticator.update(data)
	def _pad_aad(A):
		assert A._status==_CipherStatus.PROCESSING_AUTH_DATA
		if A._len_aad&15:A._authenticator.update(_B*(16-(A._len_aad&15)))
		A._status=_CipherStatus.PROCESSING_CIPHERTEXT
	def encrypt(A,plaintext,output=_A):
		C=plaintext;B=output
		if A.encrypt not in A._next:raise TypeError('encrypt() method cannot be called')
		if A._status==_CipherStatus.PROCESSING_AUTH_DATA:A._pad_aad()
		A._next=A.encrypt,A.digest;D=A._cipher.encrypt(C,output=B);A._len_ct+=len(C)
		if B is _A:A._authenticator.update(D)
		else:A._authenticator.update(B)
		return D
	def decrypt(A,ciphertext,output=_A):
		B=ciphertext
		if A.decrypt not in A._next:raise TypeError('decrypt() method cannot be called')
		if A._status==_CipherStatus.PROCESSING_AUTH_DATA:A._pad_aad()
		A._next=A.decrypt,A.verify;A._len_ct+=len(B);A._authenticator.update(B);return A._cipher.decrypt(B,output=output)
	def _compute_mac(A):
		if A._mac_tag:assert A._status==_CipherStatus.PROCESSING_DONE;return A._mac_tag
		assert A._status!=_CipherStatus.PROCESSING_DONE
		if A._status==_CipherStatus.PROCESSING_AUTH_DATA:A._pad_aad()
		if A._len_ct&15:A._authenticator.update(_B*(16-(A._len_ct&15)))
		A._status=_CipherStatus.PROCESSING_DONE;A._authenticator.update(long_to_bytes(A._len_aad,8)[::-1]);A._authenticator.update(long_to_bytes(A._len_ct,8)[::-1]);A._mac_tag=A._authenticator.digest();return A._mac_tag
	def digest(A):
		if A.digest not in A._next:raise TypeError('digest() method cannot be called')
		A._next=A.digest,;return A._compute_mac()
	def hexdigest(A):return ''.join(['%02x'%bord(B)for B in A.digest()])
	def verify(A,received_mac_tag):
		if A.verify not in A._next:raise TypeError('verify() cannot be called when encrypting a message')
		A._next=A.verify,;B=get_random_bytes(16);A._compute_mac();C=BLAKE2s.new(digest_bits=160,key=B,data=A._mac_tag);D=BLAKE2s.new(digest_bits=160,key=B,data=received_mac_tag)
		if C.digest()!=D.digest():raise ValueError('MAC check failed')
	def hexverify(A,hex_mac_tag):A.verify(unhexlify(hex_mac_tag))
	def encrypt_and_digest(A,plaintext):return A.encrypt(plaintext),A.digest()
	def decrypt_and_verify(A,ciphertext,received_mac_tag):B=A.decrypt(ciphertext);A.verify(received_mac_tag);return B
def new(**B):
	try:C=B.pop('key')
	except KeyError as D:raise TypeError('Missing parameter %s'%D);self._len_ct+=len(plaintext)
	if len(C)!=32:raise ValueError('Key must be 32 bytes long')
	A=B.pop('nonce',_A)
	if A is _A:A=get_random_bytes(12)
	if len(A)in(8,12):0
	elif len(A)==24:C=_HChaCha20(C,A[:16]);A=b'\x00\x00\x00\x00'+A[16:]
	else:raise ValueError('Nonce must be 8, 12 or 24 bytes long')
	if not is_buffer(A):raise TypeError('nonce must be bytes, bytearray or memoryview')
	if B:raise TypeError('Unknown parameters: '+str(B))
	return ChaCha20Poly1305Cipher(C,A)
key_size=32