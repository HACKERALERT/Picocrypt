_F='cannot release un-acquired lock'
_E='ExceptHookArgs'
_D='Thread.__init__() not called'
_C=False
_B=True
_A=None
import os as _os,sys as _sys,_thread
from time import monotonic as _time
from _weakrefset import WeakSet
from itertools import islice as _islice,count as _count
try:from _collections import deque as _deque
except ImportError:from collections import deque as _deque
__all__=['get_ident','active_count','Condition','current_thread','enumerate','main_thread','TIMEOUT_MAX','Event','Lock','RLock','Semaphore','BoundedSemaphore','Thread','Barrier','BrokenBarrierError','Timer','ThreadError','setprofile','settrace','local','stack_size','excepthook',_E]
_start_new_thread=_thread.start_new_thread
_allocate_lock=_thread.allocate_lock
_set_sentinel=_thread._set_sentinel
get_ident=_thread.get_ident
try:get_native_id=_thread.get_native_id;_HAVE_THREAD_NATIVE_ID=_B;__all__.append('get_native_id')
except AttributeError:_HAVE_THREAD_NATIVE_ID=_C
ThreadError=_thread.error
try:_CRLock=_thread.RLock
except AttributeError:_CRLock=_A
TIMEOUT_MAX=_thread.TIMEOUT_MAX
del _thread
_profile_hook=_A
_trace_hook=_A
def setprofile(func):global _profile_hook;_profile_hook=func
def settrace(func):global _trace_hook;_trace_hook=func
Lock=_allocate_lock
def RLock(*A,**B):
	if _CRLock is _A:return _PyRLock(*A,**B)
	return _CRLock(*A,**B)
class _RLock:
	def __init__(A):A._block=_allocate_lock();A._owner=_A;A._count=0
	def __repr__(A):
		B=A._owner
		try:B=_active[B].name
		except KeyError:pass
		return'<%s %s.%s object owner=%r count=%d at %s>'%('locked'if A._block.locked()else'unlocked',A.__class__.__module__,A.__class__.__qualname__,B,A._count,hex(id(A)))
	def acquire(A,blocking=_B,timeout=-1):
		B=get_ident()
		if A._owner==B:A._count+=1;return 1
		C=A._block.acquire(blocking,timeout)
		if C:A._owner=B;A._count=1
		return C
	__enter__=acquire
	def release(A):
		if A._owner!=get_ident():raise RuntimeError(_F)
		A._count=B=A._count-1
		if not B:A._owner=_A;A._block.release()
	def __exit__(A,t,v,tb):A.release()
	def _acquire_restore(A,state):A._block.acquire();A._count,A._owner=state
	def _release_save(A):
		if A._count==0:raise RuntimeError(_F)
		B=A._count;A._count=0;C=A._owner;A._owner=_A;A._block.release();return B,C
	def _is_owned(A):return A._owner==get_ident()
_PyRLock=_RLock
class Condition:
	def __init__(B,lock=_A):
		A=lock
		if A is _A:A=RLock()
		B._lock=A;B.acquire=A.acquire;B.release=A.release
		try:B._release_save=A._release_save
		except AttributeError:pass
		try:B._acquire_restore=A._acquire_restore
		except AttributeError:pass
		try:B._is_owned=A._is_owned
		except AttributeError:pass
		B._waiters=_deque()
	def __enter__(A):return A._lock.__enter__()
	def __exit__(A,*B):return A._lock.__exit__(*B)
	def __repr__(A):return'<Condition(%s, %d)>'%(A._lock,len(A._waiters))
	def _release_save(A):A._lock.release()
	def _acquire_restore(A,x):A._lock.acquire()
	def _is_owned(A):
		if A._lock.acquire(0):A._lock.release();return _C
		else:return _B
	def wait(B,timeout=_A):
		D=timeout
		if not B._is_owned():raise RuntimeError('cannot wait on un-acquired lock')
		A=_allocate_lock();A.acquire();B._waiters.append(A);E=B._release_save();C=_C
		try:
			if D is _A:A.acquire();C=_B
			elif D>0:C=A.acquire(_B,D)
			else:C=A.acquire(_C)
			return C
		finally:
			B._acquire_restore(E)
			if not C:
				try:B._waiters.remove(A)
				except ValueError:pass
	def wait_for(E,predicate,timeout=_A):
		D=predicate;B=_A;A=timeout;C=D()
		while not C:
			if A is not _A:
				if B is _A:B=_time()+A
				else:
					A=B-_time()
					if A<=0:break
			E.wait(A);C=D()
		return C
	def notify(A,n=1):
		if not A._is_owned():raise RuntimeError('cannot notify on un-acquired lock')
		B=A._waiters;C=_deque(_islice(B,n))
		if not C:return
		for D in C:
			D.release()
			try:B.remove(D)
			except ValueError:pass
	def notify_all(A):A.notify(len(A._waiters))
	notifyAll=notify_all
class Semaphore:
	def __init__(A,value=1):
		B=value
		if B<0:raise ValueError('semaphore initial value must be >= 0')
		A._cond=Condition(Lock());A._value=B
	def acquire(B,blocking=_B,timeout=_A):
		D=blocking;A=timeout
		if not D and A is not _A:raise ValueError("can't specify timeout for non-blocking acquire")
		E=_C;C=_A
		with B._cond:
			while B._value==0:
				if not D:break
				if A is not _A:
					if C is _A:C=_time()+A
					else:
						A=C-_time()
						if A<=0:break
				B._cond.wait(A)
			else:B._value-=1;E=_B
		return E
	__enter__=acquire
	def release(A):
		with A._cond:A._value+=1;A._cond.notify()
	def __exit__(A,t,v,tb):A.release()
class BoundedSemaphore(Semaphore):
	def __init__(A,value=1):B=value;Semaphore.__init__(A,B);A._initial_value=B
	def release(A):
		with A._cond:
			if A._value>=A._initial_value:raise ValueError('Semaphore released too many times')
			A._value+=1;A._cond.notify()
class Event:
	def __init__(A):A._cond=Condition(Lock());A._flag=_C
	def _reset_internal_locks(A):A._cond.__init__(Lock())
	def is_set(A):return A._flag
	isSet=is_set
	def set(A):
		with A._cond:A._flag=_B;A._cond.notify_all()
	def clear(A):
		with A._cond:A._flag=_C
	def wait(A,timeout=_A):
		with A._cond:
			B=A._flag
			if not B:B=A._cond.wait(timeout)
			return B
class Barrier:
	def __init__(A,parties,action=_A,timeout=_A):A._cond=Condition(Lock());A._action=action;A._timeout=timeout;A._parties=parties;A._state=0;A._count=0
	def wait(A,timeout=_A):
		B=timeout
		if B is _A:B=A._timeout
		with A._cond:
			A._enter();C=A._count;A._count+=1
			try:
				if C+1==A._parties:A._release()
				else:A._wait(B)
				return C
			finally:A._count-=1;A._exit()
	def _enter(A):
		while A._state in(-1,1):A._cond.wait()
		if A._state<0:raise BrokenBarrierError
		assert A._state==0
	def _release(A):
		try:
			if A._action:A._action()
			A._state=1;A._cond.notify_all()
		except:A._break();raise
	def _wait(A,timeout):
		if not A._cond.wait_for(lambda:A._state!=0,timeout):A._break();raise BrokenBarrierError
		if A._state<0:raise BrokenBarrierError
		assert A._state==1
	def _exit(A):
		if A._count==0:
			if A._state in(-1,1):A._state=0;A._cond.notify_all()
	def reset(A):
		with A._cond:
			if A._count>0:
				if A._state==0:A._state=-1
				elif A._state==-2:A._state=-1
			else:A._state=0
			A._cond.notify_all()
	def abort(A):
		with A._cond:A._break()
	def _break(A):A._state=-2;A._cond.notify_all()
	@property
	def parties(self):return self._parties
	@property
	def n_waiting(self):
		if self._state==0:return self._count
		return 0
	@property
	def broken(self):return self._state==-2
class BrokenBarrierError(RuntimeError):0
_counter=_count().__next__
_counter()
def _newname(template='Thread-%d'):return template%_counter()
_active_limbo_lock=_allocate_lock()
_active={}
_limbo={}
_dangling=WeakSet()
_shutdown_locks_lock=_allocate_lock()
_shutdown_locks=set()
class Thread:
	_initialized=_C
	def __init__(A,group=_A,target=_A,name=_A,args=(),kwargs=_A,*,daemon=_A):
		C=daemon;B=kwargs;assert group is _A,'group argument must be None for now'
		if B is _A:B={}
		A._target=target;A._name=str(name or _newname());A._args=args;A._kwargs=B
		if C is not _A:A._daemonic=C
		else:A._daemonic=current_thread().daemon
		A._ident=_A
		if _HAVE_THREAD_NATIVE_ID:A._native_id=_A
		A._tstate_lock=_A;A._started=Event();A._is_stopped=_C;A._initialized=_B;A._stderr=_sys.stderr;A._invoke_excepthook=_make_invoke_excepthook();_dangling.add(A)
	def _reset_internal_locks(A,is_alive):
		A._started._reset_internal_locks()
		if is_alive:A._set_tstate_lock()
		else:A._is_stopped=_B;A._tstate_lock=_A
	def __repr__(A):
		assert A._initialized,'Thread.__init__() was not called';B='initial'
		if A._started.is_set():B='started'
		A.is_alive()
		if A._is_stopped:B='stopped'
		if A._daemonic:B+=' daemon'
		if A._ident is not _A:B+=' %s'%A._ident
		return'<%s(%s, %s)>'%(A.__class__.__name__,A._name,B)
	def start(A):
		if not A._initialized:raise RuntimeError('thread.__init__() not called')
		if A._started.is_set():raise RuntimeError('threads can only be started once')
		with _active_limbo_lock:_limbo[A]=A
		try:_start_new_thread(A._bootstrap,())
		except Exception:
			with _active_limbo_lock:del _limbo[A]
			raise
		A._started.wait()
	def run(A):
		try:
			if A._target:A._target(*A._args,**A._kwargs)
		finally:del A._target,A._args,A._kwargs
	def _bootstrap(A):
		try:A._bootstrap_inner()
		except:
			if A._daemonic and _sys is _A:return
			raise
	def _set_ident(A):A._ident=get_ident()
	if _HAVE_THREAD_NATIVE_ID:
		def _set_native_id(A):A._native_id=get_native_id()
	def _set_tstate_lock(A):
		A._tstate_lock=_set_sentinel();A._tstate_lock.acquire()
		if not A.daemon:
			with _shutdown_locks_lock:_shutdown_locks.add(A._tstate_lock)
	def _bootstrap_inner(A):
		try:
			A._set_ident();A._set_tstate_lock()
			if _HAVE_THREAD_NATIVE_ID:A._set_native_id()
			A._started.set()
			with _active_limbo_lock:_active[A._ident]=A;del _limbo[A]
			if _trace_hook:_sys.settrace(_trace_hook)
			if _profile_hook:_sys.setprofile(_profile_hook)
			try:A.run()
			except:A._invoke_excepthook(A)
		finally:
			with _active_limbo_lock:
				try:del _active[get_ident()]
				except:pass
	def _stop(A):
		B=A._tstate_lock
		if B is not _A:assert not B.locked()
		A._is_stopped=_B;A._tstate_lock=_A
		if not A.daemon:
			with _shutdown_locks_lock:_shutdown_locks.discard(B)
	def _delete(A):
		with _active_limbo_lock:del _active[get_ident()]
	def join(A,timeout=_A):
		B=timeout
		if not A._initialized:raise RuntimeError(_D)
		if not A._started.is_set():raise RuntimeError('cannot join thread before it is started')
		if A is current_thread():raise RuntimeError('cannot join current thread')
		if B is _A:A._wait_for_tstate_lock()
		else:A._wait_for_tstate_lock(timeout=max(B,0))
	def _wait_for_tstate_lock(A,block=_B,timeout=-1):
		B=A._tstate_lock
		if B is _A:assert A._is_stopped
		elif B.acquire(block,timeout):B.release();A._stop()
	@property
	def name(self):assert self._initialized,_D;return self._name
	@name.setter
	def name(self,name):assert self._initialized,_D;self._name=str(name)
	@property
	def ident(self):assert self._initialized,_D;return self._ident
	if _HAVE_THREAD_NATIVE_ID:
		@property
		def native_id(self):assert self._initialized,_D;return self._native_id
	def is_alive(A):
		assert A._initialized,_D
		if A._is_stopped or not A._started.is_set():return _C
		A._wait_for_tstate_lock(_C);return not A._is_stopped
	def isAlive(A):import warnings as B;B.warn('isAlive() is deprecated, use is_alive() instead',DeprecationWarning,stacklevel=2);return A.is_alive()
	@property
	def daemon(self):assert self._initialized,_D;return self._daemonic
	@daemon.setter
	def daemon(self,daemonic):
		A=self
		if not A._initialized:raise RuntimeError(_D)
		if A._started.is_set():raise RuntimeError('cannot set daemon status of active thread')
		A._daemonic=daemonic
	def isDaemon(A):return A.daemon
	def setDaemon(A,daemonic):A.daemon=daemonic
	def getName(A):return A.name
	def setName(A,name):A.name=name
try:from _thread import _excepthook as excepthook,_ExceptHookArgs as ExceptHookArgs
except ImportError:
	from traceback import print_exception as _print_exception;from collections import namedtuple;_ExceptHookArgs=namedtuple(_E,'exc_type exc_value exc_traceback thread')
	def ExceptHookArgs(args):return _ExceptHookArgs(*args)
	def excepthook(A):
		if A.exc_type==SystemExit:return
		if _sys is not _A and _sys.stderr is not _A:B=_sys.stderr
		elif A.thread is not _A:
			B=A.thread._stderr
			if B is _A:return
		else:return
		if A.thread is not _A:C=A.thread.name
		else:C=get_ident()
		print(f"Exception in thread {C}:",file=B,flush=_B);_print_exception(A.exc_type,A.exc_value,A.exc_traceback,file=B);B.flush()
def _make_invoke_excepthook():
	C=excepthook;D=_sys.excepthook
	if C is _A:raise RuntimeError('threading.excepthook is None')
	if D is _A:raise RuntimeError('sys.excepthook is None')
	E=_sys.exc_info;K=print;A=_sys
	def B(thread):
		F=thread;global excepthook
		try:
			B=excepthook
			if B is _A:B=C
			G=ExceptHookArgs([*E(),F]);B(G)
		except Exception as H:
			H.__suppress_context__=_B;del H
			if A is not _A and A.stderr is not _A:I=A.stderr
			else:I=F._stderr
			K('Exception in threading.excepthook:',file=I,flush=_B)
			if A is not _A and A.excepthook is not _A:J=A.excepthook
			else:J=D
			J(*E())
		finally:G=_A
	return B
class Timer(Thread):
	def __init__(A,interval,function,args=_A,kwargs=_A):B=kwargs;Thread.__init__(A);A.interval=interval;A.function=function;A.args=args if args is not _A else[];A.kwargs=B if B is not _A else{};A.finished=Event()
	def cancel(A):A.finished.set()
	def run(A):
		A.finished.wait(A.interval)
		if not A.finished.is_set():A.function(*A.args,**A.kwargs)
		A.finished.set()
class _MainThread(Thread):
	def __init__(A):
		Thread.__init__(A,name='MainThread',daemon=_C);A._set_tstate_lock();A._started.set();A._set_ident()
		if _HAVE_THREAD_NATIVE_ID:A._set_native_id()
		with _active_limbo_lock:_active[A._ident]=A
class _DummyThread(Thread):
	def __init__(A):
		Thread.__init__(A,name=_newname('Dummy-%d'),daemon=_B);A._started.set();A._set_ident()
		if _HAVE_THREAD_NATIVE_ID:A._set_native_id()
		with _active_limbo_lock:_active[A._ident]=A
	def _stop(A):0
	def is_alive(A):assert not A._is_stopped and A._started.is_set();return _B
	def join(A,timeout=_A):assert _C,'cannot join a dummy thread'
def current_thread():
	try:return _active[get_ident()]
	except KeyError:return _DummyThread()
currentThread=current_thread
def active_count():
	with _active_limbo_lock:return len(_active)+len(_limbo)
activeCount=active_count
def _enumerate():return list(_active.values())+list(_limbo.values())
def enumerate():
	with _active_limbo_lock:return list(_active.values())+list(_limbo.values())
from _thread import stack_size
_main_thread=_MainThread()
def _shutdown():
	if _main_thread._is_stopped:return
	A=_main_thread._tstate_lock;assert A is not _A;assert A.locked();A.release();_main_thread._stop()
	while _B:
		with _shutdown_locks_lock:B=list(_shutdown_locks);_shutdown_locks.clear()
		if not B:break
		for C in B:C.acquire();C.release()
def main_thread():return _main_thread
try:from _thread import _local as local
except ImportError:from _threading_local import local
def _after_fork():
	global _active_limbo_lock,_main_thread;global _shutdown_locks_lock,_shutdown_locks;_active_limbo_lock=_allocate_lock();C={}
	try:B=_active[get_ident()]
	except KeyError:B=_MainThread()
	_main_thread=B;_shutdown_locks_lock=_allocate_lock();_shutdown_locks=set()
	with _active_limbo_lock:
		D=set(_enumerate());D.update(_dangling)
		for A in D:
			if A is B:A._reset_internal_locks(_B);E=get_ident();A._ident=E;C[E]=A
			else:A._reset_internal_locks(_C);A._stop()
		_limbo.clear();_active.clear();_active.update(C);assert len(_active)==1
if hasattr(_os,'register_at_fork'):_os.register_at_fork(after_in_child=_after_fork)