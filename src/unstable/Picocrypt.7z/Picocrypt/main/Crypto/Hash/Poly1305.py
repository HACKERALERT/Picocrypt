_A=None
from binascii import unhexlify
from Crypto.Util.py3compat import bord,tobytes,_copy_bytes
from Crypto.Hash import BLAKE2s
from Crypto.Random import get_random_bytes
from Crypto.Util._raw_api import load_pycryptodome_raw_lib,VoidPointer,SmartPointer,create_string_buffer,get_raw_buffer,c_size_t,c_uint8_ptr
_raw_poly1305=load_pycryptodome_raw_lib('Crypto.Hash._poly1305','\n                        int poly1305_init(void **state,\n                                          const uint8_t *r,\n                                          size_t r_len,\n                                          const uint8_t *s,\n                                          size_t s_len);\n                        int poly1305_destroy(void *state);\n                        int poly1305_update(void *state,\n                                            const uint8_t *in,\n                                            size_t len);\n                        int poly1305_digest(const void *state,\n                                            uint8_t *digest,\n                                            size_t len);\n                        ')
class Poly1305_MAC:
	digest_size=16
	def __init__(A,r,s,data):
		if len(r)!=16:raise ValueError('Parameter r is not 16 bytes long')
		if len(s)!=16:raise ValueError('Parameter s is not 16 bytes long')
		A._mac_tag=_A;B=VoidPointer();C=_raw_poly1305.poly1305_init(B.address_of(),c_uint8_ptr(r),c_size_t(len(r)),c_uint8_ptr(s),c_size_t(len(s)))
		if C:raise ValueError('Error %d while instantiating Poly1305'%C)
		A._state=SmartPointer(B.get(),_raw_poly1305.poly1305_destroy)
		if data:A.update(data)
	def update(A,data):
		if A._mac_tag:raise TypeError("You can only call 'digest' or 'hexdigest' on this object")
		B=_raw_poly1305.poly1305_update(A._state.get(),c_uint8_ptr(data),c_size_t(len(data)))
		if B:raise ValueError('Error %d while hashing Poly1305 data'%B)
		return A
	def copy(A):raise NotImplementedError()
	def digest(A):
		if A._mac_tag:return A._mac_tag
		B=create_string_buffer(16);C=_raw_poly1305.poly1305_digest(A._state.get(),B,c_size_t(len(B)))
		if C:raise ValueError('Error %d while creating Poly1305 digest'%C)
		A._mac_tag=get_raw_buffer(B);return A._mac_tag
	def hexdigest(A):return ''.join(['%02x'%bord(B)for B in tuple(A.digest())])
	def verify(B,mac_tag):
		A=get_random_bytes(16);C=BLAKE2s.new(digest_bits=160,key=A,data=mac_tag);D=BLAKE2s.new(digest_bits=160,key=A,data=B.digest())
		if C.digest()!=D.digest():raise ValueError('MAC check failed')
	def hexverify(A,hex_mac_tag):A.verify(unhexlify(tobytes(hex_mac_tag)))
def new(**A):
	C=A.pop('cipher',_A)
	if not hasattr(C,'_derive_Poly1305_key_pair'):raise ValueError("Parameter 'cipher' must be AES or ChaCha20")
	D=A.pop('key',_A)
	if D is _A:raise TypeError("You must pass a parameter 'key'")
	B=A.pop('nonce',_A);F=A.pop('data',_A)
	if A:raise TypeError('Unknown parameters: '+str(A))
	G,H,B=C._derive_Poly1305_key_pair(D,B);E=Poly1305_MAC(G,H,F);E.nonce=_copy_bytes(_A,_A,B);return E