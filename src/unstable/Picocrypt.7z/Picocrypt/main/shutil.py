"Utility functions for copying and archiving files and directory trees.\n\nXXX The functions here don't copy the resource fork or other metadata on Mac.\n\n"
_X='total used free'
_W='usage'
_V='disk_usage'
_U="xz'ed tar-file"
_T='xztar'
_S="bzip2'ed tar-file"
_R='bztar'
_Q='ZIP file'
_P="gzip'ed tar-file"
_O='gztar'
_N='uncompressed tar file'
_M='tar'
_L='.zip'
_K='creating %s'
_J='.tar'
_I='bzip2'
_H='zip'
_G='xz'
_F='gzip'
_E='compress'
_D='Cannot call rmtree on a symbolic link'
_C=True
_B=False
_A=None
import os,sys,stat,fnmatch,collections,errno
try:import zlib;del zlib;_ZLIB_SUPPORTED=_C
except ImportError:_ZLIB_SUPPORTED=_B
try:import bz2;del bz2;_BZ2_SUPPORTED=_C
except ImportError:_BZ2_SUPPORTED=_B
try:import lzma;del lzma;_LZMA_SUPPORTED=_C
except ImportError:_LZMA_SUPPORTED=_B
try:from pwd import getpwnam
except ImportError:getpwnam=_A
try:from grp import getgrnam
except ImportError:getgrnam=_A
_WINDOWS=os.name=='nt'
posix=nt=_A
if os.name=='posix':import posix
elif _WINDOWS:import nt
COPY_BUFSIZE=1024*1024 if _WINDOWS else 64*1024
_USE_CP_SENDFILE=hasattr(os,'sendfile')and sys.platform.startswith('linux')
_HAS_FCOPYFILE=posix and hasattr(posix,'_fcopyfile')
_WIN_DEFAULT_PATHEXT='.COM;.EXE;.BAT;.CMD;.VBS;.JS;.WS;.MSC'
__all__=['copyfileobj','copyfile','copymode','copystat','copy','copy2','copytree','move','rmtree','Error','SpecialFileError','ExecError','make_archive','get_archive_formats','register_archive_format','unregister_archive_format','get_unpack_formats','register_unpack_format','unregister_unpack_format','unpack_archive','ignore_patterns','chown','which','get_terminal_size','SameFileError']
class Error(OSError):0
class SameFileError(Error):'Raised when source and destination are the same file.'
class SpecialFileError(OSError):'Raised when trying to do a kind of operation (e.g. copying) which is\n    not supported on a special file (e.g. a named pipe)'
class ExecError(OSError):'Raised when a command could not be executed'
class ReadError(OSError):'Raised when an archive cannot be read'
class RegistryError(Exception):'Raised when a registry operation with the archiving\n    and unpacking registries fails'
class _GiveupOnFastCopy(Exception):'Raised as a signal to fallback on using raw read()/write()\n    file copy when fast-copy functions fail to do so.\n    '
def _fastcopy_fcopyfile(fsrc,fdst,flags):
	'Copy a regular file content or metadata by using high-performance\n    fcopyfile(3) syscall (macOS).\n    '
	try:B=fsrc.fileno();C=fdst.fileno()
	except Exception as A:raise _GiveupOnFastCopy(A)
	try:posix._fcopyfile(B,C,flags)
	except OSError as A:
		A.filename=fsrc.name;A.filename2=fdst.name
		if A.errno in{errno.EINVAL,errno.ENOTSUP}:raise _GiveupOnFastCopy(A)
		else:raise A from _A
def _fastcopy_sendfile(fsrc,fdst):
	'Copy data from one regular mmap-like fd to another by using\n    high-performance sendfile(2) syscall.\n    This should work on Linux >= 2.6.33 only.\n    ';global _USE_CP_SENDFILE
	try:D=fsrc.fileno();E=fdst.fileno()
	except Exception as A:raise _GiveupOnFastCopy(A)
	try:B=max(os.fstat(D).st_size,2**23)
	except OSError:B=2**27
	if sys.maxsize<2**32:B=min(B,2**30)
	C=0
	while _C:
		try:F=os.sendfile(E,D,C,B)
		except OSError as A:
			A.filename=fsrc.name;A.filename2=fdst.name
			if A.errno==errno.ENOTSOCK:_USE_CP_SENDFILE=_B;raise _GiveupOnFastCopy(A)
			if A.errno==errno.ENOSPC:raise A from _A
			if C==0 and os.lseek(E,0,os.SEEK_CUR)==0:raise _GiveupOnFastCopy(A)
			raise A
		else:
			if F==0:break
			C+=F
def _copyfileobj_readinto(fsrc,fdst,length=COPY_BUFSIZE):
	'readinto()/memoryview() based variant of copyfileobj().\n    *fsrc* must support readinto() method and both files must be\n    open in binary mode.\n    ';C=length;D=fsrc.readinto;E=fdst.write
	with memoryview(bytearray(C))as A:
		while _C:
			B=D(A)
			if not B:break
			elif B<C:
				with A[:B]as F:fdst.write(F)
			else:E(A)
def copyfileobj(fsrc,fdst,length=0):
	'copy data from file-like object fsrc to file-like object fdst';A=length
	if not A:A=COPY_BUFSIZE
	C=fsrc.read;D=fdst.write
	while _C:
		B=C(A)
		if not B:break
		D(B)
def _samefile(src,dst):
	B=dst;A=src
	if isinstance(A,os.DirEntry)and hasattr(os.path,'samestat'):
		try:return os.path.samestat(A.stat(),os.stat(B))
		except OSError:return _B
	if hasattr(os.path,'samefile'):
		try:return os.path.samefile(A,B)
		except OSError:return _B
	return os.path.normcase(os.path.abspath(A))==os.path.normcase(os.path.abspath(B))
def _stat(fn):return fn.stat()if isinstance(fn,os.DirEntry)else os.stat(fn)
def _islink(fn):return fn.is_symlink()if isinstance(fn,os.DirEntry)else os.path.islink(fn)
def copyfile(src,dst,*,follow_symlinks=_C):
	'Copy data from src to dst in the most efficient way possible.\n\n    If follow_symlinks is not set and src is a symbolic link, a new\n    symlink will be created instead of copying the file it points to.\n\n    ';B=src;A=dst;sys.audit('shutil.copyfile',B,A)
	if _samefile(B,A):raise SameFileError('{!r} and {!r} are the same file'.format(B,A))
	F=0
	for (H,C) in enumerate([B,A]):
		try:G=_stat(C)
		except OSError:pass
		else:
			if stat.S_ISFIFO(G.st_mode):C=C.path if isinstance(C,os.DirEntry)else C;raise SpecialFileError('`%s` is a named pipe'%C)
			if _WINDOWS and H==0:F=G.st_size
	if not follow_symlinks and _islink(B):os.symlink(os.readlink(B),A)
	else:
		with open(B,'rb')as D,open(A,'wb')as E:
			if _HAS_FCOPYFILE:
				try:_fastcopy_fcopyfile(D,E,posix._COPYFILE_DATA);return A
				except _GiveupOnFastCopy:pass
			elif _USE_CP_SENDFILE:
				try:_fastcopy_sendfile(D,E);return A
				except _GiveupOnFastCopy:pass
			elif _WINDOWS and F>0:_copyfileobj_readinto(D,E,min(F,COPY_BUFSIZE));return A
			copyfileobj(D,E)
	return A
def copymode(src,dst,*,follow_symlinks=_C):
	"Copy mode bits from src to dst.\n\n    If follow_symlinks is not set, symlinks aren't followed if and only\n    if both `src` and `dst` are symlinks.  If `lchmod` isn't available\n    (e.g. Linux) this method does nothing.\n\n    ";B=dst;A=src;sys.audit('shutil.copymode',A,B)
	if not follow_symlinks and _islink(A)and os.path.islink(B):
		if hasattr(os,'lchmod'):C,D=os.lstat,os.lchmod
		else:return
	else:C,D=_stat,os.chmod
	E=C(A);D(B,stat.S_IMODE(E.st_mode))
if hasattr(os,'listxattr'):
	def _copyxattr(src,dst,*,follow_symlinks=_C):
		"Copy extended filesystem attributes from `src` to `dst`.\n\n        Overwrite existing attributes.\n\n        If `follow_symlinks` is false, symlinks won't be followed.\n\n        ";A=follow_symlinks
		try:D=os.listxattr(src,follow_symlinks=A)
		except OSError as B:
			if B.errno not in(errno.ENOTSUP,errno.ENODATA,errno.EINVAL):raise
			return
		for C in D:
			try:E=os.getxattr(src,C,follow_symlinks=A);os.setxattr(dst,C,E,follow_symlinks=A)
			except OSError as B:
				if B.errno not in(errno.EPERM,errno.ENOTSUP,errno.ENODATA,errno.EINVAL):raise
else:
	def _copyxattr(*A,**B):0
def copystat(src,dst,*,follow_symlinks=_C):
	'Copy file metadata\n\n    Copy the permission bits, last access time, last modification time, and\n    flags from `src` to `dst`. On Linux, copystat() also copies the "extended\n    attributes" where possible. The file contents, owner, and group are\n    unaffected. `src` and `dst` are path-like objects or path names given as\n    strings.\n\n    If the optional flag `follow_symlinks` is not set, symlinks aren\'t\n    followed if and only if both `src` and `dst` are symlinks.\n    ';C=dst;B=src;sys.audit('shutil.copystat',B,C)
	def F(*A,ns=_A,follow_symlinks=_A):0
	A=follow_symlinks or not(_islink(B)and os.path.islink(C))
	if A:
		def E(name):return getattr(os,name,F)
	else:
		def E(name):
			A=getattr(os,name,F)
			if A in os.supports_follow_symlinks:return A
			return F
	if isinstance(B,os.DirEntry):D=B.stat(follow_symlinks=A)
	else:D=E('stat')(B,follow_symlinks=A)
	H=stat.S_IMODE(D.st_mode);E('utime')(C,ns=(D.st_atime_ns,D.st_mtime_ns),follow_symlinks=A);_copyxattr(B,C,follow_symlinks=A)
	try:E('chmod')(C,H,follow_symlinks=A)
	except NotImplementedError:pass
	if hasattr(D,'st_flags'):
		try:E('chflags')(C,D.st_flags,follow_symlinks=A)
		except OSError as I:
			for G in ('EOPNOTSUPP','ENOTSUP'):
				if hasattr(errno,G)and I.errno==getattr(errno,G):break
			else:raise
def copy(src,dst,*,follow_symlinks=_C):
	'Copy data and mode bits ("cp src dst"). Return the file\'s destination.\n\n    The destination may be a directory.\n\n    If follow_symlinks is false, symlinks won\'t be followed. This\n    resembles GNU\'s "cp -P src dst".\n\n    If source and destination are the same file, a SameFileError will be\n    raised.\n\n    ';C=follow_symlinks;B=src;A=dst
	if os.path.isdir(A):A=os.path.join(A,os.path.basename(B))
	copyfile(B,A,follow_symlinks=C);copymode(B,A,follow_symlinks=C);return A
def copy2(src,dst,*,follow_symlinks=_C):
	'Copy data and metadata. Return the file\'s destination.\n\n    Metadata is copied with copystat(). Please see the copystat function\n    for more information.\n\n    The destination may be a directory.\n\n    If follow_symlinks is false, symlinks won\'t be followed. This\n    resembles GNU\'s "cp -P src dst".\n    ';C=follow_symlinks;B=src;A=dst
	if os.path.isdir(A):A=os.path.join(A,os.path.basename(B))
	copyfile(B,A,follow_symlinks=C);copystat(B,A,follow_symlinks=C);return A
def ignore_patterns(*B):
	'Function that can be used as copytree() ignore parameter.\n\n    Patterns is a sequence of glob-style patterns\n    that are used to exclude files'
	def A(path,names):
		A=[]
		for C in B:A.extend(fnmatch.filter(names,C))
		return set(A)
	return A
def _copytree(entries,src,dst,symlinks,ignore,copy_function,ignore_dangling_symlinks,dirs_exist_ok=_B):
	N=entries;K=dirs_exist_ok;I=ignore;H=symlinks;G=src;D=dst;C=copy_function
	if I is not _A:O=I(os.fspath(G),[A.name for A in N])
	else:O=set()
	os.makedirs(D,exist_ok=K);E=[];Q=C is copy2 or C is copy
	for A in N:
		if A.name in O:continue
		L=os.path.join(G,A.name);B=os.path.join(D,A.name);F=A if Q else L
		try:
			M=A.is_symlink()
			if M and os.name=='nt':
				R=A.stat(follow_symlinks=_B)
				if R.st_reparse_tag==stat.IO_REPARSE_TAG_MOUNT_POINT:M=_B
			if M:
				P=os.readlink(L)
				if H:os.symlink(P,B);copystat(F,B,follow_symlinks=not H)
				else:
					if not os.path.exists(P)and ignore_dangling_symlinks:continue
					if A.is_dir():copytree(F,B,H,I,C,dirs_exist_ok=K)
					else:C(F,B)
			elif A.is_dir():copytree(F,B,H,I,C,dirs_exist_ok=K)
			else:C(F,B)
		except Error as S:E.extend(S.args[0])
		except OSError as J:E.append((L,B,str(J)))
	try:copystat(G,D)
	except OSError as J:
		if getattr(J,'winerror',_A)is _A:E.append((G,D,str(J)))
	if E:raise Error(E)
	return D
def copytree(src,dst,symlinks=_B,ignore=_A,copy_function=copy2,ignore_dangling_symlinks=_B,dirs_exist_ok=_B):
	"Recursively copy a directory tree and return the destination directory.\n\n    dirs_exist_ok dictates whether to raise an exception in case dst or any\n    missing parent directory already exists.\n\n    If exception(s) occur, an Error is raised with a list of reasons.\n\n    If the optional symlinks flag is true, symbolic links in the\n    source tree result in symbolic links in the destination tree; if\n    it is false, the contents of the files pointed to by symbolic\n    links are copied. If the file pointed by the symlink doesn't\n    exist, an exception will be added in the list of errors raised in\n    an Error exception at the end of the copy process.\n\n    You can set the optional ignore_dangling_symlinks flag to true if you\n    want to silence this exception. Notice that this has no effect on\n    platforms that don't support os.symlink.\n\n    The optional ignore argument is a callable. If given, it\n    is called with the `src` parameter, which is the directory\n    being visited by copytree(), and `names` which is the list of\n    `src` contents, as returned by os.listdir():\n\n        callable(src, names) -> ignored_names\n\n    Since copytree() is called recursively, the callable will be\n    called once for each directory that is copied. It returns a\n    list of names relative to the `src` directory that should\n    not be copied.\n\n    The optional copy_function argument is a callable that will be used\n    to copy each file. It will be called with the source path and the\n    destination path as arguments. By default, copy2() is used, but any\n    function that supports the same signature (like copy()) can be used.\n\n    ";A=src;sys.audit('shutil.copytree',A,dst)
	with os.scandir(A)as B:C=list(B)
	return _copytree(entries=C,src=A,dst=dst,symlinks=symlinks,ignore=ignore,copy_function=copy_function,ignore_dangling_symlinks=ignore_dangling_symlinks,dirs_exist_ok=dirs_exist_ok)
if hasattr(os.stat_result,'st_file_attributes'):
	def _rmtree_isdir(entry):
		try:A=entry.stat(follow_symlinks=_B);return stat.S_ISDIR(A.st_mode)and not(A.st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT and A.st_reparse_tag==stat.IO_REPARSE_TAG_MOUNT_POINT)
		except OSError:return _B
	def _rmtree_islink(path):
		try:A=os.lstat(path);return stat.S_ISLNK(A.st_mode)or A.st_file_attributes&stat.FILE_ATTRIBUTE_REPARSE_POINT and A.st_reparse_tag==stat.IO_REPARSE_TAG_MOUNT_POINT
		except OSError:return _B
else:
	def _rmtree_isdir(entry):
		try:return entry.is_dir(follow_symlinks=_B)
		except OSError:return _B
	def _rmtree_islink(path):return os.path.islink(path)
def _rmtree_unsafe(path,onerror):
	B=path;A=onerror
	try:
		with os.scandir(B)as F:E=list(F)
	except OSError:A(os.scandir,B,sys.exc_info());E=[]
	for D in E:
		C=D.path
		if _rmtree_isdir(D):
			try:
				if D.is_symlink():raise OSError(_D)
			except OSError:A(os.path.islink,C,sys.exc_info());continue
			_rmtree_unsafe(C,A)
		else:
			try:os.unlink(C)
			except OSError:A(os.unlink,C,sys.exc_info())
	try:os.rmdir(B)
	except OSError:A(os.rmdir,B,sys.exc_info())
def _rmtree_safe_fd(topfd,path,onerror):
	F=path;D=topfd;A=onerror
	try:
		with os.scandir(D)as I:J=list(I)
	except OSError as K:K.filename=F;A(os.scandir,F,sys.exc_info());return
	for B in J:
		C=os.path.join(F,B.name)
		try:E=B.is_dir(follow_symlinks=_B)
		except OSError:E=_B
		else:
			if E:
				try:H=B.stat(follow_symlinks=_B);E=stat.S_ISDIR(H.st_mode)
				except OSError:A(os.lstat,C,sys.exc_info());continue
		if E:
			try:G=os.open(B.name,os.O_RDONLY,dir_fd=D)
			except OSError:A(os.open,C,sys.exc_info())
			else:
				try:
					if os.path.samestat(H,os.fstat(G)):
						_rmtree_safe_fd(G,C,A)
						try:os.rmdir(B.name,dir_fd=D)
						except OSError:A(os.rmdir,C,sys.exc_info())
					else:
						try:raise OSError(_D)
						except OSError:A(os.path.islink,C,sys.exc_info())
				finally:os.close(G)
		else:
			try:os.unlink(B.name,dir_fd=D)
			except OSError:A(os.unlink,C,sys.exc_info())
_use_fd_functions={os.open,os.stat,os.unlink,os.rmdir}<=os.supports_dir_fd and os.scandir in os.supports_fd and os.stat in os.supports_follow_symlinks
def rmtree(path,ignore_errors=_B,onerror=_A):
	'Recursively delete a directory tree.\n\n    If ignore_errors is set, errors are ignored; otherwise, if onerror\n    is set, it is called to handle the error with arguments (func,\n    path, exc_info) where func is platform and implementation dependent;\n    path is the argument to that function that caused it to fail; and\n    exc_info is a tuple returned by sys.exc_info().  If ignore_errors\n    is false and onerror is None, an exception is raised.\n\n    ';B=onerror;A=path;sys.audit('shutil.rmtree',A)
	if ignore_errors:
		def B(*A):0
	elif B is _A:
		def B(*A):raise
	if _use_fd_functions:
		if isinstance(A,bytes):A=os.fsdecode(A)
		try:D=os.lstat(A)
		except Exception:B(os.lstat,A,sys.exc_info());return
		try:C=os.open(A,os.O_RDONLY)
		except Exception:B(os.open,A,sys.exc_info());return
		try:
			if os.path.samestat(D,os.fstat(C)):
				_rmtree_safe_fd(C,A,B)
				try:os.rmdir(A)
				except OSError:B(os.rmdir,A,sys.exc_info())
			else:
				try:raise OSError(_D)
				except OSError:B(os.path.islink,A,sys.exc_info())
		finally:os.close(C)
	else:
		try:
			if _rmtree_islink(A):raise OSError(_D)
		except OSError:B(os.path.islink,A,sys.exc_info());return
		return _rmtree_unsafe(A,B)
rmtree.avoids_symlink_attacks=_use_fd_functions
def _basename(path):A=os.path.sep+(os.path.altsep or'');return os.path.basename(path.rstrip(A))
def move(src,dst,copy_function=copy2):
	'Recursively move a file or directory to another location. This is\n    similar to the Unix "mv" command. Return the file or directory\'s\n    destination.\n\n    If the destination is a directory or a symlink to a directory, the source\n    is moved inside the directory. The destination path must not already\n    exist.\n\n    If the destination already exists but is not a directory, it may be\n    overwritten depending on os.rename() semantics.\n\n    If the destination is on our current filesystem, then rename() is used.\n    Otherwise, src is copied to the destination and then removed. Symlinks are\n    recreated under the new name if os.rename() fails because of cross\n    filesystem renames.\n\n    The optional `copy_function` argument is a callable that will be used\n    to copy the source or it will be delegated to `copytree`.\n    By default, copy2() is used, but any function that supports the same\n    signature (like copy()) can be used.\n\n    A lot more could be done here...  A look at a mv.c shows a lot of\n    the issues this implementation glosses over.\n\n    ';D=copy_function;B=dst;A=src;sys.audit('shutil.move',A,B);C=B
	if os.path.isdir(B):
		if _samefile(A,B):os.rename(A,B);return
		C=os.path.join(B,_basename(A))
		if os.path.exists(C):raise Error("Destination path '%s' already exists"%C)
	try:os.rename(A,C)
	except OSError:
		if os.path.islink(A):E=os.readlink(A);os.symlink(E,C);os.unlink(A)
		elif os.path.isdir(A):
			if _destinsrc(A,B):raise Error("Cannot move a directory '%s' into itself '%s'."%(A,B))
			copytree(A,C,copy_function=D,symlinks=_C);rmtree(A)
		else:D(A,C);os.unlink(A)
	return C
def _destinsrc(src,dst):
	B=dst;A=src;A=os.path.abspath(A);B=os.path.abspath(B)
	if not A.endswith(os.path.sep):A+=os.path.sep
	if not B.endswith(os.path.sep):B+=os.path.sep
	return B.startswith(A)
def _get_gid(name):
	'Returns a gid, given a group name.'
	if getgrnam is _A or name is _A:return _A
	try:A=getgrnam(name)
	except KeyError:A=_A
	if A is not _A:return A[2]
	return _A
def _get_uid(name):
	'Returns an uid, given a user name.'
	if getpwnam is _A or name is _A:return _A
	try:A=getpwnam(name)
	except KeyError:A=_A
	if A is not _A:return A[2]
	return _A
def _make_tarball(base_name,base_dir,compress=_F,verbose=0,dry_run=0,owner=_A,group=_A,logger=_A):
	'Create a (possibly compressed) tar file from all the files under\n    \'base_dir\'.\n\n    \'compress\' must be "gzip" (the default), "bzip2", "xz", or None.\n\n    \'owner\' and \'group\' can be used to define an owner and a group for the\n    archive that is being built. If not provided, the current owner and group\n    will be used.\n\n    The output tar file will be named \'base_name\' +  ".tar", possibly plus\n    the appropriate compression extension (".gz", ".bz2", or ".xz").\n\n    Returns the output filename.\n    ';H=group;G=owner;F=dry_run;C=logger;A=compress
	if A is _A:B=''
	elif _ZLIB_SUPPORTED and A==_F:B='gz'
	elif _BZ2_SUPPORTED and A==_I:B='bz2'
	elif _LZMA_SUPPORTED and A==_G:B=_G
	else:raise ValueError("bad value for 'compress', or compression format not supported : {0}".format(A))
	import tarfile as L;M='.'+B if A else'';E=base_name+_J+M;D=os.path.dirname(E)
	if D and not os.path.exists(D):
		if C is not _A:C.info(_K,D)
		if not F:os.makedirs(D)
	if C is not _A:C.info('Creating tar archive')
	I=_get_uid(G);J=_get_gid(H)
	def N(tarinfo):
		A=tarinfo
		if J is not _A:A.gid=J;A.gname=H
		if I is not _A:A.uid=I;A.uname=G
		return A
	if not F:
		K=L.open(E,'w|%s'%B)
		try:K.add(base_dir,filter=N)
		finally:K.close()
	return E
def _make_zipfile(base_name,base_dir,verbose=0,dry_run=0,logger=_A):
	'Create a zip file from all the files under \'base_dir\'.\n\n    The output zip file will be named \'base_name\' + ".zip".  Returns the\n    name of the output zip file.\n    ';L="adding '%s'";I=dry_run;H=base_name;D=base_dir;B=logger;import zipfile as J;E=H+_L;C=os.path.dirname(H)
	if C and not os.path.exists(C):
		if B is not _A:B.info(_K,C)
		if not I:os.makedirs(C)
	if B is not _A:B.info("creating '%s' and adding '%s' to it",E,D)
	if not I:
		with J.ZipFile(E,'w',compression=J.ZIP_DEFLATED)as F:
			A=os.path.normpath(D)
			if A!=os.curdir:
				F.write(A,A)
				if B is not _A:B.info(L,A)
			for (K,M,N) in os.walk(D):
				for G in sorted(M):
					A=os.path.normpath(os.path.join(K,G));F.write(A,A)
					if B is not _A:B.info(L,A)
				for G in N:
					A=os.path.normpath(os.path.join(K,G))
					if os.path.isfile(A):
						F.write(A,A)
						if B is not _A:B.info(L,A)
	return E
_ARCHIVE_FORMATS={_M:(_make_tarball,[(_E,_A)],_N)}
if _ZLIB_SUPPORTED:_ARCHIVE_FORMATS[_O]=_make_tarball,[(_E,_F)],_P;_ARCHIVE_FORMATS[_H]=_make_zipfile,[],_Q
if _BZ2_SUPPORTED:_ARCHIVE_FORMATS[_R]=_make_tarball,[(_E,_I)],_S
if _LZMA_SUPPORTED:_ARCHIVE_FORMATS[_T]=_make_tarball,[(_E,_G)],_U
def get_archive_formats():'Returns a list of supported formats for archiving and unarchiving.\n\n    Each element of the returned sequence is a tuple (name, description)\n    ';A=[(A,B[2])for(A,B)in _ARCHIVE_FORMATS.items()];A.sort();return A
def register_archive_format(name,function,extra_args=_A,description=''):
	'Registers an archive format.\n\n    name is the name of the format. function is the callable that will be\n    used to create archives. If provided, extra_args is a sequence of\n    (name, value) tuples that will be passed as arguments to the callable.\n    description can be provided to describe the format, and will be returned\n    by the get_archive_formats() function.\n    ';B=function;A=extra_args
	if A is _A:A=[]
	if not callable(B):raise TypeError('The %s object is not callable'%B)
	if not isinstance(A,(tuple,list)):raise TypeError('extra_args needs to be a sequence')
	for C in A:
		if not isinstance(C,(tuple,list))or len(C)!=2:raise TypeError('extra_args elements are : (arg_name, value)')
	_ARCHIVE_FORMATS[name]=B,A,description
def unregister_archive_format(name):del _ARCHIVE_FORMATS[name]
def make_archive(base_name,format,root_dir=_A,base_dir=_A,verbose=0,dry_run=0,owner=_A,group=_A,logger=_A):
	'Create an archive file (eg. zip or tar).\n\n    \'base_name\' is the name of the file to create, minus any format-specific\n    extension; \'format\' is the archive format: one of "zip", "tar", "gztar",\n    "bztar", or "xztar".  Or any other registered format.\n\n    \'root_dir\' is a directory that will be the root directory of the\n    archive; ie. we typically chdir into \'root_dir\' before creating the\n    archive.  \'base_dir\' is the directory where we start archiving from;\n    ie. \'base_dir\' will be the common prefix of all files and\n    directories in the archive.  \'root_dir\' and \'base_dir\' both default\n    to the current directory.  Returns the name of the archive file.\n\n    \'owner\' and \'group\' are used when creating a tar archive. By default,\n    uses the current owner and group.\n    ';F=dry_run;D=base_dir;C=base_name;B=logger;A=root_dir;sys.audit('shutil.make_archive',C,format,A,D);G=os.getcwd()
	if A is not _A:
		if B is not _A:B.debug("changing into '%s'",A)
		C=os.path.abspath(C)
		if not F:os.chdir(A)
	if D is _A:D=os.curdir
	E={'dry_run':F,'logger':B}
	try:H=_ARCHIVE_FORMATS[format]
	except KeyError:raise ValueError("unknown archive format '%s'"%format) from _A
	I=H[0]
	for (J,K) in H[1]:E[J]=K
	if format!=_H:E['owner']=owner;E['group']=group
	try:L=I(C,D,**E)
	finally:
		if A is not _A:
			if B is not _A:B.debug("changing back to '%s'",G)
			os.chdir(G)
	return L
def get_unpack_formats():'Returns a list of supported formats for unpacking.\n\n    Each element of the returned sequence is a tuple\n    (name, extensions, description)\n    ';A=[(B,A[0],A[3])for(B,A)in _UNPACK_FORMATS.items()];A.sort();return A
def _check_unpack_options(extensions,function,extra_args):
	'Checks what gets registered as an unpacker.';A={}
	for (C,D) in _UNPACK_FORMATS.items():
		for E in D[0]:A[E]=C
	for B in extensions:
		if B in A:F='%s is already registered for "%s"';raise RegistryError(F%(B,A[B]))
	if not callable(function):raise TypeError('The registered function must be a callable')
def register_unpack_format(name,extensions,function,extra_args=_A,description=''):
	"Registers an unpack format.\n\n    `name` is the name of the format. `extensions` is a list of extensions\n    corresponding to the format.\n\n    `function` is the callable that will be\n    used to unpack archives. The callable will receive archives to unpack.\n    If it's unable to handle an archive, it needs to raise a ReadError\n    exception.\n\n    If provided, `extra_args` is a sequence of\n    (name, value) tuples that will be passed as arguments to the callable.\n    description can be provided to describe the format, and will be returned\n    by the get_unpack_formats() function.\n    ";C=function;B=extensions;A=extra_args
	if A is _A:A=[]
	_check_unpack_options(B,C,A);_UNPACK_FORMATS[name]=B,C,A,description
def unregister_unpack_format(name):'Removes the pack format from the registry.';del _UNPACK_FORMATS[name]
def _ensure_directory(path):
	'Ensure that the parent directory of `path` exists';A=os.path.dirname(path)
	if not os.path.isdir(A):os.makedirs(A)
def _unpack_zipfile(filename,extract_dir):
	'Unpack zip `filename` to `extract_dir`\n    ';H='/';B=filename;import zipfile as D
	if not D.is_zipfile(B):raise ReadError('%s is not a zip file'%B)
	zip=D.ZipFile(B)
	try:
		for E in zip.infolist():
			A=E.filename
			if A.startswith(H)or'..'in A:continue
			C=os.path.join(extract_dir,*A.split(H))
			if not C:continue
			_ensure_directory(C)
			if not A.endswith(H):
				F=zip.read(E.filename);G=open(C,'wb')
				try:G.write(F)
				finally:G.close();del F
	finally:zip.close()
def _unpack_tarfile(filename,extract_dir):
	'Unpack tar/tar.gz/tar.bz2/tar.xz `filename` to `extract_dir`\n    ';A=filename;import tarfile as B
	try:C=B.open(A)
	except B.TarError:raise ReadError('%s is not a compressed or uncompressed tar file'%A)
	try:C.extractall(extract_dir)
	finally:C.close()
_UNPACK_FORMATS={_M:([_J],_unpack_tarfile,[],_N),_H:([_L],_unpack_zipfile,[],_Q)}
if _ZLIB_SUPPORTED:_UNPACK_FORMATS[_O]=['.tar.gz','.tgz'],_unpack_tarfile,[],_P
if _BZ2_SUPPORTED:_UNPACK_FORMATS[_R]=['.tar.bz2','.tbz2'],_unpack_tarfile,[],_S
if _LZMA_SUPPORTED:_UNPACK_FORMATS[_T]=['.tar.xz','.txz'],_unpack_tarfile,[],_U
def _find_unpack_format(filename):
	for (A,B) in _UNPACK_FORMATS.items():
		for C in B[0]:
			if filename.endswith(C):return A
	return _A
def unpack_archive(filename,extract_dir=_A,format=_A):
	'Unpack an archive.\n\n    `filename` is the name of the archive.\n\n    `extract_dir` is the name of the target directory, where the archive\n    is unpacked. If not provided, the current working directory is used.\n\n    `format` is the archive format: one of "zip", "tar", "gztar", "bztar",\n    or "xztar".  Or any other registered format.  If not provided,\n    unpack_archive will use the filename extension and see if an unpacker\n    was registered for that extension.\n\n    In case none is found, a ValueError is raised.\n    ';B=extract_dir;A=filename;sys.audit('shutil.unpack_archive',A,B,format)
	if B is _A:B=os.getcwd()
	B=os.fspath(B);A=os.fspath(A)
	if format is not _A:
		try:D=_UNPACK_FORMATS[format]
		except KeyError:raise ValueError("Unknown unpack format '{0}'".format(format)) from _A
		C=D[1];C(A,B,**dict(D[2]))
	else:
		format=_find_unpack_format(A)
		if format is _A:raise ReadError("Unknown archive format '{0}'".format(A))
		C=_UNPACK_FORMATS[format][1];E=dict(_UNPACK_FORMATS[format][2]);C(A,B,**E)
if hasattr(os,'statvfs'):
	__all__.append(_V);_ntuple_diskusage=collections.namedtuple(_W,_X);_ntuple_diskusage.total.__doc__='Total space in bytes';_ntuple_diskusage.used.__doc__='Used space in bytes';_ntuple_diskusage.free.__doc__='Free space in bytes'
	def disk_usage(path):"Return disk usage statistics about the given path.\n\n        Returned value is a named tuple with attributes 'total', 'used' and\n        'free', which are the amount of total, used and free space, in bytes.\n        ";A=os.statvfs(path);B=A.f_bavail*A.f_frsize;C=A.f_blocks*A.f_frsize;D=(A.f_blocks-A.f_bfree)*A.f_frsize;return _ntuple_diskusage(C,D,B)
elif _WINDOWS:
	__all__.append(_V);_ntuple_diskusage=collections.namedtuple(_W,_X)
	def disk_usage(path):"Return disk usage statistics about the given path.\n\n        Returned values is a named tuple with attributes 'total', 'used' and\n        'free', which are the amount of total, used and free space, in bytes.\n        ";A,B=nt._getdiskusage(path);C=A-B;return _ntuple_diskusage(A,C,B)
def chown(path,user=_A,group=_A):
	'Change owner user and group of the given path.\n\n    user and group can be the uid/gid or the user/group names, and in that case,\n    they are converted to their respective uid/gid.\n    ';B=group;A=user;sys.audit('shutil.chown',path,A,B)
	if A is _A and B is _A:raise ValueError('user and/or group must be set')
	C=A;D=B
	if A is _A:C=-1
	elif isinstance(A,str):
		C=_get_uid(A)
		if C is _A:raise LookupError('no such user: {!r}'.format(A))
	if B is _A:D=-1
	elif not isinstance(B,int):
		D=_get_gid(B)
		if D is _A:raise LookupError('no such group: {!r}'.format(B))
	os.chown(path,C,D)
def get_terminal_size(fallback=(80,24)):
	"Get the size of the terminal window.\n\n    For each of the two dimensions, the environment variable, COLUMNS\n    and LINES respectively, is checked. If the variable is defined and\n    the value is a positive integer, it is used.\n\n    When COLUMNS or LINES is not defined, which is the common case,\n    the terminal connected to sys.__stdout__ is queried\n    by invoking os.get_terminal_size.\n\n    If the terminal size cannot be successfully queried, either because\n    the system doesn't support querying, or because we are not\n    connected to a terminal, the value given in fallback parameter\n    is used. Fallback defaults to (80, 24) which is the default\n    size used by many terminal emulators.\n\n    The value returned is a named tuple of type os.terminal_size.\n    "
	try:A=int(os.environ['COLUMNS'])
	except (KeyError,ValueError):A=0
	try:B=int(os.environ['LINES'])
	except (KeyError,ValueError):B=0
	if A<=0 or B<=0:
		try:C=os.get_terminal_size(sys.__stdout__.fileno())
		except (AttributeError,ValueError,OSError):C=os.terminal_size(fallback)
		if A<=0:A=C.columns
		if B<=0:B=C.lines
	return os.terminal_size((A,B))
def _access_check(fn,mode):return os.path.exists(fn)and os.access(fn,mode)and not os.path.isdir(fn)
def which(cmd,mode=os.F_OK|os.X_OK,path=_A):
	'Given a command, mode, and a PATH string, return the path which\n    conforms to the given mode on the PATH, or None if there is no such\n    file.\n\n    `mode` defaults to os.F_OK | os.X_OK. `path` defaults to the result\n    of os.environ.get("PATH"), or can be overridden with a custom search\n    path.\n\n    ';B=cmd;A=path
	if os.path.dirname(B):
		if _access_check(B,mode):return B
		return _A
	E=isinstance(B,bytes)
	if A is _A:
		A=os.environ.get('PATH',_A)
		if A is _A:
			try:A=os.confstr('CS_PATH')
			except (AttributeError,ValueError):A=os.defpath
	if not A:return _A
	if E:A=os.fsencode(A);A=A.split(os.fsencode(os.pathsep))
	else:A=os.fsdecode(A);A=A.split(os.pathsep)
	if sys.platform=='win32':
		C=os.curdir
		if E:C=os.fsencode(C)
		if C not in A:A.insert(0,C)
		J=os.getenv('PATHEXT')or _WIN_DEFAULT_PATHEXT;D=[A for A in J.split(os.pathsep)if A]
		if E:D=[os.fsencode(A)for A in D]
		if any((B.lower().endswith(A.lower())for A in D)):F=[B]
		else:F=[B+A for A in D]
	else:F=[B]
	G=set()
	for dir in A:
		H=os.path.normcase(dir)
		if not H in G:
			G.add(H)
			for K in F:
				I=os.path.join(dir,K)
				if _access_check(I,mode):return I
	return _A