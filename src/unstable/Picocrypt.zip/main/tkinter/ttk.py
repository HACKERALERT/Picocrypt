_d='selection'
_c='column'
_b='<<RangeChanged>>'
_a='index'
_Z='add'
_Y='bbox'
_X='names'
_W='_tile_loaded'
_V='null'
_U='menu'
_T='command'
_S='invoke'
_R='create'
_Q='from'
_P='tag'
_O='insert'
_N='set'
_M='identify'
_L='theme'
_K='element'
_J='typename'
_I='layout'
_H='map'
_G='configure'
_F='-%s'
_E='children'
_D=True
_C=' '
_B=False
_A=None
__version__='0.3.1'
__author__='Guilherme Polo <ggpolo@gmail.com>'
__all__=['Button','Checkbutton','Combobox','Entry','Frame','Label','Labelframe','LabelFrame','Menubutton','Notebook','Panedwindow','PanedWindow','Progressbar','Radiobutton','Scale','Scrollbar','Separator','Sizegrip','Spinbox','Style','Treeview','LabeledScale','OptionMenu','tclobjs_to_py','setup_master']
import tkinter
from tkinter import _flatten,_join,_stringify,_splitdict
_REQUIRE_TILE=_D if tkinter.TkVersion<8.5 else _B
def _load_tile(master):
	A=master
	if _REQUIRE_TILE:
		import os;B=os.environ.get('TILE_LIBRARY')
		if B:A.tk.eval('global auto_path; lappend auto_path {%s}'%B)
		A.tk.eval('package require tile');A._tile_loaded=_D
def _format_optvalue(value,script=_B):
	A=value
	if script:A=_stringify(A)
	elif isinstance(A,(list,tuple)):A=_join(A)
	return A
def _format_optdict(optdict,script=_B,ignore=_A):
	B=ignore;A=[]
	for (C,D) in optdict.items():
		if not B or C not in B:
			A.append(_F%C)
			if D is not _A:A.append(_format_optvalue(D,script))
	return _flatten(A)
def _mapdict_values(items):
	B=[]
	for (*A,C) in items:
		if len(A)==1:A=A[0]or''
		else:A=_C.join(A)
		B.append(A)
		if C is not _A:B.append(C)
	return B
def _format_mapdict(mapdict,script=_B):
	A=[]
	for (B,C) in mapdict.items():A.extend((_F%B,_format_optvalue(_mapdict_values(C),script)))
	return _flatten(A)
def _format_elemcreate(etype,script=_B,*A,**F):
	L='image';E=script;D=etype;B=_A;C=()
	if D in(L,'vsapi'):
		if D==L:G=A[0];H=_join(_mapdict_values(A[1:]));B='%s %s'%(G,H)
		else:I,J=A[:2];K=_join(_mapdict_values(A[2:]));B='%s %s %s'%(I,J,K)
		C=_format_optdict(F,E)
	elif D==_Q:
		B=A[0]
		if len(A)>1:C=_format_optvalue(A[1],E),
	if E:B='{%s}'%B;C=_C.join(C)
	return B,C
def _format_layoutlist(layout,indent=0,indent_size=2):
	D=indent_size;A=indent;B=[]
	for G in layout:
		H,C=G;C=C or{};E=_C.join(_format_optdict(C,_D,(_E,)));F='%s%s%s'%(_C*A,H,' %s'%E if E else'')
		if _E in C:B.append(F+' -children {');A+=D;I,A=_format_layoutlist(C[_E],A,D);B.append(I);A-=D;B.append('%s}'%(_C*A))
		else:B.append(F)
	return '\n'.join(B),A
def _script_from_settings(settings):
	K='element create';E=[]
	for (F,A) in settings.items():
		if A.get(_G):D=_C.join(_format_optdict(A[_G],_D));E.append('ttk::style configure %s %s;'%(F,D))
		if A.get(_H):D=_C.join(_format_mapdict(A[_H],_D));E.append('ttk::style map %s %s;'%(F,D))
		if _I in A:
			if not A[_I]:D=_V
			else:D,_=_format_layoutlist(A[_I])
			E.append('ttk::style layout %s {\n%s\n}'%(F,D))
		if A.get(K):
			B=A[K];G=B[0];C=1
			while C<len(B)and not hasattr(B[C],'items'):C+=1
			H=B[1:C];I=B[C]if C<len(B)and B[C]else{};J,A=_format_elemcreate(G,_D,*H,**I);E.append('ttk::style element create %s %s %s %s'%(F,G,J,A))
	return '\n'.join(E)
def _list_from_statespec(stuple):
	C=stuple
	if isinstance(C,str):return C
	D=[];E=iter(C)
	for (A,B) in zip(E,E):
		if hasattr(A,_J):A=str(A).split()
		elif isinstance(A,str):A=A.split()
		elif not isinstance(A,(tuple,list)):A=A,
		if hasattr(B,_J):B=str(B)
		D.append((*A,B))
	return D
def _list_from_layouttuple(tk,ltuple):
	B=ltuple;B=tk.splitlist(B);E=[];A=0
	while A<len(B):
		G=B[A];F={};E.append((G,F));A+=1
		while A<len(B):
			C,D=B[A:A+2]
			if not C.startswith('-'):break
			C=C[1:];A+=2
			if C==_E:D=_list_from_layouttuple(tk,D)
			F[C]=D
	return E
def _val_or_dict(tk,options,*C):
	A=options;A=_format_optdict(A);B=tk.call(*C+A)
	if len(A)%2:return B
	return _splitdict(tk,B,conv=_tclobj_to_py)
def _convert_stringval(value):
	A=value;A=str(A)
	try:A=int(A)
	except (ValueError,TypeError):pass
	return A
def _to_number(x):
	if isinstance(x,str):
		if'.'in x:x=float(x)
		else:x=int(x)
	return x
def _tclobj_to_py(val):
	A=val
	if A and hasattr(A,'__len__')and not isinstance(A,str):
		if getattr(A[0],_J,_A)=='StateSpec':A=_list_from_statespec(A)
		else:A=list(map(_convert_stringval,A))
	elif hasattr(A,_J):A=_convert_stringval(A)
	return A
def tclobjs_to_py(adict):
	A=adict
	for (B,C) in A.items():A[B]=_tclobj_to_py(C)
	return A
def setup_master(master=_A):
	A=master
	if A is _A:A=tkinter._get_default_root()
	return A
class Style:
	_name='ttk::style'
	def __init__(B,master=_A):
		A=master;A=setup_master(A)
		if not getattr(A,_W,_B):_load_tile(A)
		B.master=A;B.tk=B.master.tk
	def configure(B,style,query_opt=_A,**C):
		A=query_opt
		if A is not _A:C[A]=_A
		D=_val_or_dict(B.tk,C,B._name,_G,style)
		if D or A:return D
	def map(A,style,query_opt=_A,**E):
		D=query_opt;C=style
		if D is not _A:B=A.tk.call(A._name,_H,C,_F%D);return _list_from_statespec(A.tk.splitlist(B))
		B=A.tk.call(A._name,_H,C,*_format_mapdict(E));return{C:_list_from_statespec(A.tk.splitlist(D))for(C,D)in _splitdict(A.tk,B).items()}
	def lookup(B,style,option,state=_A,default=_A):A=state;A=_C.join(A)if A else'';return B.tk.call(B._name,'lookup',style,_F%option,A,default)
	def layout(A,style,layoutspec=_A):
		B=layoutspec;C=_A
		if B:C=_format_layoutlist(B)[0]
		elif B is not _A:C=_V
		return _list_from_layouttuple(A.tk,A.tk.call(A._name,_I,style,C))
	def element_create(A,elementname,etype,*C,**D):B=etype;E,F=_format_elemcreate(B,_B,*C,**D);A.tk.call(A._name,_K,_R,elementname,B,E,*F)
	def element_names(A):return tuple((B.lstrip('-')for B in A.tk.splitlist(A.tk.call(A._name,_K,_X))))
	def element_options(A,elementname):return tuple((B.lstrip('-')for B in A.tk.splitlist(A.tk.call(A._name,_K,'options',elementname))))
	def theme_create(A,themename,parent=_A,settings=_A):
		F='-settings';D=settings;C=parent;B=themename;E=_script_from_settings(D)if D else''
		if C:A.tk.call(A._name,_L,_R,B,'-parent',C,F,E)
		else:A.tk.call(A._name,_L,_R,B,F,E)
	def theme_settings(A,themename,settings):B=_script_from_settings(settings);A.tk.call(A._name,_L,'settings',themename,B)
	def theme_names(A):return A.tk.splitlist(A.tk.call(A._name,_L,_X))
	def theme_use(A,themename=_A):
		B=themename
		if B is _A:return A.tk.eval('return $ttk::currentTheme')
		A.tk.call('ttk::setTheme',B)
class Widget(tkinter.Widget):
	def __init__(B,master,widgetname,kw=_A):
		A=master;A=setup_master(A)
		if not getattr(A,_W,_B):_load_tile(A)
		tkinter.Widget.__init__(B,A,widgetname,kw=kw)
	def identify(A,x,y):return A.tk.call(A._w,_M,x,y)
	def instate(A,statespec,callback=_A,*D,**E):
		B=callback;C=A.tk.getboolean(A.tk.call(A._w,'instate',_C.join(statespec)))
		if C and B:return B(*D,**E)
		return C
	def state(B,statespec=_A):
		A=statespec
		if A is not _A:A=_C.join(A)
		return B.tk.splitlist(str(B.tk.call(B._w,'state',A)))
class Button(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::button',B)
	def invoke(A):return A.tk.call(A._w,_S)
class Checkbutton(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::checkbutton',B)
	def invoke(A):return A.tk.call(A._w,_S)
class Entry(Widget,tkinter.Entry):
	def __init__(A,master=_A,widget=_A,**B):Widget.__init__(A,master,widget or'ttk::entry',B)
	def bbox(A,index):return A._getints(A.tk.call(A._w,_Y,index))
	def identify(A,x,y):return A.tk.call(A._w,_M,x,y)
	def validate(A):return A.tk.getboolean(A.tk.call(A._w,'validate'))
class Combobox(Entry):
	def __init__(A,master=_A,**B):Entry.__init__(A,master,'ttk::combobox',**B)
	def current(A,newindex=_A):
		C='current';B=newindex
		if B is _A:return A.tk.getint(A.tk.call(A._w,C))
		return A.tk.call(A._w,C,B)
	def set(A,value):A.tk.call(A._w,_N,value)
class Frame(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::frame',B)
class Label(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::label',B)
class Labelframe(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::labelframe',B)
LabelFrame=Labelframe
class Menubutton(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::menubutton',B)
class Notebook(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::notebook',B)
	def add(A,child,**B):A.tk.call(A._w,_Z,child,*_format_optdict(B))
	def forget(A,tab_id):A.tk.call(A._w,'forget',tab_id)
	def hide(A,tab_id):A.tk.call(A._w,'hide',tab_id)
	def identify(A,x,y):return A.tk.call(A._w,_M,x,y)
	def index(A,tab_id):return A.tk.getint(A.tk.call(A._w,_a,tab_id))
	def insert(A,pos,child,**B):A.tk.call(A._w,_O,pos,child,*_format_optdict(B))
	def select(A,tab_id=_A):return A.tk.call(A._w,'select',tab_id)
	def tab(A,tab_id,option=_A,**C):
		B=option
		if B is not _A:C[B]=_A
		return _val_or_dict(A.tk,C,A._w,'tab',tab_id)
	def tabs(A):return A.tk.splitlist(A.tk.call(A._w,'tabs')or())
	def enable_traversal(A):A.tk.call('ttk::notebook::enableTraversal',A._w)
class Panedwindow(Widget,tkinter.PanedWindow):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::panedwindow',B)
	forget=tkinter.PanedWindow.forget
	def insert(A,pos,child,**B):A.tk.call(A._w,_O,pos,child,*_format_optdict(B))
	def pane(A,pane,option=_A,**C):
		B=option
		if B is not _A:C[B]=_A
		return _val_or_dict(A.tk,C,A._w,'pane',pane)
	def sashpos(A,index,newpos=_A):return A.tk.getint(A.tk.call(A._w,'sashpos',index,newpos))
PanedWindow=Panedwindow
class Progressbar(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::progressbar',B)
	def start(A,interval=_A):A.tk.call(A._w,'start',interval)
	def step(A,amount=_A):A.tk.call(A._w,'step',amount)
	def stop(A):A.tk.call(A._w,'stop')
class Radiobutton(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::radiobutton',B)
	def invoke(A):return A.tk.call(A._w,_S)
class Scale(Widget,tkinter.Scale):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::scale',B)
	def configure(C,cnf=_A,**A):
		B=cnf;D=Widget.configure(C,B,**A)
		if not isinstance(B,(type(_A),str)):A.update(B)
		if any([_Q in A,'from_'in A,'to'in A]):C.event_generate(_b)
		return D
	def get(A,x=_A,y=_A):return A.tk.call(A._w,'get',x,y)
class Scrollbar(Widget,tkinter.Scrollbar):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::scrollbar',B)
class Separator(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::separator',B)
class Sizegrip(Widget):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::sizegrip',B)
class Spinbox(Entry):
	def __init__(A,master=_A,**B):Entry.__init__(A,master,'ttk::spinbox',**B)
	def set(A,value):A.tk.call(A._w,_N,value)
class Treeview(Widget,tkinter.XView,tkinter.YView):
	def __init__(A,master=_A,**B):Widget.__init__(A,master,'ttk::treeview',B)
	def bbox(A,item,column=_A):return A._getints(A.tk.call(A._w,_Y,item,column))or''
	def get_children(A,item=_A):return A.tk.splitlist(A.tk.call(A._w,_E,item or'')or())
	def set_children(A,item,*B):A.tk.call(A._w,_E,item,B)
	def column(A,column,option=_A,**C):
		B=option
		if B is not _A:C[B]=_A
		return _val_or_dict(A.tk,C,A._w,_c,column)
	def delete(A,*B):A.tk.call(A._w,'delete',B)
	def detach(A,*B):A.tk.call(A._w,'detach',B)
	def exists(A,item):return A.tk.getboolean(A.tk.call(A._w,'exists',item))
	def focus(A,item=_A):return A.tk.call(A._w,'focus',item)
	def heading(A,column,option=_A,**B):
		D=option;C=B.get(_T)
		if C and not isinstance(C,str):B[_T]=A.master.register(C,A._substitute)
		if D is not _A:B[D]=_A
		return _val_or_dict(A.tk,B,A._w,'heading',column)
	def identify(A,component,x,y):return A.tk.call(A._w,_M,component,x,y)
	def identify_row(A,y):return A.identify('row',0,y)
	def identify_column(A,x):return A.identify(_c,x,0)
	def identify_region(A,x,y):return A.identify('region',x,y)
	def identify_element(A,x,y):return A.identify(_K,x,y)
	def index(A,item):return A.tk.getint(A.tk.call(A._w,_a,item))
	def insert(A,parent,index,iid=_A,**F):
		C=index;B=parent;D=_format_optdict(F)
		if iid is not _A:E=A.tk.call(A._w,_O,B,C,'-id',iid,*D)
		else:E=A.tk.call(A._w,_O,B,C,*D)
		return E
	def item(A,item,option=_A,**C):
		B=option
		if B is not _A:C[B]=_A
		return _val_or_dict(A.tk,C,A._w,'item',item)
	def move(A,item,parent,index):A.tk.call(A._w,'move',item,parent,index)
	reattach=move
	def next(A,item):return A.tk.call(A._w,'next',item)
	def parent(A,item):return A.tk.call(A._w,'parent',item)
	def prev(A,item):return A.tk.call(A._w,'prev',item)
	def see(A,item):A.tk.call(A._w,'see',item)
	def selection(A):return A.tk.splitlist(A.tk.call(A._w,_d))
	def _selection(B,selop,items):
		A=items
		if len(A)==1 and isinstance(A[0],(tuple,list)):A=A[0]
		B.tk.call(B._w,_d,selop,A)
	def selection_set(A,*B):A._selection(_N,B)
	def selection_add(A,*B):A._selection(_Z,B)
	def selection_remove(A,*B):A._selection('remove',B)
	def selection_toggle(A,*B):A._selection('toggle',B)
	def set(A,item,column=_A,value=_A):
		C=value;B=column;D=A.tk.call(A._w,_N,item,B,C)
		if B is _A and C is _A:return _splitdict(A.tk,D,cut_minus=_B,conv=_tclobj_to_py)
		else:return D
	def tag_bind(A,tagname,sequence=_A,callback=_A):A._bind((A._w,_P,'bind',tagname),sequence,callback,add=0)
	def tag_configure(A,tagname,option=_A,**C):
		B=option
		if B is not _A:C[B]=_A
		return _val_or_dict(A.tk,C,A._w,_P,_G,tagname)
	def tag_has(A,tagname,item=_A):
		C='has';B=tagname
		if item is _A:return A.tk.splitlist(A.tk.call(A._w,_P,C,B))
		else:return A.tk.getboolean(A.tk.call(A._w,_P,C,B,item))
class LabeledScale(Frame):
	def __init__(A,master=_A,variable=_A,from_=0,to=10,**E):I='bottom';D=master;C=from_;B='top';A._label_top=E.pop('compound',B)==B;Frame.__init__(A,D,**E);A._variable=variable or tkinter.IntVar(D);A._variable.set(C);A._last_valid=C;A.label=Label(A);A.scale=Scale(A,variable=A._variable,from_=C,to=to);A.scale.bind(_b,A._adjust);F=I if A._label_top else B;G=B if F==I else I;A.scale.pack(side=F,fill='x');H=Label(A);H.pack(side=G);H.lower();A.label.place(anchor='n'if G==B else's');A.__tracecb=A._variable.trace_variable('w',A._adjust);A.bind('<Configure>',A._adjust);A.bind('<Map>',A._adjust)
	def destroy(A):
		try:A._variable.trace_vdelete('w',A.__tracecb)
		except AttributeError:pass
		else:del A._variable
		super().destroy();A.label=_A;A.scale=_A
	def _adjust(A,*F):
		def E():
			A.update_idletasks();C,B=A.scale.coords()
			if A._label_top:B=A.scale.winfo_y()-A.label.winfo_reqheight()
			else:B=A.scale.winfo_reqheight()+A.label.winfo_reqheight()
			A.label.place_configure(x=C,y=B)
		B=_to_number(A.scale[_Q]);C=_to_number(A.scale['to'])
		if C<B:B,C=C,B
		D=A._variable.get()
		if not B<=D<=C:A.value=A._last_valid;return
		A._last_valid=D;A.label['text']=D;A.after_idle(E)
	@property
	def value(self):return self._variable.get()
	@value.setter
	def value(self,val):self._variable.set(val)
class OptionMenu(Menubutton):
	def __init__(A,master,variable,default=_A,*D,**B):
		G='direction';F='style';C=variable;E={'textvariable':C,F:B.pop(F,_A),G:B.pop(G,_A)};Menubutton.__init__(A,master,**E);A[_U]=tkinter.Menu(A,tearoff=_B);A._variable=C;A._callback=B.pop(_T,_A)
		if B:raise tkinter.TclError('unknown option -%s'%next(iter(B.keys())))
		A.set_menu(default,*D)
	def __getitem__(A,item):
		B=item
		if B==_U:return A.nametowidget(Menubutton.__getitem__(A,B))
		return Menubutton.__getitem__(A,B)
	def set_menu(A,default=_A,*E):
		B=default;C=A[_U];C.delete(0,'end')
		for D in E:C.add_radiobutton(label=D,command=tkinter._setit(A._variable,D,A._callback),variable=A._variable)
		if B:A._variable.set(B)
	def destroy(A):
		try:del A._variable
		except AttributeError:pass
		super().destroy()