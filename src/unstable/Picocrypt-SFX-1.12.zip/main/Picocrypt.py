_d='#666666'
_c='#000000'
_b='Darwin'
_a='#6f737d'
_Z='<KeyRelease>'
_Y='#ffffff'
_X='Ready.'
_W='#f5f6f7'
_V='s'
_U='1.0'
_T=b'+'
_S='#fbfcfc'
_R='Confirm password:'
_Q='determinate'
_P='Windows'
_O='utf-8'
_N='<Button-1>'
_M='nesw'
_L='.pcv'
_K='#e5eaf0'
_J='value'
_I='encrypt'
_H='•'
_G='decrypt'
_F='hand2'
_E=True
_D='normal'
_C=False
_B='disabled'
_A='state'
from threading import Thread
from datetime import datetime,timedelta
from argon2.low_level import hash_secret_raw
from argon2.low_level import Type as argonType
from Crypto.Cipher import ChaCha20_Poly1305
from Crypto.Hash import SHA3_512
from blake3 import blake3
from hmac import compare_digest
from creedsolo import RSCodec,ReedSolomonError
from os import urandom,fsync,remove,system
from os.path import getsize,expanduser,isdir,exists
from os.path import basename,dirname,abspath,realpath
from os.path import join as pathJoin,split as pathSplit
from pathlib import Path
from zipfile import ZipFile
from tkinterdnd2 import TkinterDnD,DND_FILES
from tkinter.filedialog import asksaveasfilename
from ttkthemes import ThemedStyle
from time import sleep
import re,sys,tkinter,tkinter.ttk,tkinter.scrolledtext,webbrowser,platform
rootDir=dirname(realpath(__file__))
working=_C
mode=_C
inputFile=_C
outputFile=_C
rs128=_C
rs13=_C
allFiles=_C
onlyFolders=_C
onlyFiles=_C
startTime=_C
previousTime=_C
done=_C
stopUpdating=_C
reedsolo=_C
reedsoloFixed=_C
reedsoloErrors=_C
strings=['File metadata (used to store some text along with the file):','Compressing files together...','Error. The provided password is incorrect.','Error. The input file is corrupted.','Error. The input file and header keys are badly corrupted.','Error. The input file has been intentionally modified.','The input file is corrupted, but the output has been kept.','The input file has been intentionally modified, but the output has been kept.','The input file is badly corrupted, but the output has been kept.','Deriving key (takes a few seconds)...',"Keep decrypted output even if it's corrupted or modified",'Securely erase and delete original file','Securely erasing original file(s)...','Output file already exists. Would you like to overwrite it?','','Prevent corruption using Reed-Solomon','Error. Folder(s) and/or file(s) are empty.','Unknown error occured. Please try again.','Drag and drop file(s) and folder(s) into this window.','File metadata (read-only):',"Error. The input file couldn't be decoded as UTF-8."]
tk=TkinterDnD.Tk()
tk.geometry('480x500')
tk.title('Picocrypt')
tk.resizable(0,0)
tk.configure(background=_W)
ThemedStyle(tk).set_theme('arc')
def Get_HWND_DPI(window_handle):
	from ctypes import windll as B,pointer as E,wintypes as A;B.shcore.SetProcessDpiAwareness(1);F=96;G=0;H=A.HWND(window_handle);I=B.user32.MonitorFromWindow(H,A.DWORD(2));C=A.UINT();D=A.UINT()
	try:B.shcore.GetDpiForMonitor(I,G,E(C),E(D));return C.value*2,D.value*2,(C.value+D.value)/(2*F)
	except Exception:return 96,96,1
def TkGeometryScale(s,cvtfunc):E='+';A=cvtfunc;D='(?P<W>\\d+)x(?P<H>\\d+)\\+(?P<X>\\d+)\\+(?P<Y>\\d+)';B=re.compile(D).search(s);C=str(A(B.group('W')))+'x';C+=str(A(B.group('H')))+E;C+=str(A(B.group('X')))+E;C+=str(A(B.group('Y')));return C
def MakeTkDPIAware(TKGUI):A=TKGUI;A.DPI_X,A.DPI_Y,A.DPI_scaling=Get_HWND_DPI(A.winfo_id());A.TkScale=lambda v:int(float(v)*A.DPI_scaling);A.TkGeometryScale=lambda s:TkGeometryScale(s,A.TkScale)
if platform.system()==_P:0
try:favicon=tkinter.PhotoImage(file='./key.png');tk.iconphoto(_C,favicon)
except:pass
dummy=tkinter.ttk.Button(tk)
dummy.place(x=480,y=0)
inputString=tkinter.StringVar(tk)
inputString.set(strings[18])
inputLabel=tkinter.ttk.Label(tk,textvariable=inputString)
inputLabel.place(x=20,y=18)
clearInput=tkinter.ttk.Button(tk,text='Clear',command=lambda:[resetUI(),statusString.set(_X)])
clearInput.place(x=386,y=13,width=74,height=27)
clearInput[_A]=_B
separator=tkinter.Frame(tk,bg='#dfe3ed',height=1)
separator.place(x=20,y=39,width=438)
outputString=tkinter.StringVar(tk)
outputString.set('Save output as:')
outputLabel=tkinter.ttk.Label(tk,textvariable=outputString)
outputLabel.place(x=20,y=51)
outputLabel[_A]=_B
pcvString=tkinter.StringVar(tk)
pcvString.set(_L)
pcvLabel=tkinter.ttk.Label(tk,textvariable=pcvString)
pcvLabel.place(x=314,y=71)
outputFrame=tkinter.Frame(tk,width=320,height=24)
outputFrame.place(x=20,y=69)
outputFrame.columnconfigure(0,weight=10)
outputFrame.grid_propagate(_C)
outputInput=tkinter.ttk.Entry(outputFrame)
outputInput.grid(sticky=_M)
outputInput[_A]=_B
orString=tkinter.StringVar(tk)
orString.set('or')
orLabel=tkinter.ttk.Label(tk,textvariable=orString)
orLabel.place(x=356,y=71)
def saveAs():
	global mode,onlyFiles,onlyFolders;dummy.focus()
	if inputFile:A=dirname(inputFile)
	elif onlyFiles:A=dirname(onlyFiles[0])
	else:A=Path(onlyFolders[0]).parent.absolute()
	B=asksaveasfilename(initialdir=A,initialfile=basename(inputFile)[:-4]if mode==_G else basename(inputFile)+_L,confirmoverwrite=_E);outputInput.delete(0,tkinter.END);outputInput.insert(0,B if mode==_G else B[:-4])
saveAsBtn=tkinter.ttk.Button(tk,text='Save as',command=saveAs)
saveAsBtn.place(x=386,y=67,width=74,height=27)
saveAsBtn[_A]=_B
passwordString=tkinter.StringVar(tk)
passwordString.set('Password:')
passwordLabel=tkinter.ttk.Label(tk,textvariable=passwordString)
passwordLabel.place(x=20,y=103)
passwordLabel[_A]=_B
passwordFrame=tkinter.Frame(tk,width=210,height=24)
passwordFrame.place(x=20,y=121)
passwordFrame.columnconfigure(0,weight=10)
passwordFrame.grid_propagate(_C)
passwordInput=tkinter.ttk.Entry(passwordFrame,show=_H)
passwordInput.grid(sticky=_M)
passwordInput[_A]=_B
def showPassword(e):
	if passwordInput.cget('show'):passwordInput.config(show='');cPasswordInput.config(show='')
	else:passwordInput.config(show=_H);cPasswordInput.config(show=_H)
passwordShowString=tkinter.StringVar(tk)
passwordShowString.set('👁')
passwordShow=tkinter.ttk.Label(tk,textvariable=passwordShowString,cursor=_F,font=('TkDefaultFont',14))
passwordShow.bind(_N,showPassword)
passwordShow[_A]=_B
passwordShow.place(x=234,y=121)
cPasswordString=tkinter.StringVar(tk)
cPasswordString.set(_R)
cPasswordLabel=tkinter.ttk.Label(tk,textvariable=cPasswordString)
cPasswordLabel.place(x=20,y=158)
cPasswordLabel[_A]=_B
cPasswordFrame=tkinter.Frame(tk,width=210,height=24)
cPasswordFrame.place(x=20,y=176)
cPasswordFrame.columnconfigure(0,weight=10)
cPasswordFrame.grid_propagate(_C)
cPasswordInput=tkinter.ttk.Entry(cPasswordFrame,show=_H)
cPasswordInput.grid(sticky=_M)
cPasswordInput[_A]=_B
def showStrength():
	global mode
	if mode==_G:return
	A=passwordInput.get();B=any((B.isalpha()for B in A));C=any((B.isdigit()for B in A));D=any((not B.isalnum()for B in A));E=len(A)>8
	if B and C and D and E:passwordStrength.config(width=210);passwordStrength.config(bg='#149414')
	elif B and C and D:passwordStrength.config(width=140);passwordStrength.config(bg='#fada52')
	elif B and C or B and D or C and D:passwordStrength.config(width=90);passwordStrength.config(bg='#ff781f')
	elif not A:passwordStrength.config(width=210);passwordStrength.config(bg=_K)
	else:passwordStrength.config(width=20);passwordStrength.config(bg='#e3242b')
def doPasswordsMatch():
	global mode
	if mode==_G:return
	A=passwordInput.get()==cPasswordInput.get()
	if passwordInput.get()and A:passwordMatchesString.set('✔️');startBtn[_A]=_D;startBtn.config(cursor=_F)
	elif passwordInput.get()and not A:passwordMatchesString.set('❌');startBtn[_A]=_B;startBtn.config(cursor='')
	elif not passwordInput.get():passwordMatchesString.set('');startBtn[_A]=_B;startBtn.config(cursor='')
passwordInput.bind(_Z,lambda e:[showStrength(),doPasswordsMatch()])
cPasswordInput.bind(_Z,lambda e:doPasswordsMatch())
passwordStrength=tkinter.Frame(tk,height=2,width=210)
passwordStrength.config(bg=_K)
passwordStrength.place(x=20,y=146)
passwordMatchesString=tkinter.StringVar(tk)
passwordMatches=tkinter.ttk.Label(tk,textvariable=passwordMatchesString)
passwordMatches.place(x=236,y=180)
metadataString=tkinter.StringVar(tk)
metadataString.set(strings[0])
metadataLabel=tkinter.ttk.Label(tk,textvariable=metadataString)
metadataLabel.place(x=20,y=210)
metadataLabel[_A]=_B
metadataFrame=tkinter.Frame(tk,width=439,height=99)
metadataFrame.place(x=20,y=228)
metadataFrame.columnconfigure(0,weight=10)
metadataFrame.rowconfigure(0,weight=10)
metadataFrame.grid_propagate(_C)
metadataFrame.config(bg=_K)
metadataInput=tkinter.scrolledtext.ScrolledText(metadataFrame,exportselection=0,padx=5,pady=5)
metadataInput.config(font=('Consolas',10))
metadataInput.grid(row=0,column=0,sticky=_M,padx=1,pady=1)
metadataInput.config(borderwidth=0)
metadataInput.config(bg=_S)
metadataInput[_A]=_B
metadataInput.bind('<FocusIn>',lambda e:metadataBoxUI('in'))
metadataInput.bind('<FocusOut>',lambda e:metadataBoxUI('out'))
def metadataBoxUI(what):
	if what=='in':
		if metadataInput.cget('bg')==_Y:metadataFrame.config(bg='#5294e2')
	else:metadataFrame.config(bg='#d8ddea')
keep=tkinter.IntVar(tk)
keepBtn=tkinter.ttk.Checkbutton(tk,text=strings[10],variable=keep,onvalue=1,offvalue=0,command=lambda:dummy.focus())
keepBtn.place(x=17,y=337)
keepBtn[_A]=_B
erase=tkinter.IntVar(tk)
eraseBtn=tkinter.ttk.Checkbutton(tk,text=strings[11],variable=erase,onvalue=1,offvalue=0,command=lambda:dummy.focus())
eraseBtn.place(x=17,y=357)
eraseBtn[_A]=_B
rs=tkinter.IntVar(tk)
rsBtn=tkinter.ttk.Checkbutton(tk,text=strings[15],variable=rs,onvalue=1,offvalue=0,command=lambda:dummy.focus())
rsBtn.place(x=17,y=377)
rsBtn[_A]=_B
rsHelpString=tkinter.StringVar(tk)
rsHelpString.set('(?)')
rsHelp=tkinter.ttk.Label(tk,textvariable=rsHelpString,cursor=_F,font=('Helvetica',7))
rsHelp.place(x=259,y=382)
rsHelpLink='https://en.wikipedia.org/wiki/Reed%E2%80%93Solomon_error_correction'
rsHelp.bind(_N,lambda e:webbrowser.open(rsHelpLink))
startFrame=tkinter.Frame(tk,width=440,height=29)
startFrame.place(x=20,y=410)
startFrame.columnconfigure(0,weight=10)
startFrame.grid_propagate(_C)
startFrame.config(background=_Y)
startBtn=tkinter.ttk.Button(startFrame,text='Start',command=lambda:Thread(target=wrapper,daemon=_E).start())
startBtn.grid(row=0,column=0,stick=_M)
startBtn[_A]=_B
def cancel():global working;working=_C
cancelBtn=tkinter.ttk.Button(startFrame,text='Cancel',command=cancel)
cancelBtn.grid(stick=_M)
cancelBtn.grid(row=0,column=1)
cancelBtn[_A]=_B
progress=tkinter.ttk.Progressbar(tk,orient=tkinter.HORIZONTAL,length=336,mode=_Q)
progress.place(x=30,y=420)
startFrame.lift()
statusString=tkinter.StringVar(tk)
statusString.set(_X)
status=tkinter.ttk.Label(tk,textvariable=statusString)
status.place(x=20,y=448)
hint='Created by Evan Su. Click for details and source.'
creditsString=tkinter.StringVar(tk)
creditsString.set(hint)
creditsLabel=tkinter.ttk.Label(tk,textvariable=creditsString,cursor=_F)
creditsLabel.place(x=20,y=468)
source='https://github.com/HACKERALERT/Picocrypt'
creditsLabel.bind(_N,lambda e:webbrowser.open(source))
creditsLabel[_A]=_B
versionString=tkinter.StringVar(tk)
versionString.set('v1.12')
version=tkinter.ttk.Label(tk,textvariable=versionString)
version[_A]=_B
version.place(x=430,y=468)
prompt=tkinter.Frame(tk)
prompt.config(bg=_W)
promptString=tkinter.StringVar(tk)
promptString.set('Drag and drop file(s) and folder(s) here.')
promptLabel=tkinter.ttk.Label(prompt,textvariable=promptString)
promptLabel.place(x=135,y=311)
promptIconHor=tkinter.Frame(prompt,bg=_a,height=4)
promptIconHor.place(x=208,y=261,width=64)
promptIconVer=tkinter.Frame(prompt,bg=_a,width=4)
promptIconVer.place(x=238,y=231,height=64)
confirmOverwrite=tkinter.Frame(tk)
confirmOverwrite.config(bg=_W)
confirmOverwriteString=tkinter.StringVar(tk)
confirmOverwriteString.set(strings[13])
confirmOverwriteLabel=tkinter.ttk.Label(confirmOverwrite,textvariable=confirmOverwriteString)
confirmOverwriteLabel.place(x=94,y=200)
confirmOverwriteNo=tkinter.ttk.Button(confirmOverwrite,text='No',cursor=_F,command=lambda:confirmOverwrite.pack_forget())
confirmOverwriteNo.place(x=150,y=245)
def overwriteConfirmed():confirmOverwrite.pack_forget();Thread(target=wrapper,daemon=_E,args=(_E,)).start()
confirmOverwriteYes=tkinter.ttk.Button(confirmOverwrite,text='Yes',cursor=_F,command=overwriteConfirmed)
confirmOverwriteYes.place(x=250,y=245)
def filesDragged(draggedFiles):
	global inputFile,rs128,onlyFiles,mode,onlyFolders,allFiles;resetUI();status.config(cursor='');status.bind(_N,lambda e:None)
	try:
		onlyFiles=[];onlyFolders=[];allFiles=[];C='';A=[A for A in draggedFiles];E=[];H=_C
		for B in A:
			if B=='{':H=_E
			elif B=='}':H=_C;E.append(C);C=''
			elif B==' 'and not H:
				if C:E.append(C)
				C=''
			else:C+=B
		if C:E.append(C)
		for B in E:
			if isdir(B):
				onlyFolders.append(B);A=Path(B).rglob('*')
				for L in A:allFiles.append(abspath(L))
			else:onlyFiles.append(B)
		if len(onlyFiles)==1 and not len(allFiles):inputFile=onlyFiles[0];onlyFiles=[]
		else:inputFile=''
		if inputFile.endswith(_L):mode=_G;K=' (will decrypt)';F=open(inputFile,'rb');F.read(129);D=F.read(138);D=bytes(rs128.decode(D)[0]);D=D.replace(_T,b'');I=F.read(int(D.decode(_O)));I=bytes(rs128.decode(I)[0]).decode(_O);metadataString.set('File metadata (read only):');metadataInput[_A]=_D;metadataInput.delete(_U,tkinter.END);metadataInput.insert(_U,I);metadataInput[_A]=_B;F.close();outputFrame.config(width=440);outputInput[_A]=_D;outputInput.delete(0,tkinter.END);outputInput.insert(0,inputFile[:-4]);setDecryptionUI()
		else:
			mode=_I;setEncryptionUI();startBtn[_A]=_B;startBtn.config(cursor='')
			if inputFile:outputInput.insert(0,inputFile)
			else:
				if onlyFiles:A=Path(onlyFiles[0]).parent.absolute()
				else:A=Path(onlyFolders[0]).parent.absolute()
				A=pathJoin(A,'Encrypted.zip');A=A.replace('\\','/');inputFile=A;outputInput.insert(0,A)
			K=' (will encrypt)'
		J=len(onlyFiles);G=len(onlyFolders)
		if(allFiles or onlyFiles)and not onlyFolders:inputString.set(f"{J} files selected (will encrypt).")
		elif onlyFolders and not onlyFiles:inputString.set(f"{G} folder{_V if G!=1 else''} selected (will encrypt).")
		elif onlyFolders and(allFiles or onlyFiles):inputString.set(f"{J} file{_V if J!=1 else''} and "+f"{G} folder{_V if G!=1 else''} selected (will encrypt).")
		else:inputString.set(inputFile.split('/')[-1]+K)
		prompt.pack_forget();statusString.set(_X)
	except UnicodeDecodeError:statusString.set(strings[20])
	except:pass
def onDrop(e):
	global working
	if not working:filesDragged(e.data)
	clearInput[_A]=_D;clearInput.config(cursor=_F)
def onDropEnter(e):prompt.pack(expand=1,fill=tkinter.BOTH);prompt.lift()
def onDropLeave(e):prompt.pack_forget()
tk.drop_target_register(DND_FILES)
tk.dnd_bind('<<Drop>>',onDrop)
tk.dnd_bind('<<DropEnter>>',onDropEnter)
tk.dnd_bind('<<DropLeave>>',onDropLeave)
def work():
	i='modified';h='corrupted';g='badlyCorrupted';f='wb+';a=b'0';global inputFile,outputFile,working,mode,rs13,rs128,reedsolo;global done,stopUpdating,startTime,previousTime,onlyFiles;global onlyFolders,allFiles,reedsoloFixed,reedsoloErrors;disableAllInputs();dummy.focus();D=_C;W=keep.get()==1;b=erase.get()==1;reedsolo=rs.get()==1;working=_E;stopUpdating=_C;I=_C;reedsoloFixed=0;reedsoloErrors=0;c=passwordInput.get().encode(_O);L=metadataInput.get(_U,tkinter.END).encode(_O);cancelBtn[_A]=_D;cancelBtn.config(cursor=_F)
	if mode==_I:outputFile=outputInput.get()+_L
	else:outputFile=outputInput.get()
	progress.config(mode='indeterminate');progress.start(15)
	if onlyFiles or allFiles:
		statusString.set(strings[1]);G=outputFile[:-4]
		if onlyFiles:T=Path(onlyFiles[0]).parent.absolute()
		else:T=Path(dirname(allFiles[0])).parent.absolute()
		d=len(str(T));U=pathJoin(T,G);V=ZipFile(U,'w')
		for E in allFiles:V.write(E,E[d:])
		for E in onlyFiles:V.write(E,pathSplit(E)[1])
		V.close();inputFile=U;outputFile=U+_L;j=dirname(outputFile)
	try:B=open(inputFile,'rb')
	except:setEncryptionUI();statusString.set(strings[16]);return
	if mode==_I:
		J=urandom(16);K=urandom(24);A=open(outputFile,f)
		if reedsolo:A.write(rs128.encode(_T))
		else:A.write(rs128.encode(b'-'))
		L=rs128.encode(L);G=len(L);G=f"{G:+<10}";G=rs128.encode(G.encode(_O));A.write(G);A.write(L);A.write(rs128.encode(J));A.write(rs128.encode(K));A.write(a*192);A.write(a*144);A.write(a*160)
	else:
		G=B.read(129)
		if bytes(rs128.decode(G)[0])==_T:reedsolo=_E
		else:reedsolo=_C
		M=B.read(138);M=bytes(rs128.decode(M)[0]);M=M.replace(_T,b'');B.read(int(M.decode(_O)));J=B.read(144);K=B.read(152);N=B.read(192);O=B.read(144);P=B.read(160)
		try:J,_,C=rs128.decode(J);J=bytes(J);reedsoloFixed+=len(C)
		except:I=_E
		try:K,_,C=rs128.decode(K);K=bytes(K);reedsoloFixed+=len(C)
		except:I=_E
		try:N,_,C=rs128.decode(N);N=bytes(N);reedsoloFixed+=len(C)
		except:I=_E
		try:O,_,C=rs128.decode(O);O=bytes(O);reedsoloFixed+=len(C)
		except:I=_E
		try:P,_,C=rs128.decode(P);P=bytes(P);reedsoloFixed+=len(C)
		except:I=_E
		if I:
			if not W:statusString.set(strings[8]);B.close();A.close();remove(outputFile);setDecryptionUI();return
			else:D=g
	statusString.set(strings[9]);X=hash_secret_raw(c,J,time_cost=8,memory_cost=2**20,parallelism=8,hash_len=32,type=argonType.D);progress.stop();progress.config(mode=_Q);progress[_J]=0;Y=SHA3_512.new(data=X).digest()
	if mode==_G:
		if not compare_digest(Y,N):
			if not I:statusString.set(strings[2]);B.close();setDecryptionUI();return
		A=open(outputFile,f)
	R=blake3();Q=ChaCha20_Poly1305.new(key=X,nonce=K);done=0;e=getsize(inputFile);startTime=datetime.now();previousTime=datetime.now();Thread(target=updateStats,daemon=_E,args=(e,)).start()
	while _E:
		if not working:
			B.close();A.close();remove(outputFile)
			if mode==_I:setEncryptionUI()
			else:setDecryptionUI()
			statusString.set('Operation canceled by user.');dummy.focus();return
		if mode==_G and reedsolo:H=B.read(1104905)
		else:H=B.read(2**20)
		if not H:break
		if mode==_I:
			F=Q.encrypt(H)
			if reedsolo:F=bytes(rs13.encode(F))
			R.update(F)
		else:
			R.update(H)
			if reedsolo:
				try:F,_,C=rs13.decode(H)
				except ReedSolomonError:
					if not reedsoloErrors and not W:statusString.set(strings[4]);B.close();A.close();remove(outputFile);setDecryptionUI();return
					D=g;F=b'';H=H[:-13];S=0
					while _E:
						if S<1104905:F+=H[S:S+242];S+=255
						else:break
					C=bytearray();reedsoloErrors+=1
				reedsoloFixed+=len(C);F=Q.decrypt(F)
			else:F=Q.decrypt(H)
		A.write(F);done+=2**20
	if mode==_I:A.flush();A.close();A=open(outputFile,'r+b');A.seek(129+138+len(L)+144+152);A.write(rs128.encode(Y));A.write(rs128.encode(Q.digest()));A.write(rs128.encode(R.digest()))
	else:
		if not compare_digest(P,R.digest()):
			statusString.set(strings[3]);B.close();A.close()
			if keep.get()!=1:remove(outputFile);setDecryptionUI();return
			elif not D:D=h
		try:Q.verify(O)
		except:
			if not reedsoloErrors and not I:
				statusString.set(strings[5]);B.close();A.close()
				if keep.get()!=1:remove(outputFile);setDecryptionUI();return
				elif not D:D=i
	if not D:A.flush();fsync(A.fileno())
	A.close();B.close();stopUpdating=_E
	if b:
		if onlyFolders:
			for E in onlyFolders:secureWipe(E)
		if onlyFiles:
			for E in range(len(onlyFiles)):statusString.set(strings[12]+f" ({E}/{len(onlyFiles)}");progress[_J]=E/len(onlyFiles);secureWipe(onlyFiles[E])
		secureWipe(inputFile)
	elif allFiles or onlyFiles:remove(inputFile)
	print(D,reedsoloFixed)
	if not D:
		statusString.set(f"Completed. (Click here to show output 🡪)")
		if mode==_G and reedsoloFixed:statusString.set(f"Completed with {reedsoloFixed}"+f" bytes fixed. (Click here to show output 🡪)")
	elif D==i:statusString.set(strings[7])
	elif D==h:statusString.set(strings[6])
	else:statusString.set(strings[8])
	status.config(cursor=_F);Z=''.join([A for A in outputFile])
	if platform.system()==_P:status.bind(_N,lambda e:showOutput(Z.replace('/','\\')))
	else:status.bind(_N,lambda e:showOutput(Z))
	resetUI();inputFile='';outputFile='';allFiles=[];onlyFolders=[];onlyFiles=[];working=_C
def wrapper(yes=_C):
	global working,mode,outputFile
	if mode==_I:outputFile=outputInput.get()+_L
	else:outputFile=outputInput.get()
	try:
		getsize(outputFile)
		if not yes:confirmOverwrite.pack(expand=1,fill=tkinter.BOTH);confirmOverwrite.lift();return
	except:pass
	try:work()
	except:
		if mode==_I:setEncryptionUI()
		else:setDecryptionUI()
		statusString.set(strings[17])
	finally:dummy.focus();working=_C;sys.exit(0)
def updateStats(total):
	C=total;global startTime,previousTime,done,stopUpdating,reedsolo,reedsoloFixed,reedsoloErrors,working
	while _E:
		F=statusString.get().startswith('Working')or statusString.get().startswith('Deriving')
		if not stopUpdating and F and working:
			I=(datetime.now()-previousTime).total_seconds()or 0.0001;G=(datetime.now()-startTime).total_seconds()or 0.0001;previousTime=datetime.now();D=done*100/C;progress[_J]=D;E=done/G/10**6 or 0.0001;A=max(round((C-done)/(E*10**6)),0);A=str(timedelta(seconds=min(A,86399))).zfill(8);B=f"Working... {min(D,100):.0f}% at {E:.2f} MB/s (ETA: {A})"
			if reedsolo and mode==_G and reedsoloFixed:H=_V if reedsoloFixed!=1 else'';B+=f", fixed {reedsoloFixed} error{H}"
			if reedsolo and mode==_G and reedsoloErrors:B+=f", {reedsoloErrors} MB unrecoverable"
			statusString.set(B);sleep(0.05)
		else:sys.exit(0);break
def secureWipe(fin):
	A=fin;statusString.set(strings[12])
	if platform.system()==_P:
		if isdir(A):
			B=[]
			for C in Path(A).rglob('*'):
				if dirname(C)not in B:B.append(dirname(C))
			for C in range(len(B)):statusString.set(strings[12]+f" ({C}/{len(B)})");progress[_J]=100*C/len(B);system(f'cd "{B[C]}" && "{rootDir}/sdelete64.exe" * -p 4 -s -nobanner')
			system(f'cd "{rootDir}"');rmtree(A)
		else:statusString.set(strings[12]);progress[_J]=100;system(f'sdelete64.exe "{A}" -p 4 -nobanner')
	elif platform.system()==_b:system(f'rm -rfP "{A}"')
	else:system(f'shred -uz "{A}" -n 4')
def showOutput(file):
	A=file
	if platform.system()==_P:system(f'explorer /select,"{A}"')
	elif platform.system()==_b:system(f'cd "{dirname(A)}"; open -R "{pathSplit(A)[1]}"');system(f'cd "{rootDir}"')
	else:system(f'xdg-open "{dirname(A)}"')
def resetUI():A='end';global working;working=_C;inputString.set(strings[18]);inputLabel[_A]=_D;clearInput[_A]=_B;clearInput.config(cursor='');outputLabel[_A]=_B;saveAsBtn.config(cursor='');saveAsBtn[_A]=_B;outputFrame.config(width=320);outputInput[_A]=_D;outputInput.delete(0,A);outputInput[_A]=_B;passwordLabel[_A]=_B;passwordInput[_A]=_D;passwordInput.delete(0,A);passwordInput[_A]=_B;passwordInput.config(show=_H);passwordShow[_A]=_B;cPasswordString.set(_R);cPasswordLabel[_A]=_B;cPasswordInput[_A]=_D;cPasswordInput.delete(0,A);cPasswordInput[_A]=_B;cPasswordInput.config(show=_H);passwordStrength.config(width=208);passwordStrength.config(bg=_K);passwordMatchesString.set('');metadataFrame.config(bg=_K);metadataInput.config(bg=_S);metadataInput.config(fg=_c);metadataString.set(strings[0]);metadataLabel[_A]=_B;metadataInput[_A]=_D;metadataInput.delete(_U,tkinter.END);metadataInput[_A]=_B;keep.set(0);keepBtn[_A]=_B;erase.set(0);eraseBtn[_A]=_B;rs.set(0);rsBtn[_A]=_B;startFrame.lift();startBtn[_A]=_B;startBtn.config(cursor='');cancelBtn[_A]=_B;cancelBtn.config(cursor='');progress.stop();progress.config(mode=_Q);progress[_J]=0;dummy.focus()
def setEncryptionUI():global working;working=_C;clearInput[_A]=_D;clearInput.config(cursor=_F);saveAsBtn.config(cursor=_F);saveAsBtn[_A]=_D;outputLabel[_A]=_D;outputInput[_A]=_D;outputFrame.config(width=290);passwordLabel[_A]=_D;passwordInput[_A]=_D;passwordShow[_A]=_D;cPasswordLabel[_A]=_D;cPasswordString.set(_R);cPasswordInput[_A]=_D;metadataFrame.config(bg='#cfd6e6');metadataInput.config(bg=_Y);metadataInput.config(fg=_c);metadataLabel[_A]=_D;metadataInput[_A]=_D;eraseBtn[_A]=_D;rsBtn[_A]=_D;startFrame.lift();startBtn[_A]=_D;startBtn.config(cursor=_F);cancelBtn[_A]=_B;cancelBtn.config(cursor='');progress.stop();progress.config(mode=_Q);progress[_J]=0
def setDecryptionUI():global working;working=_C;clearInput[_A]=_D;clearInput.config(cursor=_F);saveAsBtn.config(cursor=_F);saveAsBtn[_A]=_D;outputLabel[_A]=_D;outputInput[_A]=_D;outputFrame.config(width=320);passwordLabel[_A]=_D;passwordInput[_A]=_D;passwordShow[_A]=_D;cPasswordString.set('Confirm password (N/A):');metadataFrame.config(bg=_K);metadataInput.config(bg=_S);metadataInput.config(fg=_d);metadataString.set(strings[19]);metadataInput[_A]=_B;keepBtn[_A]=_D;startFrame.lift();startBtn[_A]=_D;startBtn.config(cursor=_F);cancelBtn[_A]=_B;cancelBtn.config(cursor='');progress.stop();progress.config(mode=_Q);progress[_J]=0
def disableAllInputs():clearInput[_A]=_B;clearInput.config(cursor='');saveAsBtn.config(cursor='');saveAsBtn[_A]=_B;outputInput[_A]=_B;passwordInput[_A]=_B;passwordInput.config(show=_H);passwordShow[_A]=_B;cPasswordInput[_A]=_B;cPasswordInput.config(show=_H);cPasswordString.set(_R);metadataFrame.config(bg=_K);metadataInput.config(bg=_S);metadataInput.config(fg=_d);metadataInput[_A]=_B;progress.lift();startBtn[_A]=_B;startBtn.config(cursor='');eraseBtn[_A]=_B;keepBtn[_A]=_B;rsBtn[_A]=_B
def onClose():
	global working
	if not working:tk.destroy()
def prepare():
	global rs13,rs128;rs13=RSCodec(13);rs128=RSCodec(128)
	if platform.system()==_P:system('sdelete64.exe /accepteula')
	sys.exit(0)
Thread(target=prepare,daemon=_E).start()
tk.protocol('WM_DELETE_WINDOW',onClose)
tk.mainloop()
sys.exit(0)