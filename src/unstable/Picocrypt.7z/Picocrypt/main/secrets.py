_B='ascii'
_A=None
__all__=['choice','randbelow','randbits','SystemRandom','token_bytes','token_hex','token_urlsafe','compare_digest']
import base64,binascii,os
from hmac import compare_digest
from random import SystemRandom
_sysrand=SystemRandom()
randbits=_sysrand.getrandbits
choice=_sysrand.choice
def randbelow(exclusive_upper_bound):
	A=exclusive_upper_bound
	if A<=0:raise ValueError('Upper bound must be positive.')
	return _sysrand._randbelow(A)
DEFAULT_ENTROPY=32
def token_bytes(nbytes=_A):
	A=nbytes
	if A is _A:A=DEFAULT_ENTROPY
	return os.urandom(A)
def token_hex(nbytes=_A):return binascii.hexlify(token_bytes(nbytes)).decode(_B)
def token_urlsafe(nbytes=_A):A=token_bytes(nbytes);return base64.urlsafe_b64encode(A).rstrip(b'=').decode(_B)