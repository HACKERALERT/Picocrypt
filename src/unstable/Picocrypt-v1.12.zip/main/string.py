_F='Unrecognized named group in pattern'
_E='escaped'
_D='braced'
_C='named'
_B='invalid'
_A=None
__all__=['ascii_letters','ascii_lowercase','ascii_uppercase','capwords','digits','hexdigits','octdigits','printable','punctuation','whitespace','Formatter','Template']
import _string
whitespace=' \t\n\r\x0b\x0c'
ascii_lowercase='abcdefghijklmnopqrstuvwxyz'
ascii_uppercase='ABCDEFGHIJKLMNOPQRSTUVWXYZ'
ascii_letters=ascii_lowercase+ascii_uppercase
digits='0123456789'
hexdigits=digits+'abcdef'+'ABCDEF'
octdigits='01234567'
punctuation='!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
printable=digits+ascii_letters+punctuation+whitespace
def capwords(s,sep=_A):return (sep or' ').join((A.capitalize()for A in s.split(sep)))
import re as _re
from collections import ChainMap as _ChainMap
_sentinel_dict={}
class _TemplateMetaclass(type):
	pattern='\n    %(delim)s(?:\n      (?P<escaped>%(delim)s) |   # Escape sequence of two delimiters\n      (?P<named>%(id)s)      |   # delimiter and a Python identifier\n      {(?P<braced>%(bid)s)}  |   # delimiter and a braced identifier\n      (?P<invalid>)              # Other ill-formed delimiter exprs\n    )\n    '
	def __init__(A,name,bases,dct):
		super(_TemplateMetaclass,A).__init__(name,bases,dct)
		if'pattern'in dct:B=A.pattern
		else:B=_TemplateMetaclass.pattern%{'delim':_re.escape(A.delimiter),'id':A.idpattern,'bid':A.braceidpattern or A.idpattern}
		A.pattern=_re.compile(B,A.flags|_re.VERBOSE)
class Template(metaclass=_TemplateMetaclass):
	delimiter='$';idpattern='(?a:[_a-z][_a-z0-9]*)';braceidpattern=_A;flags=_re.IGNORECASE
	def __init__(A,template):A.template=template
	def _invalid(E,mo):
		B=mo.start(_B);A=E.template[:B].splitlines(keepends=True)
		if not A:C=1;D=1
		else:C=B-len(''.join(A[:-1]));D=len(A)
		raise ValueError('Invalid placeholder in string: line %d, col %d'%(D,C))
	def substitute(A,B=_sentinel_dict,**C):
		if B is _sentinel_dict:B=C
		elif C:B=_ChainMap(C,B)
		def D(mo):
			C=mo;D=C.group(_C)or C.group(_D)
			if D is not _A:return str(B[D])
			if C.group(_E)is not _A:return A.delimiter
			if C.group(_B)is not _A:A._invalid(C)
			raise ValueError(_F,A.pattern)
		return A.pattern.sub(D,A.template)
	def safe_substitute(C,B=_sentinel_dict,**A):
		if B is _sentinel_dict:B=A
		elif A:B=_ChainMap(A,B)
		def D(mo):
			A=mo;D=A.group(_C)or A.group(_D)
			if D is not _A:
				try:return str(B[D])
				except KeyError:return A.group()
			if A.group(_E)is not _A:return C.delimiter
			if A.group(_B)is not _A:return A.group()
			raise ValueError(_F,C.pattern)
		return C.pattern.sub(D,C.template)
class Formatter:
	def format(A,B,*C,**D):return A.vformat(B,C,D)
	def vformat(A,format_string,args,kwargs):B=kwargs;C=set();D,_=A._vformat(format_string,args,B,C,2);A.check_unused_args(C,args,B);return D
	def _vformat(B,format_string,args,kwargs,used_args,recursion_depth,auto_arg_index=0):
		N='cannot switch from manual field specification to automatic field numbering';M=False;I=recursion_depth;H=used_args;G=kwargs;A=auto_arg_index
		if I<0:raise ValueError('Max string recursion exceeded')
		D=[]
		for (J,C,E,K) in B.parse(format_string):
			if J:D.append(J)
			if C is not _A:
				if C=='':
					if A is M:raise ValueError(N)
					C=str(A);A+=1
				elif C.isdigit():
					if A:raise ValueError(N)
					A=M
				F,L=B.get_field(C,args,G);H.add(L);F=B.convert_field(F,K);E,A=B._vformat(E,args,G,H,I-1,auto_arg_index=A);D.append(B.format_field(F,E))
		return ''.join(D),A
	def get_value(B,key,args,kwargs):
		A=key
		if isinstance(A,int):return args[A]
		else:return kwargs[A]
	def check_unused_args(A,used_args,args,kwargs):0
	def format_field(A,value,format_spec):return format(value,format_spec)
	def convert_field(C,value,conversion):
		B=value;A=conversion
		if A is _A:return B
		elif A=='s':return str(B)
		elif A=='r':return repr(B)
		elif A=='a':return ascii(B)
		raise ValueError('Unknown conversion specifier {0!s}'.format(A))
	def parse(A,format_string):return _string.formatter_parser(format_string)
	def get_field(D,field_name,args,kwargs):
		B,E=_string.formatter_field_name_split(field_name);A=D.get_value(B,args,kwargs)
		for (F,C) in E:
			if F:A=getattr(A,C)
			else:A=A[C]
		return A,B