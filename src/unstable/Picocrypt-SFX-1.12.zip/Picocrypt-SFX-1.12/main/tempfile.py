_G='mode'
_F='TMP_MAX'
_E='w+b'
_D='nt'
_C=True
_B=False
_A=None
__all__=['NamedTemporaryFile','TemporaryFile','SpooledTemporaryFile','TemporaryDirectory','mkstemp','mkdtemp','mktemp',_F,'gettempprefix','tempdir','gettempdir','gettempprefixb','gettempdirb']
import functools as _functools,warnings as _warnings,io as _io,os as _os,shutil as _shutil,errno as _errno
from random import Random as _Random
import sys as _sys,weakref as _weakref,_thread
_allocate_lock=_thread.allocate_lock
_text_openflags=_os.O_RDWR|_os.O_CREAT|_os.O_EXCL
if hasattr(_os,'O_NOFOLLOW'):_text_openflags|=_os.O_NOFOLLOW
_bin_openflags=_text_openflags
if hasattr(_os,'O_BINARY'):_bin_openflags|=_os.O_BINARY
if hasattr(_os,_F):TMP_MAX=_os.TMP_MAX
else:TMP_MAX=10000
template='tmp'
_once_lock=_allocate_lock()
def _exists(fn):
	try:_os.lstat(fn)
	except OSError:return _B
	else:return _C
def _infer_return_type(*C):
	D="Can't mix bytes and non-bytes in path components.";A=_A
	for B in C:
		if B is _A:continue
		if isinstance(B,bytes):
			if A is str:raise TypeError(D)
			A=bytes
		else:
			if A is bytes:raise TypeError(D)
			A=str
	if A is _A:return str
	return A
def _sanitize_params(prefix,suffix,dir):
	B=suffix;A=prefix;C=_infer_return_type(A,B,dir)
	if B is _A:B=C()
	if A is _A:
		if C is str:A=template
		else:A=_os.fsencode(template)
	if dir is _A:
		if C is str:dir=gettempdir()
		else:dir=gettempdirb()
	return A,B,dir,C
class _RandomNameSequence:
	characters='abcdefghijklmnopqrstuvwxyz0123456789_'
	@property
	def rng(self):
		A=self;B=_os.getpid()
		if B!=getattr(A,'_rng_pid',_A):A._rng=_Random();A._rng_pid=B
		return A._rng
	def __iter__(A):return A
	def __next__(A):B=A.characters;C=A.rng.choice;D=[C(B)for A in range(8)];return ''.join(D)
def _candidate_tempdir_list():
	A=[]
	for C in ('TMPDIR','TEMP','TMP'):
		B=_os.getenv(C)
		if B:A.append(B)
	if _os.name==_D:A.extend([_os.path.expanduser('~\\AppData\\Local\\Temp'),_os.path.expandvars('%SYSTEMROOT%\\Temp'),'c:\\temp','c:\\tmp','\\temp','\\tmp'])
	else:A.extend(['/tmp','/var/tmp','/usr/tmp'])
	try:A.append(_os.getcwd())
	except (AttributeError,OSError):A.append(_os.curdir)
	return A
def _get_default_tempdir():
	D=_RandomNameSequence();A=_candidate_tempdir_list()
	for dir in A:
		if dir!=_os.curdir:dir=_os.path.abspath(dir)
		for G in range(100):
			E=next(D);B=_os.path.join(dir,E)
			try:
				C=_os.open(B,_bin_openflags,384)
				try:
					try:
						with _io.open(C,'wb',closefd=_B)as F:F.write(b'blat')
					finally:_os.close(C)
				finally:_os.unlink(B)
				return dir
			except FileExistsError:pass
			except PermissionError:
				if _os.name==_D and _os.path.isdir(dir)and _os.access(dir,_os.W_OK):continue
				break
			except OSError:break
	raise FileNotFoundError(_errno.ENOENT,'No usable temporary directory found in %s'%A)
_name_sequence=_A
def _get_candidate_names():
	global _name_sequence
	if _name_sequence is _A:
		_once_lock.acquire()
		try:
			if _name_sequence is _A:_name_sequence=_RandomNameSequence()
		finally:_once_lock.release()
	return _name_sequence
def _mkstemp_inner(dir,pre,suf,flags,output_type):
	A=_get_candidate_names()
	if output_type is bytes:A=map(_os.fsencode,A)
	for E in range(TMP_MAX):
		C=next(A);B=_os.path.join(dir,pre+C+suf);_sys.audit('tempfile.mkstemp',B)
		try:D=_os.open(B,flags,384)
		except FileExistsError:continue
		except PermissionError:
			if _os.name==_D and _os.path.isdir(dir)and _os.access(dir,_os.W_OK):continue
			else:raise
		return D,_os.path.abspath(B)
	raise FileExistsError(_errno.EEXIST,'No usable temporary file name found')
def gettempprefix():return template
def gettempprefixb():return _os.fsencode(gettempprefix())
tempdir=_A
def gettempdir():
	global tempdir
	if tempdir is _A:
		_once_lock.acquire()
		try:
			if tempdir is _A:tempdir=_get_default_tempdir()
		finally:_once_lock.release()
	return tempdir
def gettempdirb():return _os.fsencode(gettempdir())
def mkstemp(suffix=_A,prefix=_A,dir=_A,text=_B):
	B=prefix;A=suffix;B,A,dir,D=_sanitize_params(B,A,dir)
	if text:C=_text_openflags
	else:C=_bin_openflags
	return _mkstemp_inner(dir,B,A,C,D)
def mkdtemp(suffix=_A,prefix=_A,dir=_A):
	B=prefix;A=suffix;B,A,dir,E=_sanitize_params(B,A,dir);C=_get_candidate_names()
	if E is bytes:C=map(_os.fsencode,C)
	for G in range(TMP_MAX):
		F=next(C);D=_os.path.join(dir,B+F+A);_sys.audit('tempfile.mkdtemp',D)
		try:_os.mkdir(D,448)
		except FileExistsError:continue
		except PermissionError:
			if _os.name==_D and _os.path.isdir(dir)and _os.access(dir,_os.W_OK):continue
			else:raise
		return D
	raise FileExistsError(_errno.EEXIST,'No usable temporary directory name found')
def mktemp(suffix='',prefix=template,dir=_A):
	if dir is _A:dir=gettempdir()
	B=_get_candidate_names()
	for D in range(TMP_MAX):
		C=next(B);A=_os.path.join(dir,prefix+C+suffix)
		if not _exists(A):return A
	raise FileExistsError(_errno.EEXIST,'No usable temporary filename found')
class _TemporaryFileCloser:
	file=_A;close_called=_B
	def __init__(A,file,name,delete=_C):A.file=file;A.name=name;A.delete=delete
	if _os.name!=_D:
		def close(A,unlink=_os.unlink):
			if not A.close_called and A.file is not _A:
				A.close_called=_C
				try:A.file.close()
				finally:
					if A.delete:unlink(A.name)
		def __del__(A):A.close()
	else:
		def close(A):
			if not A.close_called:A.close_called=_C;A.file.close()
class _TemporaryFileWrapper:
	def __init__(A,file,name,delete=_C):B=delete;A.file=file;A.name=name;A.delete=B;A._closer=_TemporaryFileCloser(file,name,B)
	def __getattr__(B,name):
		E=B.__dict__['file'];A=getattr(E,name)
		if hasattr(A,'__call__'):
			C=A
			@_functools.wraps(C)
			def D(*A,**B):return C(*A,**B)
			D._closer=B._closer;A=D
		if not isinstance(A,int):setattr(B,name,A)
		return A
	def __enter__(A):A.file.__enter__();return A
	def __exit__(A,exc,value,tb):B=A.file.__exit__(exc,value,tb);A.close();return B
	def close(A):A._closer.close()
	def __iter__(A):
		for B in A.file:yield B
def NamedTemporaryFile(mode=_E,buffering=-1,encoding=_A,newline=_A,suffix=_A,prefix=_A,dir=_A,delete=_C,*,errors=_A):
	C=delete;B=prefix;A=suffix;B,A,dir,G=_sanitize_params(B,A,dir);D=_bin_openflags
	if _os.name==_D and C:D|=_os.O_TEMPORARY
	E,F=_mkstemp_inner(dir,B,A,D,G)
	try:H=_io.open(E,mode,buffering=buffering,newline=newline,encoding=encoding,errors=errors);return _TemporaryFileWrapper(H,F,C)
	except BaseException:_os.unlink(F);_os.close(E);raise
if _os.name!='posix'or _sys.platform=='cygwin':TemporaryFile=NamedTemporaryFile
else:
	_O_TMPFILE_WORKS=hasattr(_os,'O_TMPFILE')
	def TemporaryFile(mode=_E,buffering=-1,encoding=_A,newline=_A,suffix=_A,prefix=_A,dir=_A,*,errors=_A):
		G=errors;F=newline;E=encoding;D=buffering;C=prefix;B=suffix;global _O_TMPFILE_WORKS;C,B,dir,I=_sanitize_params(C,B,dir);H=_bin_openflags
		if _O_TMPFILE_WORKS:
			try:J=(H|_os.O_TMPFILE)&~ _os.O_CREAT;A=_os.open(dir,J,384)
			except IsADirectoryError:_O_TMPFILE_WORKS=_B
			except OSError:pass
			else:
				try:return _io.open(A,mode,buffering=D,newline=F,encoding=E,errors=G)
				except:_os.close(A);raise
		A,K=_mkstemp_inner(dir,C,B,H,I)
		try:_os.unlink(K);return _io.open(A,mode,buffering=D,newline=F,encoding=E,errors=G)
		except:_os.close(A);raise
class SpooledTemporaryFile:
	_rolled=_B
	def __init__(A,max_size=0,mode=_E,buffering=-1,encoding=_A,newline=_A,suffix=_A,prefix=_A,dir=_A,*,errors=_A):
		D=errors;C=newline;B=encoding
		if'b'in mode:A._file=_io.BytesIO()
		else:A._file=_io.TextIOWrapper(_io.BytesIO(),encoding=B,errors=D,newline=C)
		A._max_size=max_size;A._rolled=_B;A._TemporaryFileArgs={_G:mode,'buffering':buffering,'suffix':suffix,'prefix':prefix,'encoding':B,'newline':C,'dir':dir,'errors':D}
	def _check(A,file):
		if A._rolled:return
		B=A._max_size
		if B and file.tell()>B:A.rollover()
	def rollover(A):
		if A._rolled:return
		C=A._file;B=A._file=TemporaryFile(**A._TemporaryFileArgs);del A._TemporaryFileArgs;D=C.tell()
		if hasattr(B,'buffer'):B.buffer.write(C.detach().getvalue())
		else:B.write(C.getvalue())
		B.seek(D,0);A._rolled=_C
	def __enter__(A):
		if A._file.closed:raise ValueError('Cannot enter context with closed file')
		return A
	def __exit__(A,exc,value,tb):A._file.close()
	def __iter__(A):return A._file.__iter__()
	def close(A):A._file.close()
	@property
	def closed(self):return self._file.closed
	@property
	def encoding(self):return self._file.encoding
	@property
	def errors(self):return self._file.errors
	def fileno(A):A.rollover();return A._file.fileno()
	def flush(A):A._file.flush()
	def isatty(A):return A._file.isatty()
	@property
	def mode(self):
		try:return self._file.mode
		except AttributeError:return self._TemporaryFileArgs[_G]
	@property
	def name(self):
		try:return self._file.name
		except AttributeError:return _A
	@property
	def newlines(self):return self._file.newlines
	def read(A,*B):return A._file.read(*B)
	def readline(A,*B):return A._file.readline(*B)
	def readlines(A,*B):return A._file.readlines(*B)
	def seek(A,*B):return A._file.seek(*B)
	@property
	def softspace(self):return self._file.softspace
	def tell(A):return A._file.tell()
	def truncate(A,size=_A):
		B=size
		if B is _A:A._file.truncate()
		else:
			if B>A._max_size:A.rollover()
			A._file.truncate(B)
	def write(A,s):B=A._file;C=B.write(s);A._check(B);return C
	def writelines(A,iterable):B=A._file;C=B.writelines(iterable);A._check(B);return C
class TemporaryDirectory:
	def __init__(A,suffix=_A,prefix=_A,dir=_A):A.name=mkdtemp(suffix,prefix,dir);A._finalizer=_weakref.finalize(A,A._cleanup,A.name,warn_message='Implicitly cleaning up {!r}'.format(A))
	@classmethod
	def _rmtree(D,name):
		def A(func,path,exc_info):
			B=exc_info;A=path
			if issubclass(B[0],PermissionError):
				def C(path):
					try:_os.chflags(path,0)
					except AttributeError:pass
					_os.chmod(path,448)
				try:
					if A!=name:C(_os.path.dirname(A))
					C(A)
					try:_os.unlink(A)
					except (IsADirectoryError,PermissionError):D._rmtree(A)
				except FileNotFoundError:pass
			elif issubclass(B[0],FileNotFoundError):0
			else:raise
		_shutil.rmtree(name,onerror=A)
	@classmethod
	def _cleanup(A,name,warn_message):A._rmtree(name);_warnings.warn(warn_message,ResourceWarning)
	def __repr__(A):return '<{} {!r}>'.format(A.__class__.__name__,A.name)
	def __enter__(A):return A.name
	def __exit__(A,exc,value,tb):A.cleanup()
	def cleanup(A):
		if A._finalizer.detach():A._rmtree(A.name)