_c='osascript'
_b='open location "%s"'
_a='darwin'
_Z='netscape'
_Y='mozilla'
_X='firebird'
_W='seamonkey'
_V='--new-window'
_U=',new-tab'
_T=',new-window'
_S='openURL(%s%action)'
_R='-remote'
_Q='-noraise'
_P='default'
_O='chrome'
_N='%22'
_M='"'
_L='opera'
_K='firefox'
_J='kfm'
_I='konqueror'
_H='kfmclient'
_G='win'
_F='%action'
_E='webbrowser.open'
_D='%s'
_C=False
_B=True
_A=None
import os,shlex,shutil,sys,subprocess,threading
__all__=['Error','open','open_new','open_new_tab','get','register']
class Error(Exception):0
_lock=threading.RLock()
_browsers={}
_tryorder=_A
_os_preferred_browser=_A
def register(name,klass,instance=_A,*,preferred=_C):
	A=name
	with _lock:
		if _tryorder is _A:register_standard_browsers()
		_browsers[A.lower()]=[klass,instance]
		if preferred or _os_preferred_browser and A in _os_preferred_browser:_tryorder.insert(0,A)
		else:_tryorder.append(A)
def get(using=_A):
	C=using
	if _tryorder is _A:
		with _lock:
			if _tryorder is _A:register_standard_browsers()
	if C is not _A:D=[C]
	else:D=_tryorder
	for A in D:
		if _D in A:
			A=shlex.split(A)
			if A[-1]=='&':return BackgroundBrowser(A[:-1])
			else:return GenericBrowser(A)
		else:
			try:B=_browsers[A.lower()]
			except KeyError:B=_synthesize(A)
			if B[1]is not _A:return B[1]
			elif B[0]is not _A:return B[0]()
	raise Error('could not locate runnable browser')
def open(url,new=0,autoraise=_B):
	if _tryorder is _A:
		with _lock:
			if _tryorder is _A:register_standard_browsers()
	for A in _tryorder:
		B=get(A)
		if B.open(url,new,autoraise):return _B
	return _C
def open_new(url):return open(url,1)
def open_new_tab(url):return open(url,2)
def _synthesize(browser,*,preferred=_C):
	B=browser;C=B.split()[0]
	if not shutil.which(C):return[_A,_A]
	D=os.path.basename(C)
	try:E=_browsers[D.lower()]
	except KeyError:return[_A,_A]
	A=E[1]
	if A and D.lower()==A.basename:import copy;A=copy.copy(A);A.name=B;A.basename=os.path.basename(B);register(B,_A,instance=A,preferred=preferred);return[_A,A]
	return[_A,_A]
class BaseBrowser(object):
	args=[_D]
	def __init__(A,name=''):A.name=name;A.basename=name
	def open(A,url,new=0,autoraise=_B):raise NotImplementedError
	def open_new(A,url):return A.open(url,1)
	def open_new_tab(A,url):return A.open(url,2)
class GenericBrowser(BaseBrowser):
	def __init__(A,name):
		B=name
		if isinstance(B,str):A.name=B;A.args=[_D]
		else:A.name=B[0];A.args=B[1:]
		A.basename=os.path.basename(A.name)
	def open(A,url,new=0,autoraise=_B):
		sys.audit(_E,url);B=[A.name]+[B.replace(_D,url)for B in A.args]
		try:
			if sys.platform[:3]==_G:C=subprocess.Popen(B)
			else:C=subprocess.Popen(B,close_fds=_B)
			return not C.wait()
		except OSError:return _C
class BackgroundBrowser(GenericBrowser):
	def open(A,url,new=0,autoraise=_B):
		B=[A.name]+[B.replace(_D,url)for B in A.args];sys.audit(_E,url)
		try:
			if sys.platform[:3]==_G:C=subprocess.Popen(B)
			else:C=subprocess.Popen(B,close_fds=_B,start_new_session=_B)
			return C.poll()is _A
		except OSError:return _C
class UnixBrowser(BaseBrowser):
	raise_opts=_A;background=_C;redirect_stdout=_B;remote_args=[_F,_D];remote_action=_A;remote_action_newwin=_A;remote_action_newtab=_A
	def _invoke(A,args,remote,autoraise,url=_A):
		D=autoraise;C=remote;F=[]
		if C and A.raise_opts:
			D=int(D);G=A.raise_opts[D]
			if G:F=[G]
		H=[A.name]+F+args
		if C or A.background:B=subprocess.DEVNULL
		else:B=_A
		E=subprocess.Popen(H,close_fds=_B,stdin=B,stdout=A.redirect_stdout and B or _A,stderr=B,start_new_session=_B)
		if C:
			try:I=E.wait(5);return not I
			except subprocess.TimeoutExpired:return _B
		elif A.background:
			if E.poll()is _A:return _B
			else:return _C
		else:return not E.wait()
	def open(A,url,new=0,autoraise=_B):
		D=new;C=url;sys.audit(_E,C)
		if D==0:E=A.remote_action
		elif D==1:E=A.remote_action_newwin
		elif D==2:
			if A.remote_action_newtab is _A:E=A.remote_action_newwin
			else:E=A.remote_action_newtab
		else:raise Error("Bad 'new' parameter to open(); "+'expected 0, 1, or 2, got %s'%D)
		B=[B.replace(_D,C).replace(_F,E)for B in A.remote_args];B=[A for A in B if A];F=A._invoke(B,_B,autoraise,C)
		if not F:B=[B.replace(_D,C)for B in A.args];return A._invoke(B,_C,_C)
		else:return _B
class Mozilla(UnixBrowser):remote_args=[_F,_D];remote_action='';remote_action_newwin='-new-window';remote_action_newtab='-new-tab';background=_B
class Netscape(UnixBrowser):raise_opts=[_Q,'-raise'];remote_args=[_R,_S];remote_action='';remote_action_newwin=_T;remote_action_newtab=_U;background=_B
class Galeon(UnixBrowser):raise_opts=[_Q,''];remote_args=[_F,_D];remote_action='-n';remote_action_newwin='-w';background=_B
class Chrome(UnixBrowser):remote_args=[_F,_D];remote_action='';remote_action_newwin=_V;remote_action_newtab='';background=_B
Chromium=Chrome
class Opera(UnixBrowser):remote_args=[_F,_D];remote_action='';remote_action_newwin=_V;remote_action_newtab='';background=_B
class Elinks(UnixBrowser):remote_args=[_R,_S];remote_action='';remote_action_newwin=_T;remote_action_newtab=_U;background=_C;redirect_stdout=_C
class Konqueror(BaseBrowser):
	def open(E,url,new=0,autoraise=_B):
		C=url;sys.audit(_E,C)
		if new==2:D='newTab'
		else:D='openURL'
		A=subprocess.DEVNULL
		try:B=subprocess.Popen([_H,D,C],close_fds=_B,stdin=A,stdout=A,stderr=A)
		except OSError:pass
		else:B.wait();return _B
		try:B=subprocess.Popen([_I,'--silent',C],close_fds=_B,stdin=A,stdout=A,stderr=A,start_new_session=_B)
		except OSError:pass
		else:
			if B.poll()is _A:return _B
		try:B=subprocess.Popen([_J,'-d',C],close_fds=_B,stdin=A,stdout=A,stderr=A,start_new_session=_B)
		except OSError:return _C
		else:return B.poll()is _A
class Grail(BaseBrowser):
	def _find_grail_rc(J):
		import glob as A,pwd,socket as B,tempfile as F;G=os.path.join(F.gettempdir(),'.grail-unix');H=pwd.getpwuid(os.getuid())[0];I=os.path.join(A.escape(G),A.escape(H)+'-*');C=A.glob(I)
		if not C:return _A
		D=B.socket(B.AF_UNIX,B.SOCK_STREAM)
		for E in C:
			try:D.connect(E)
			except OSError:
				try:os.unlink(E)
				except OSError:pass
			else:return D
	def _remote(B,action):
		A=B._find_grail_rc()
		if not A:return 0
		A.send(action);A.close();return 1
	def open(B,url,new=0,autoraise=_B):
		A=url;sys.audit(_E,A)
		if new:C=B._remote('LOADNEW '+A)
		else:C=B._remote('LOAD '+A)
		return C
def register_X_browsers():
	I='grail';H='GNOME_DESKTOP_SESSION_ID';G='mosaic';F='skipstone';E='x-www-browser';D='gnome-open';C='gvfs-open';B='xdg-open'
	if shutil.which(B):register(B,_A,BackgroundBrowser(B))
	if H in os.environ and shutil.which(C):register(C,_A,BackgroundBrowser(C))
	if H in os.environ and shutil.which(D):register(D,_A,BackgroundBrowser(D))
	if'KDE_FULL_SESSION'in os.environ and shutil.which(_H):register(_H,Konqueror,Konqueror(_H))
	if shutil.which(E):register(E,_A,BackgroundBrowser(E))
	for A in (_K,'iceweasel','iceape',_W):
		if shutil.which(A):register(A,_A,Mozilla(A))
	for A in ('mozilla-firefox','mozilla-firebird',_X,_Y,_Z):
		if shutil.which(A):register(A,_A,Netscape(A))
	if shutil.which(_J):register(_J,Konqueror,Konqueror(_J))
	elif shutil.which(_I):register(_I,Konqueror,Konqueror(_I))
	for A in ('galeon','epiphany'):
		if shutil.which(A):register(A,_A,Galeon(A))
	if shutil.which(F):register(F,_A,BackgroundBrowser(F))
	for A in ('google-chrome',_O,'chromium','chromium-browser'):
		if shutil.which(A):register(A,_A,Chrome(A))
	if shutil.which(_L):register(_L,_A,Opera(_L))
	if shutil.which(G):register(G,_A,BackgroundBrowser(G))
	if shutil.which(I):register(I,Grail,_A)
def register_standard_browsers():
	N='BROWSER';M='safari';I='w3m';H='lynx';G='elinks';F='links';E='www-browser';global _tryorder;_tryorder=[]
	if sys.platform==_a:register('MacOSX',_A,MacOSXOSAScript(_P));register(_O,_A,MacOSXOSAScript(_O));register(_K,_A,MacOSXOSAScript(_K));register(M,_A,MacOSXOSAScript(M))
	if sys.platform[:3]==_G:
		register('windows-default',WindowsDefault);J=os.path.join(os.environ.get('PROGRAMFILES','C:\\Program Files'),'Internet Explorer\\IEXPLORE.EXE')
		for B in (_K,_X,_W,_Y,_Z,_L,J):
			if shutil.which(B):register(B,_A,BackgroundBrowser(B))
	else:
		if os.environ.get('DISPLAY')or os.environ.get('WAYLAND_DISPLAY'):
			try:C='xdg-settings get default-web-browser'.split();K=subprocess.check_output(C,stderr=subprocess.DEVNULL);L=K.decode().strip()
			except (FileNotFoundError,subprocess.CalledProcessError,PermissionError,NotADirectoryError):pass
			else:global _os_preferred_browser;_os_preferred_browser=L
			register_X_browsers()
		if os.environ.get('TERM'):
			if shutil.which(E):register(E,_A,GenericBrowser(E))
			if shutil.which(F):register(F,_A,GenericBrowser(F))
			if shutil.which(G):register(G,_A,Elinks(G))
			if shutil.which(H):register(H,_A,GenericBrowser(H))
			if shutil.which(I):register(I,_A,GenericBrowser(I))
	if N in os.environ:
		D=os.environ[N].split(os.pathsep);D.reverse()
		for A in D:
			if A!='':
				C=_synthesize(A,preferred=_B)
				if C[1]is _A:register(A,_A,GenericBrowser(A),preferred=_B)
if sys.platform[:3]==_G:
	class WindowsDefault(BaseBrowser):
		def open(A,url,new=0,autoraise=_B):
			sys.audit(_E,url)
			try:os.startfile(url)
			except OSError:return _C
			else:return _B
if sys.platform==_a:
	class MacOSX(BaseBrowser):
		def __init__(A,name):A.name=name
		def open(B,url,new=0,autoraise=_B):
			C=new;A=url;sys.audit(_E,A);assert"'"not in A
			if not':'in A:A='file:'+A
			C=int(bool(C))
			if B.name==_P:E=_b%A.replace(_M,_N)
			else:
				if B.name=='OmniWeb':F=''
				else:F='toWindow %d'%(C-1)
				G='OpenURL "%s"'%A.replace(_M,_N);E='tell application "%s"\n                                activate\n                                %s %s\n                            end tell'%(B.name,G,F)
			D=os.popen(_c,'w')
			if D is _A:return _C
			D.write(E);H=D.close();return not H
	class MacOSXOSAScript(BaseBrowser):
		def __init__(A,name):A._name=name
		def open(B,url,new=0,autoraise=_B):
			if B._name==_P:C=_b%url.replace(_M,_N)
			else:C='\n                   tell application "%s"\n                       activate\n                       open location "%s"\n                   end\n                   '%(B._name,url.replace(_M,_N))
			A=os.popen(_c,'w')
			if A is _A:return _C
			A.write(C);D=A.close();return not D
def main():
	import getopt as B;C='Usage: %s [-n | -t] url\n    -n: open new window\n    -t: open new tab'%sys.argv[0]
	try:F,D=B.getopt(sys.argv[1:],'ntd')
	except B.error as G:print(G,file=sys.stderr);print(C,file=sys.stderr);sys.exit(1)
	A=0
	for (E,I) in F:
		if E=='-n':A=1
		elif E=='-t':A=2
	if len(D)!=1:print(C,file=sys.stderr);sys.exit(1)
	H=D[0];open(H,A);print('\x07')
if __name__=='__main__':main()