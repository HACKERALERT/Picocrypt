_C='{*}'
_B='*'
_A=None
import re
xpath_tokenizer_re=re.compile('(\'[^\']*\'|\\"[^\\"]*\\"|::|//?|\\.\\.|\\(\\)|[/.*:\\[\\]\\(\\)@=])|((?:\\{[^}]+\\})?[^/\\[\\]\\(\\)@=\\s]+)|\\s+')
def xpath_tokenizer(pattern,namespaces=_A):
	K='{%s}%s';J=':';I=False;B=namespaces;F=B.get('')if B else _A;C=I
	for D in xpath_tokenizer_re.findall(pattern):
		E,A=D
		if A and A[0]!='{':
			if J in A:
				G,H=A.split(J,1)
				try:
					if not B:raise KeyError
					yield(E,K%(B[G],H))
				except KeyError:raise SyntaxError('prefix %r not found in prefix map'%G) from _A
			elif F and not C:yield(E,K%(F,A))
			else:yield D
			C=I
		else:yield D;C=E=='@'
def get_parent_map(context):
	B=context;A=B.parent_map
	if A is _A:
		B.parent_map=A={}
		for C in B.root.iter():
			for D in C:A[D]=C
	return A
def _is_wildcard_tag(tag):return tag[:3]==_C or tag[-2:]=='}*'
def _prepare_tag(tag):
	A=tag;B,C=isinstance,str
	if A=='{*}*':
		def D(context,result):
			for A in result:
				if B(A.tag,C):yield A
	elif A=='{}*':
		def D(context,result):
			for A in result:
				D=A.tag
				if B(D,C)and D[0]!='{':yield A
	elif A[:3]==_C:
		E=A[2:];G=slice(-len(E),_A);A=A[3:]
		def D(context,result):
			for F in result:
				D=F.tag
				if D==A or B(D,C)and D[G]==E:yield F
	elif A[-2:]=='}*':
		F=A[:-1];H=slice(_A,len(F))
		def D(context,result):
			for A in result:
				D=A.tag
				if B(D,C)and D[H]==F:yield A
	else:raise RuntimeError(f"internal parser error, got {A}")
	return D
def prepare_child(next,token):
	A=token[1]
	if _is_wildcard_tag(A):
		C=_prepare_tag(A)
		def B(context,result):
			def A(result):
				for A in result:yield from A
			return C(context,A(result))
	else:
		if A[:2]=='{}':A=A[2:]
		def B(context,result):
			for C in result:
				for B in C:
					if B.tag==A:yield B
	return B
def prepare_star(next,token):
	def A(context,result):
		for A in result:yield from A
	return A
def prepare_self(next,token):
	def A(context,result):yield from result
	return A
def prepare_descendant(next,token):
	B=token
	try:B=next()
	except StopIteration:return
	if B[0]==_B:A=_B
	elif not B[0]:A=B[1]
	else:raise SyntaxError('invalid descendant')
	if _is_wildcard_tag(A):
		D=_prepare_tag(A)
		def C(context,result):
			def A(result):
				for A in result:
					for B in A.iter():
						if B is not A:yield B
			return D(context,A(result))
	else:
		if A[:2]=='{}':A=A[2:]
		def C(context,result):
			for B in result:
				for C in B.iter(A):
					if C is not B:yield C
	return C
def prepare_parent(next,token):
	def A(context,result):
		B=get_parent_map(context);C={}
		for D in result:
			if D in B:
				A=B[D]
				if A not in C:C[A]=_A;yield A
	return A
def prepare_predicate(next,token):
	K='-()-';J='\\-?\\d+$';I='-';D=token;A=[];B=[]
	while 1:
		try:D=next()
		except StopIteration:return
		if D[0]==']':break
		if D==('',''):continue
		if D[0]and D[0][:1]in'\'"':D="'",D[0][1:-1]
		A.append(D[0]or I);B.append(D[1])
	A=''.join(A)
	if A=='@-':
		H=B[1]
		def C(context,result):
			for A in result:
				if A.get(H)is not _A:yield A
		return C
	if A=="@-='":
		H=B[1];F=B[-1]
		def C(context,result):
			for A in result:
				if A.get(H)==F:yield A
		return C
	if A==I and not re.match(J,B[0]):
		G=B[0]
		def C(context,result):
			for A in result:
				if A.find(G)is not _A:yield A
		return C
	if A==".='"or A=="-='"and not re.match(J,B[0]):
		G=B[0];F=B[-1]
		if G:
			def C(context,result):
				for A in result:
					for B in A.findall(G):
						if ''.join(B.itertext())==F:yield A;break
		else:
			def C(context,result):
				for A in result:
					if ''.join(A.itertext())==F:yield A
		return C
	if A==I or A=='-()'or A==K:
		if A==I:
			E=int(B[0])-1
			if E<0:raise SyntaxError('XPath position >= 1 expected')
		else:
			if B[0]!='last':raise SyntaxError('unsupported function')
			if A==K:
				try:E=int(B[2])-1
				except ValueError:raise SyntaxError('unsupported expression')
				if E>-2:raise SyntaxError('XPath offset from last() must be negative')
			else:E=-1
		def C(context,result):
			B=get_parent_map(context)
			for A in result:
				try:
					C=B[A];D=list(C.findall(A.tag))
					if D[E]is A:yield A
				except (IndexError,KeyError):pass
		return C
	raise SyntaxError('invalid predicate')
ops={'':prepare_child,_B:prepare_star,'.':prepare_self,'..':prepare_parent,'//':prepare_descendant,'[':prepare_predicate}
_cache={}
class _SelectorContext:
	parent_map=_A
	def __init__(A,root):A.root=root
def iterfind(elem,path,namespaces=_A):
	G='/';D=namespaces;A=path
	if A[-1:]==G:A=A+_B
	E=A,
	if D:E+=tuple(sorted(D.items()))
	try:C=_cache[E]
	except KeyError:
		if len(_cache)>100:_cache.clear()
		if A[:1]==G:raise SyntaxError('cannot use absolute path on element')
		next=iter(xpath_tokenizer(A,D)).__next__
		try:B=next()
		except StopIteration:return
		C=[]
		while 1:
			try:C.append(ops[B[0]](next,B))
			except StopIteration:raise SyntaxError('invalid path') from _A
			try:
				B=next()
				if B[0]==G:B=next()
			except StopIteration:break
		_cache[E]=C
	F=[elem];H=_SelectorContext(elem)
	for I in C:F=I(H,F)
	return F
def find(elem,path,namespaces=_A):return next(iterfind(elem,path,namespaces),_A)
def findall(elem,path,namespaces=_A):return list(iterfind(elem,path,namespaces))
def findtext(elem,path,default=_A,namespaces=_A):
	A=elem
	try:A=next(iterfind(A,path,namespaces));return A.text or''
	except StopIteration:return default