_B='lo must be non-negative'
_A=None
def insort_right(a,x,lo=0,hi=_A):lo=bisect_right(a,x,lo,hi);a.insert(lo,x)
def bisect_right(a,x,lo=0,hi=_A):
	if lo<0:raise ValueError(_B)
	if hi is _A:hi=len(a)
	while lo<hi:
		mid=(lo+hi)//2
		if x<a[mid]:hi=mid
		else:lo=mid+1
	return lo
def insort_left(a,x,lo=0,hi=_A):lo=bisect_left(a,x,lo,hi);a.insert(lo,x)
def bisect_left(a,x,lo=0,hi=_A):
	if lo<0:raise ValueError(_B)
	if hi is _A:hi=len(a)
	while lo<hi:
		mid=(lo+hi)//2
		if a[mid]<x:lo=mid+1
		else:hi=mid
	return lo
try:from _bisect import *
except ImportError:pass
bisect=bisect_right
insort=insort_right