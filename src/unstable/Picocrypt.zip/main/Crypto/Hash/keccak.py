_C='digest_bits'
_B=False
_A='digest_bytes'
from Crypto.Util.py3compat import bord
from Crypto.Util._raw_api import load_pycryptodome_raw_lib,VoidPointer,SmartPointer,create_string_buffer,get_raw_buffer,c_size_t,c_uint8_ptr
_raw_keccak_lib=load_pycryptodome_raw_lib('Crypto.Hash._keccak','\n                        int keccak_init(void **state,\n                                        size_t capacity_bytes,\n                                        uint8_t padding_byte);\n                        int keccak_destroy(void *state);\n                        int keccak_absorb(void *state,\n                                          const uint8_t *in,\n                                          size_t len);\n                        int keccak_squeeze(const void *state,\n                                           uint8_t *out,\n                                           size_t len);\n                        int keccak_digest(void *state, uint8_t *digest, size_t len);\n                        ')
class Keccak_Hash:
	def __init__(A,data,digest_bytes,update_after_digest):
		A.digest_size=digest_bytes;A._update_after_digest=update_after_digest;A._digest_done=_B;B=VoidPointer();C=_raw_keccak_lib.keccak_init(B.address_of(),c_size_t(A.digest_size*2),1)
		if C:raise ValueError('Error %d while instantiating keccak'%C)
		A._state=SmartPointer(B.get(),_raw_keccak_lib.keccak_destroy)
		if data:A.update(data)
	def update(A,data):
		if A._digest_done and not A._update_after_digest:raise TypeError("You can only call 'digest' or 'hexdigest' on this object")
		B=_raw_keccak_lib.keccak_absorb(A._state.get(),c_uint8_ptr(data),c_size_t(len(data)))
		if B:raise ValueError('Error %d while updating keccak'%B)
		return A
	def digest(A):
		A._digest_done=True;B=create_string_buffer(A.digest_size);C=_raw_keccak_lib.keccak_digest(A._state.get(),B,c_size_t(A.digest_size))
		if C:raise ValueError('Error %d while squeezing keccak'%C)
		return get_raw_buffer(B)
	def hexdigest(A):return ''.join(['%02x'%bord(B)for B in A.digest()])
	def new(B,**A):
		if _A not in A and _C not in A:A[_A]=B.digest_size
		return new(**A)
def new(**A):
	C=None;E=A.pop('data',C);F=A.pop('update_after_digest',_B);B=A.pop(_A,C);D=A.pop(_C,C)
	if C not in(B,D):raise TypeError('Only one digest parameter must be provided')
	if(C,C)==(B,D):raise TypeError('Digest size (bits, bytes) not provided')
	if B is not C:
		if B not in(28,32,48,64):raise ValueError("'digest_bytes' must be: 28, 32, 48 or 64")
	else:
		if D not in(224,256,384,512):raise ValueError("'digest_bytes' must be: 224, 256, 384 or 512")
		B=D//8
	if A:raise TypeError('Unknown parameters: '+str(A))
	return Keccak_Hash(E,B,F)