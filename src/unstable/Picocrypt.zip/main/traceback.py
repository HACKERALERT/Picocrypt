_D='    {}\n'
_C=False
_B=True
_A=None
import collections,itertools,linecache,sys
__all__=['extract_stack','extract_tb','format_exception','format_exception_only','format_list','format_stack','format_tb','print_exc','format_exc','print_exception','print_last','print_stack','print_tb','clear_frames','FrameSummary','StackSummary','TracebackException','walk_stack','walk_tb']
def print_list(extracted_list,file=_A):
	A=file
	if A is _A:A=sys.stderr
	for B in StackSummary.from_list(extracted_list).format():print(B,file=A,end='')
def format_list(extracted_list):return StackSummary.from_list(extracted_list).format()
def print_tb(tb,limit=_A,file=_A):print_list(extract_tb(tb,limit=limit),file=file)
def format_tb(tb,limit=_A):return extract_tb(tb,limit=limit).format()
def extract_tb(tb,limit=_A):return StackSummary.extract(walk_tb(tb),limit=limit)
_cause_message='\nThe above exception was the direct cause of the following exception:\n\n'
_context_message='\nDuring handling of the above exception, another exception occurred:\n\n'
def print_exception(etype,value,tb,limit=_A,file=_A,chain=_B):
	B=value;A=file
	if A is _A:A=sys.stderr
	for C in TracebackException(type(B),B,tb,limit=limit).format(chain=chain):print(C,file=A,end='')
def format_exception(etype,value,tb,limit=_A,chain=_B):A=value;return list(TracebackException(type(A),A,tb,limit=limit).format(chain=chain))
def format_exception_only(etype,value):return list(TracebackException(etype,value,_A).format_exception_only())
def _format_final_exc_line(etype,value):
	B=value;A=etype;C=_some_str(B)
	if B is _A or not C:D='%s\n'%A
	else:D='%s: %s\n'%(A,C)
	return D
def _some_str(value):
	A=value
	try:return str(A)
	except:return'<unprintable %s object>'%type(A).__name__
def print_exc(limit=_A,file=_A,chain=_B):print_exception(*sys.exc_info(),limit=limit,file=file,chain=chain)
def format_exc(limit=_A,chain=_B):return ''.join(format_exception(*sys.exc_info(),limit=limit,chain=chain))
def print_last(limit=_A,file=_A,chain=_B):
	if not hasattr(sys,'last_type'):raise ValueError('no last exception')
	print_exception(sys.last_type,sys.last_value,sys.last_traceback,limit,file,chain)
def print_stack(f=_A,limit=_A,file=_A):
	if f is _A:f=sys._getframe().f_back
	print_list(extract_stack(f,limit=limit),file=file)
def format_stack(f=_A,limit=_A):
	if f is _A:f=sys._getframe().f_back
	return format_list(extract_stack(f,limit=limit))
def extract_stack(f=_A,limit=_A):
	if f is _A:f=sys._getframe().f_back
	A=StackSummary.extract(walk_stack(f),limit=limit);A.reverse();return A
def clear_frames(tb):
	while tb is not _A:
		try:tb.tb_frame.clear()
		except RuntimeError:pass
		tb=tb.tb_next
class FrameSummary:
	__slots__='filename','lineno','name','_line','locals'
	def __init__(A,filename,lineno,name,*,lookup_line=_B,locals=_A,line=_A):
		A.filename=filename;A.lineno=lineno;A.name=name;A._line=line
		if lookup_line:A.line
		A.locals={A:repr(B)for(A,B)in locals.items()}if locals else _A
	def __eq__(A,other):
		B=other
		if isinstance(B,FrameSummary):return A.filename==B.filename and A.lineno==B.lineno and A.name==B.name and A.locals==B.locals
		if isinstance(B,tuple):return(A.filename,A.lineno,A.name,A.line)==B
		return NotImplemented
	def __getitem__(A,pos):return(A.filename,A.lineno,A.name,A.line)[pos]
	def __iter__(A):return iter([A.filename,A.lineno,A.name,A.line])
	def __repr__(A):return '<FrameSummary file {filename}, line {lineno} in {name}>'.format(filename=A.filename,lineno=A.lineno,name=A.name)
	def __len__(A):return 4
	@property
	def line(self):
		A=self
		if A._line is _A:A._line=linecache.getline(A.filename,A.lineno).strip()
		return A._line
def walk_stack(f):
	if f is _A:f=sys._getframe().f_back.f_back
	while f is not _A:yield(f,f.f_lineno);f=f.f_back
def walk_tb(tb):
	A=tb
	while A is not _A:yield(A.tb_frame,A.tb_lineno);A=A.tb_next
_RECURSIVE_CUTOFF=3
class StackSummary(list):
	@classmethod
	def extract(I,frame_gen,*,limit=_A,lookup_lines=_B,capture_locals=_C):
		B=frame_gen;A=limit
		if A is _A:
			A=getattr(sys,'tracebacklimit',_A)
			if A is not _A and A<0:A=0
		if A is not _A:
			if A>=0:B=itertools.islice(B,A)
			else:B=collections.deque(B,maxlen=-A)
		E=I();F=set()
		for (C,J) in B:
			G=C.f_code;D=G.co_filename;K=G.co_name;F.add(D);linecache.lazycache(D,C.f_globals)
			if capture_locals:H=C.f_locals
			else:H=_A
			E.append(FrameSummary(D,J,K,lookup_line=_C,locals=H))
		for D in F:linecache.checkcache(D)
		if lookup_lines:
			for C in E:C.line
		return E
	@classmethod
	def from_list(G,a_list):
		A=StackSummary()
		for B in a_list:
			if isinstance(B,FrameSummary):A.append(B)
			else:C,D,E,F=B;A.append(FrameSummary(C,D,E,line=F))
		return A
	def format(H):
		K='s';C=[];E=_A;F=_A;G=_A;B=0
		for A in H:
			if E is _A or E!=A.filename or F is _A or F!=A.lineno or G is _A or G!=A.name:
				if B>_RECURSIVE_CUTOFF:B-=_RECURSIVE_CUTOFF;C.append(f"  [Previous line repeated {B} more time{K if B>1 else''}]\n")
				E=A.filename;F=A.lineno;G=A.name;B=0
			B+=1
			if B>_RECURSIVE_CUTOFF:continue
			D=[];D.append('  File "{}", line {}, in {}\n'.format(A.filename,A.lineno,A.name))
			if A.line:D.append(_D.format(A.line.strip()))
			if A.locals:
				for (I,J) in sorted(A.locals.items()):D.append('    {name} = {value}\n'.format(name=I,value=J))
			C.append(''.join(D))
		if B>_RECURSIVE_CUTOFF:B-=_RECURSIVE_CUTOFF;C.append(f"  [Previous line repeated {B} more time{K if B>1 else''}]\n")
		return C
class TracebackException:
	def __init__(B,exc_type,exc_value,exc_traceback,*,limit=_A,lookup_lines=_B,capture_locals=_C,_seen=_A):
		G=lookup_lines;F=capture_locals;E=limit;D=exc_type;C=_seen;A=exc_value
		if C is _A:C=set()
		C.add(id(A))
		if A and A.__cause__ is not _A and id(A.__cause__)not in C:H=TracebackException(type(A.__cause__),A.__cause__,A.__cause__.__traceback__,limit=E,lookup_lines=_C,capture_locals=F,_seen=C)
		else:H=_A
		if A and A.__context__ is not _A and id(A.__context__)not in C:I=TracebackException(type(A.__context__),A.__context__,A.__context__.__traceback__,limit=E,lookup_lines=_C,capture_locals=F,_seen=C)
		else:I=_A
		B.__cause__=H;B.__context__=I;B.__suppress_context__=A.__suppress_context__ if A else _C;B.stack=StackSummary.extract(walk_tb(exc_traceback),limit=E,lookup_lines=G,capture_locals=F);B.exc_type=D;B._str=_some_str(A)
		if D and issubclass(D,SyntaxError):B.filename=A.filename;B.lineno=str(A.lineno);B.text=A.text;B.offset=A.offset;B.msg=A.msg
		if G:B._load_lines()
	@classmethod
	def from_exception(B,exc,*C,**D):A=exc;return B(type(A),A,A.__traceback__,*C,**D)
	def _load_lines(A):
		for B in A.stack:B.line
		if A.__context__:A.__context__._load_lines()
		if A.__cause__:A.__cause__._load_lines()
	def __eq__(A,other):return A.__dict__==other.__dict__
	def __str__(A):return A._str
	def format_exception_only(A):
		if A.exc_type is _A:yield _format_final_exc_line(_A,A._str);return
		C=A.exc_type.__qualname__;F=A.exc_type.__module__
		if F not in('__main__','builtins'):C=F+'.'+C
		if not issubclass(A.exc_type,SyntaxError):yield _format_final_exc_line(C,A._str);return
		G=A.filename or'<string>';H=str(A.lineno)or'?';yield '  File "{}", line {}\n'.format(G,H);E=A.text;D=A.offset
		if E is not _A:
			yield _D.format(E.strip())
			if D is not _A:B=E.rstrip('\n');D=min(len(B),D)-1;B=B[:D].lstrip();B=(A.isspace()and A or' 'for A in B);yield '    {}^\n'.format(''.join(B))
		I=A.msg or'<no detail available>';yield '{}: {}\n'.format(C,I)
	def format(A,*,chain=_B):
		B=chain
		if B:
			if A.__cause__ is not _A:yield from A.__cause__.format(chain=B);yield _cause_message
			elif A.__context__ is not _A and not A.__suppress_context__:yield from A.__context__.format(chain=B);yield _context_message
		if A.stack:yield'Traceback (most recent call last):\n';yield from A.stack.format()
		yield from A.format_exception_only()