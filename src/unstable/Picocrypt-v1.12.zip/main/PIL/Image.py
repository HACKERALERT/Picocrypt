_A7=b'Exif\x00\x00'
_A6=' Use '
_A5='Image.HAMMING'
_A4='Image.BOX'
_A3='Image.BICUBIC'
_A2='Image.BILINEAR'
_A1='Image.NEAREST'
_A0='{} ({})'
_z='RGBa'
_y='typestr'
_x='shape'
_w='_close__fp'
_v='>i4'
_u='>u4'
_t='>i2'
_s='>u2'
_r='|b1'
_q='I;32BS'
_p='I;32S'
_o='I;32B'
_n='I;32'
_m='I;16BS'
_l='I;16S'
_k='I;16L'
_j='HSV'
_i='LAB'
_h='YCbCr'
_g='Image categories are deprecated and will be removed in Pillow 10 (2023-01-02). Use is_animated instead.'
_f='_internal_pillow'
_e='__mul__'
_d='__add__'
_c='<i4'
_b='<u4'
_a='<i2'
_Z='<u2'
_Y='I;16B'
_X='CMYK'
_W='RGBX'
_V='PILLOW_VERSION'
_U='Qt bindings are not installed'
_T='illegal image mode'
_S=0.0
_R='I;16'
_Q='PA'
_P=1.0
_O=False
_N='raw'
_M=True
_L='LA'
_K='1'
_J='F'
_I='|u1'
_H='I'
_G='transparency'
_F='RGBA'
_D='RGB'
_C='L'
_B='P'
_A=None
import atexit,builtins,io,logging,math,numbers,os,struct,sys,tempfile,warnings,xml.etree.ElementTree
from collections.abc import Callable,MutableMapping
from pathlib import Path
from .  import ImageMode,TiffTags,UnidentifiedImageError,__version__,_plugins,_raise_version_warning
from ._binary import i32le
from ._util import deferred_error,isPath
if sys.version_info>=(3,7):
	def __getattr__(name):
		if name==_V:_raise_version_warning();return __version__
		else:
			categories={'NORMAL':0,'SEQUENCE':1,'CONTAINER':2}
			if name in categories:warnings.warn(_g,DeprecationWarning,stacklevel=2);return categories[name]
		raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
else:from .  import PILLOW_VERSION;assert PILLOW_VERSION;NORMAL=0;SEQUENCE=1;CONTAINER=2
logger=logging.getLogger(__name__)
class DecompressionBombWarning(RuntimeWarning):0
class DecompressionBombError(Exception):0
MAX_IMAGE_PIXELS=int(1024*1024*1024//4//3)
try:
	from .  import _imaging as core
	if __version__!=getattr(core,_V,_A):raise ImportError(f"The _imaging extension was built for another version of Pillow or PIL:\nCore version: {getattr(core,_V,_A)}\nPillow version: {__version__}")
except ImportError as v:
	core=deferred_error(ImportError('The _imaging C module is not installed.'))
	if str(v).startswith('Module use of python'):warnings.warn('The _imaging extension was built for another version of Python.',RuntimeWarning)
	elif str(v).startswith('The _imaging extension'):warnings.warn(str(v),RuntimeWarning)
	raise
USE_CFFI_ACCESS=hasattr(sys,'pypy_version_info')
try:import cffi
except ImportError:cffi=_A
def isImageType(t):return hasattr(t,'im')
NONE=0
FLIP_LEFT_RIGHT=0
FLIP_TOP_BOTTOM=1
ROTATE_90=2
ROTATE_180=3
ROTATE_270=4
TRANSPOSE=5
TRANSVERSE=6
AFFINE=0
EXTENT=1
PERSPECTIVE=2
QUAD=3
MESH=4
NEAREST=NONE=0
BOX=4
BILINEAR=LINEAR=2
HAMMING=5
BICUBIC=CUBIC=3
LANCZOS=ANTIALIAS=1
_filters_support={BOX:0.5,BILINEAR:_P,HAMMING:_P,BICUBIC:2.0,LANCZOS:3.0}
NEAREST=NONE=0
ORDERED=1
RASTERIZE=2
FLOYDSTEINBERG=3
WEB=0
ADAPTIVE=1
MEDIANCUT=0
MAXCOVERAGE=1
FASTOCTREE=2
LIBIMAGEQUANT=3
if hasattr(core,'DEFAULT_STRATEGY'):DEFAULT_STRATEGY=core.DEFAULT_STRATEGY;FILTERED=core.FILTERED;HUFFMAN_ONLY=core.HUFFMAN_ONLY;RLE=core.RLE;FIXED=core.FIXED
ID=[]
OPEN={}
MIME={}
SAVE={}
SAVE_ALL={}
EXTENSION={}
DECODERS={}
ENCODERS={}
if sys.byteorder=='little':_ENDIAN='<'
else:_ENDIAN='>'
_MODE_CONV={_K:(_r,_A),_C:(_I,_A),_L:(_I,2),_H:(_ENDIAN+'i4',_A),_J:(_ENDIAN+'f4',_A),_B:(_I,_A),_D:(_I,3),_W:(_I,4),_F:(_I,4),_X:(_I,4),_h:(_I,3),_i:(_I,3),_j:(_I,3),_R:(_Z,_A),_Y:(_s,_A),_k:(_Z,_A),_l:(_a,_A),_m:(_t,_A),'I;16LS':(_a,_A),_n:(_b,_A),_o:(_u,_A),'I;32L':(_b,_A),_p:(_c,_A),_q:(_v,_A),'I;32LS':(_c,_A)}
def _conv_type_shape(im):
	typ,extra=_MODE_CONV[im.mode]
	if extra is _A:return(im.size[1],im.size[0]),typ
	else:return(im.size[1],im.size[0],extra),typ
MODES=[_K,_X,_J,_j,_H,_C,_i,_B,_D,_F,_W,_h]
_MAPMODES=_C,_B,_W,_F,_X,_R,_k,_Y
def getmodebase(mode):return ImageMode.getmode(mode).basemode
def getmodetype(mode):return ImageMode.getmode(mode).basetype
def getmodebandnames(mode):return ImageMode.getmode(mode).bands
def getmodebands(mode):return len(ImageMode.getmode(mode).bands)
_initialized=0
def preinit():
	global _initialized
	if _initialized>=1:return
	try:from .  import BmpImagePlugin;assert BmpImagePlugin
	except ImportError:pass
	try:from .  import GifImagePlugin;assert GifImagePlugin
	except ImportError:pass
	try:from .  import JpegImagePlugin;assert JpegImagePlugin
	except ImportError:pass
	try:from .  import PpmImagePlugin;assert PpmImagePlugin
	except ImportError:pass
	try:from .  import PngImagePlugin;assert PngImagePlugin
	except ImportError:pass
	_initialized=1
def init():
	global _initialized
	if _initialized>=2:return 0
	for plugin in _plugins:
		try:logger.debug('Importing %s',plugin);__import__(f"PIL.{plugin}",globals(),locals(),[])
		except ImportError as e:logger.debug('Image: failed to import %s: %s',plugin,e)
	if OPEN or SAVE:_initialized=2;return 1
def _getdecoder(mode,decoder_name,args,extra=()):
	if args is _A:args=()
	elif not isinstance(args,tuple):args=args,
	try:decoder=DECODERS[decoder_name]
	except KeyError:pass
	else:return decoder(mode,*args+extra)
	try:decoder=getattr(core,decoder_name+'_decoder')
	except AttributeError as e:raise OSError(f"decoder {decoder_name} not available") from e
	return decoder(mode,*args+extra)
def _getencoder(mode,encoder_name,args,extra=()):
	if args is _A:args=()
	elif not isinstance(args,tuple):args=args,
	try:encoder=ENCODERS[encoder_name]
	except KeyError:pass
	else:return encoder(mode,*args+extra)
	try:encoder=getattr(core,encoder_name+'_encoder')
	except AttributeError as e:raise OSError(f"encoder {encoder_name} not available") from e
	return encoder(mode,*args+extra)
def coerce_e(value):return value if isinstance(value,_E)else _E(value)
class _E:
	def __init__(self,data):self.data=data
	def __add__(self,other):return _E((self.data,_d,coerce_e(other).data))
	def __mul__(self,other):return _E((self.data,_e,coerce_e(other).data))
def _getscaleoffset(expr):
	stub=['stub'];data=expr(_E(stub)).data
	try:
		a,b,c=data
		if a is stub and b==_e and isinstance(c,numbers.Number):return c,_S
		if a is stub and b==_d and isinstance(c,numbers.Number):return _P,c
	except TypeError:pass
	try:
		(a,b,c),d,e=data
		if a is stub and b==_e and isinstance(c,numbers.Number)and d==_d and isinstance(e,numbers.Number):return c,e
	except TypeError:pass
	raise ValueError('illegal expression')
class Image:
	format=_A;format_description=_A;_close_exclusive_fp_after_loading=_M
	def __init__(self):self.im=_A;self.mode='';self._size=0,0;self.palette=_A;self.info={};self._category=0;self.readonly=0;self.pyaccess=_A;self._exif=_A
	def __getattr__(self,name):
		if name=='category':warnings.warn(_g,DeprecationWarning,stacklevel=2);return self._category
		raise AttributeError(name)
	@property
	def width(self):return self.size[0]
	@property
	def height(self):return self.size[1]
	@property
	def size(self):return self._size
	def _new(self,im):
		new=Image();new.im=im;new.mode=im.mode;new._size=im.size
		if im.mode in(_B,_Q):
			if self.palette:new.palette=self.palette.copy()
			else:from .  import ImagePalette;new.palette=ImagePalette.ImagePalette()
		new.info=self.info.copy();return new
	def __enter__(self):return self
	def __exit__(self,*args):
		if hasattr(self,'fp')and getattr(self,'_exclusive_fp',_O):
			if hasattr(self,_w):self._close__fp()
			if self.fp:self.fp.close()
		self.fp=_A
	def close(self):
		try:
			if hasattr(self,_w):self._close__fp()
			if self.fp:self.fp.close()
			self.fp=_A
		except Exception as msg:logger.debug('Error closing: %s',msg)
		if getattr(self,'map',_A):self.map=_A
		self.im=deferred_error(ValueError('Operation on closed image'))
	def _copy(self):self.load();self.im=self.im.copy();self.pyaccess=_A;self.readonly=0
	def _ensure_mutable(self):
		if self.readonly:self._copy()
		else:self.load()
	def _dump(self,file=_A,format=_A,**options):
		suffix=''
		if format:suffix='.'+format
		if not file:f,filename=tempfile.mkstemp(suffix);os.close(f)
		else:
			filename=file
			if not filename.endswith(suffix):filename=filename+suffix
		self.load()
		if not format or format=='PPM':self.im.save_ppm(filename)
		else:self.save(filename,format,**options)
		return filename
	def __eq__(self,other):return self.__class__ is other.__class__ and self.mode==other.mode and self.size==other.size and self.info==other.info and self._category==other._category and self.readonly==other.readonly and self.getpalette()==other.getpalette()and self.tobytes()==other.tobytes()
	def __repr__(self):return'<%s.%s image mode=%s size=%dx%d at 0x%X>'%(self.__class__.__module__,self.__class__.__name__,self.mode,self.size[0],self.size[1],id(self))
	def _repr_png_(self):
		b=io.BytesIO()
		try:self.save(b,'PNG')
		except Exception as e:raise ValueError('Could not save to PNG for display') from e
		return b.getvalue()
	@property
	def __array_interface__(self):
		A='data';new={};shape,typestr=_conv_type_shape(self);new[_x]=shape;new[_y]=typestr;new['version']=3
		if self.mode==_K:new[A]=self.tobytes(_N,_C)
		else:new[A]=self.tobytes()
		return new
	def __getstate__(self):return[self.info,self.mode,self.size,self.getpalette(),self.tobytes()]
	def __setstate__(self,state):
		Image.__init__(self);self.tile=[];info,mode,size,palette,data=state;self.info=info;self.mode=mode;self._size=size;self.im=core.new(mode,size)
		if mode in(_C,_L,_B,_Q)and palette:self.putpalette(palette)
		self.frombytes(data)
	def tobytes(self,encoder_name=_N,*args):
		if len(args)==1 and isinstance(args[0],tuple):args=args[0]
		if encoder_name==_N and args==():args=self.mode
		self.load();e=_getencoder(self.mode,encoder_name,args);e.setimage(self.im);bufsize=max(65536,self.size[0]*4);data=[]
		while _M:
			l,s,d=e.encode(bufsize);data.append(d)
			if s:break
		if s<0:raise RuntimeError(f"encoder error {s} in tobytes")
		return b''.join(data)
	def tobitmap(self,name='image'):
		A='ascii';self.load()
		if self.mode!=_K:raise ValueError('not a bitmap')
		data=self.tobytes('xbm');return b''.join([f"#define {name}_width {self.size[0]}\n".encode(A),f"#define {name}_height {self.size[1]}\n".encode(A),f"static char {name}_bits[] = {{\n".encode(A),data,b'};'])
	def frombytes(self,data,decoder_name=_N,*args):
		if len(args)==1 and isinstance(args[0],tuple):args=args[0]
		if decoder_name==_N and args==():args=self.mode
		d=_getdecoder(self.mode,decoder_name,args);d.setimage(self.im);s=d.decode(data)
		if s[0]>=0:raise ValueError('not enough image data')
		if s[1]!=0:raise ValueError('cannot decode image data')
	def load(self):
		if self.im and self.palette and self.palette.dirty:
			mode,arr=self.palette.getdata()
			if mode==_F:mode=_D;self.info[_G]=arr[3::4];arr=bytes((value for(index,value)in enumerate(arr)if index%4!=3))
			self.im.putpalette(mode,arr);self.palette.dirty=0;self.palette.rawmode=_A
			if _G in self.info:
				if isinstance(self.info[_G],int):self.im.putpalettealpha(self.info[_G],0)
				else:self.im.putpalettealphas(self.info[_G])
				self.palette.mode=_F
			else:self.palette.mode=_D
		if self.im:
			if cffi and USE_CFFI_ACCESS:
				if self.pyaccess:return self.pyaccess
				from .  import PyAccess;self.pyaccess=PyAccess.new(self,self.readonly)
				if self.pyaccess:return self.pyaccess
			return self.im.pixel_access(self.readonly)
	def verify(self):0
	def convert(self,mode=_A,matrix=_A,dither=_A,palette=WEB,colors=256):
		B="Couldn't allocate palette entry for transparency";A='illegal conversion';self.load()
		if not mode and self.mode==_B:
			if self.palette:mode=self.palette.mode
			else:mode=_D
		if not mode or mode==self.mode and not matrix:return self.copy()
		has_transparency=self.info.get(_G)is not _A
		if matrix:
			if mode not in(_C,_D):raise ValueError(A)
			im=self.im.convert_matrix(mode,matrix);new=self._new(im)
			if has_transparency and self.im.bands==3:
				transparency=new.info[_G]
				def convert_transparency(m,v):v=m[0]*v[0]+m[1]*v[1]+m[2]*v[2]+m[3]*0.5;return max(0,min(255,int(v)))
				if mode==_C:transparency=convert_transparency(matrix,transparency)
				elif len(mode)==3:transparency=tuple([convert_transparency(matrix[i*4:i*4+4],transparency)for i in range(0,len(transparency))])
				new.info[_G]=transparency
			return new
		if mode==_B and self.mode==_F:return self.quantize(colors)
		trns=_A;delete_trns=_O
		if has_transparency:
			if self.mode in(_K,_C,_H,_D)and mode==_F:new_im=self._new(self.im.convert_transparent(mode,self.info[_G]));del new_im.info[_G];return new_im
			elif self.mode in(_C,_D,_B)and mode in(_C,_D,_B):
				t=self.info[_G]
				if isinstance(t,bytes):warnings.warn('Palette images with Transparency expressed in bytes should be converted to RGBA images');delete_trns=_M
				else:
					trns_im=Image()._new(core.new(self.mode,(1,1)))
					if self.mode==_B:
						trns_im.putpalette(self.palette)
						if isinstance(t,tuple):
							try:t=trns_im.palette.getcolor(t)
							except Exception as e:raise ValueError("Couldn't allocate a palette color for transparency") from e
					trns_im.putpixel((0,0),t)
					if mode in(_C,_D):trns_im=trns_im.convert(mode)
					else:trns_im=trns_im.convert(_D)
					trns=trns_im.getpixel((0,0))
			elif self.mode==_B and mode==_F:
				t=self.info[_G];delete_trns=_M
				if isinstance(t,bytes):self.im.putpalettealphas(t)
				elif isinstance(t,int):self.im.putpalettealpha(t,0)
				else:raise ValueError('Transparency for P mode should be bytes or int')
		if mode==_B and palette==ADAPTIVE:
			im=self.im.quantize(colors);new=self._new(im);from .  import ImagePalette;new.palette=ImagePalette.raw(_D,new.im.getpalette(_D))
			if delete_trns:del new.info[_G]
			if trns is not _A:
				try:new.info[_G]=new.palette.getcolor(trns)
				except Exception:del new.info[_G];warnings.warn(B)
			return new
		if dither is _A:dither=FLOYDSTEINBERG
		try:im=self.im.convert(mode,dither)
		except ValueError:
			try:im=self.im.convert(getmodebase(self.mode));im=im.convert(mode,dither)
			except KeyError as e:raise ValueError(A) from e
		new_im=self._new(im)
		if delete_trns:del new_im.info[_G]
		if trns is not _A:
			if new_im.mode==_B:
				try:new_im.info[_G]=new_im.palette.getcolor(trns)
				except Exception:del new_im.info[_G];warnings.warn(B)
			else:new_im.info[_G]=trns
		return new_im
	def quantize(self,colors=256,method=_A,kmeans=0,palette=_A,dither=1):
		self.load()
		if method is _A:
			method=MEDIANCUT
			if self.mode==_F:method=FASTOCTREE
		if self.mode==_F and method not in(FASTOCTREE,LIBIMAGEQUANT):raise ValueError('Fast Octree (method == 2) and libimagequant (method == 3) are the only valid methods for quantizing RGBA images')
		if palette:
			palette.load()
			if palette.mode!=_B:raise ValueError('bad mode for palette image')
			if self.mode!=_D and self.mode!=_C:raise ValueError('only RGB or L mode images can be quantized to a palette')
			im=self.im.convert(_B,dither,palette.im);return self._new(im)
		im=self._new(self.im.quantize(colors,method,kmeans));from .  import ImagePalette;mode=im.im.getpalettemode();im.palette=ImagePalette.ImagePalette(mode,im.im.getpalette(mode,mode));return im
	def copy(self):self.load();return self._new(self.im.copy())
	__copy__=copy
	def crop(self,box=_A):
		if box is _A:return self.copy()
		self.load();return self._new(self._crop(self.im,box))
	def _crop(self,im,box):x0,y0,x1,y1=map(int,map(round,box));absolute_values=abs(x1-x0),abs(y1-y0);_decompression_bomb_check(absolute_values);return im.crop((x0,y0,x1,y1))
	def draft(self,mode,size):0
	def _expand(self,xmargin,ymargin=_A):
		if ymargin is _A:ymargin=xmargin
		self.load();return self._new(self.im.expand(xmargin,ymargin,0))
	def filter(self,filter):
		from .  import ImageFilter;self.load()
		if isinstance(filter,Callable):filter=filter()
		if not hasattr(filter,'filter'):raise TypeError('filter argument should be ImageFilter.Filter instance or class')
		multiband=isinstance(filter,ImageFilter.MultibandFilter)
		if self.im.bands==1 or multiband:return self._new(filter.filter(self.im))
		ims=[]
		for c in range(self.im.bands):ims.append(self._new(filter.filter(self.im.getband(c))))
		return merge(self.mode,ims)
	def getbands(self):return ImageMode.getmode(self.mode).bands
	def getbbox(self):self.load();return self.im.getbbox()
	def getcolors(self,maxcolors=256):
		self.load()
		if self.mode in(_K,_C,_B):
			h=self.im.histogram();out=[]
			for i in range(256):
				if h[i]:out.append((h[i],i))
			if len(out)>maxcolors:return _A
			return out
		return self.im.getcolors(maxcolors)
	def getdata(self,band=_A):
		self.load()
		if band is not _A:return self.im.getband(band)
		return self.im
	def getextrema(self):
		self.load()
		if self.im.bands>1:
			extrema=[]
			for i in range(self.im.bands):extrema.append(self.im.getband(i).getextrema())
			return tuple(extrema)
		return self.im.getextrema()
	def getexif(self):
		A='Raw profile type exif'
		if self._exif is _A:self._exif=Exif()
		exif_info=self.info.get('exif')
		if exif_info is _A and A in self.info:exif_info=bytes.fromhex(''.join(self.info[A].split('\n')[3:]))
		self._exif.load(exif_info)
		if 274 not in self._exif:
			xmp_tags=self.info.get('XML:com.adobe.xmp')
			if xmp_tags:
				root=xml.etree.ElementTree.fromstring(xmp_tags)
				for elem in root.iter():
					if elem.tag.endswith('}Description'):
						orientation=elem.attrib.get('{http://ns.adobe.com/tiff/1.0/}Orientation')
						if orientation:self._exif[274]=int(orientation)
						break
		return self._exif
	def getim(self):self.load();return self.im.ptr
	def getpalette(self):
		self.load()
		try:return list(self.im.getpalette())
		except ValueError:return _A
	def getpixel(self,xy):
		self.load()
		if self.pyaccess:return self.pyaccess.getpixel(xy)
		return self.im.getpixel(xy)
	def getprojection(self):self.load();x,y=self.im.getprojection();return list(x),list(y)
	def histogram(self,mask=_A,extrema=_A):
		self.load()
		if mask:mask.load();return self.im.histogram((0,0),mask.im)
		if self.mode in(_H,_J):
			if extrema is _A:extrema=self.getextrema()
			return self.im.histogram(extrema)
		return self.im.histogram()
	def entropy(self,mask=_A,extrema=_A):
		self.load()
		if mask:mask.load();return self.im.entropy((0,0),mask.im)
		if self.mode in(_H,_J):
			if extrema is _A:extrema=self.getextrema()
			return self.im.entropy(extrema)
		return self.im.entropy()
	def paste(self,im,box=_A,mask=_A):
		if isImageType(box)and mask is _A:mask=box;box=_A
		if box is _A:box=0,0
		if len(box)==2:
			if isImageType(im):size=im.size
			elif isImageType(mask):size=mask.size
			else:raise ValueError('cannot determine region size; use 4-item box')
			box+=box[0]+size[0],box[1]+size[1]
		if isinstance(im,str):from .  import ImageColor;im=ImageColor.getcolor(im,self.mode)
		elif isImageType(im):
			im.load()
			if self.mode!=im.mode:
				if self.mode!=_D or im.mode not in(_F,_z):im=im.convert(self.mode)
			im=im.im
		self._ensure_mutable()
		if mask:mask.load();self.im.paste(im,box,mask.im)
		else:self.im.paste(im,box)
	def alpha_composite(self,im,dest=(0,0),source=(0,0)):
		if not isinstance(source,(list,tuple)):raise ValueError('Source must be a tuple')
		if not isinstance(dest,(list,tuple)):raise ValueError('Destination must be a tuple')
		if not len(source)in(2,4):raise ValueError('Source must be a 2 or 4-tuple')
		if not len(dest)==2:raise ValueError('Destination must be a 2-tuple')
		if min(source)<0:raise ValueError('Source must be non-negative')
		if len(source)==2:source=source+im.size
		if source==(0,0)+im.size:overlay=im
		else:overlay=im.crop(source)
		box=dest+(dest[0]+overlay.width,dest[1]+overlay.height)
		if box==(0,0)+self.size:background=self
		else:background=self.crop(box)
		result=alpha_composite(background,overlay);self.paste(result,box)
	def point(self,lut,mode=_A):
		self.load()
		if isinstance(lut,ImagePointHandler):return lut.point(self)
		if callable(lut):
			if self.mode in(_H,_R,_J):scale,offset=_getscaleoffset(lut);return self._new(self.im.point_transform(scale,offset))
			lut=[lut(i)for i in range(256)]*self.im.bands
		if self.mode==_J:raise ValueError('point operation not supported for this mode')
		return self._new(self.im.point(lut,mode))
	def putalpha(self,alpha):
		self._ensure_mutable()
		if self.mode not in(_L,_Q,_F):
			try:
				mode=getmodebase(self.mode)+'A'
				try:self.im.setmode(mode)
				except (AttributeError,ValueError)as e:
					im=self.im.convert(mode)
					if im.mode not in(_L,_Q,_F):raise ValueError from e
					self.im=im
				self.pyaccess=_A;self.mode=self.im.mode
			except KeyError as e:raise ValueError(_T) from e
		if self.mode in(_L,_Q):band=1
		else:band=3
		if isImageType(alpha):
			if alpha.mode not in(_K,_C):raise ValueError(_T)
			alpha.load()
			if alpha.mode==_K:alpha=alpha.convert(_C)
		else:
			try:self.im.fillband(band,alpha)
			except (AttributeError,ValueError):alpha=new(_C,self.size,alpha)
			else:return
		self.im.putband(alpha.im,band)
	def putdata(self,data,scale=_P,offset=_S):self._ensure_mutable();self.im.putdata(data,scale,offset)
	def putpalette(self,data,rawmode=_D):
		from .  import ImagePalette
		if self.mode not in(_C,_L,_B,_Q):raise ValueError(_T)
		self.load()
		if isinstance(data,ImagePalette.ImagePalette):palette=ImagePalette.raw(data.rawmode,data.palette)
		else:
			if not isinstance(data,bytes):data=bytes(data)
			palette=ImagePalette.raw(rawmode,data)
		self.mode=_Q if'A'in self.mode else _B;self.palette=palette;self.palette.mode=_D;self.load()
	def putpixel(self,xy,value):
		if self.readonly:self._copy()
		self.load()
		if self.pyaccess:return self.pyaccess.putpixel(xy,value)
		if self.mode==_B and isinstance(value,(list,tuple))and len(value)in[3,4]:value=self.palette.getcolor(value)
		return self.im.putpixel(xy,value)
	def remap_palette(self,dest_map,source_palette=_A):
		from .  import ImagePalette
		if self.mode not in(_C,_B):raise ValueError(_T)
		if source_palette is _A:
			if self.mode==_B:real_source_palette=self.im.getpalette(_D)[:768]
			else:real_source_palette=bytearray((i//3 for i in range(768)))
		else:real_source_palette=source_palette
		palette_bytes=b'';new_positions=[0]*256
		for (i,oldPosition) in enumerate(dest_map):palette_bytes+=real_source_palette[oldPosition*3:oldPosition*3+3];new_positions[oldPosition]=i
		mapping_palette=bytearray(new_positions);m_im=self.copy();m_im.mode=_B;m_im.palette=ImagePalette.ImagePalette(_D,palette=mapping_palette*3,size=768);m_im.im.putpalette(*m_im.palette.getdata());m_im=m_im.convert(_C);new_palette_bytes=palette_bytes+(768-len(palette_bytes))*b'\x00';m_im.putpalette(new_palette_bytes);m_im.palette=ImagePalette.ImagePalette(_D,palette=palette_bytes,size=len(palette_bytes));return m_im
	def _get_safe_box(self,size,resample,box):filter_support=_filters_support[resample]-0.5;scale_x=(box[2]-box[0])/size[0];scale_y=(box[3]-box[1])/size[1];support_x=filter_support*scale_x;support_y=filter_support*scale_y;return max(0,int(box[0]-support_x)),max(0,int(box[1]-support_y)),min(self.size[0],math.ceil(box[2]+support_x)),min(self.size[1],math.ceil(box[3]+support_y))
	def resize(self,size,resample=BICUBIC,box=_A,reducing_gap=_A):
		if resample not in(NEAREST,BILINEAR,BICUBIC,LANCZOS,BOX,HAMMING):message=f"Unknown resampling filter ({resample}).";filters=[_A0.format(filter[1],filter[0])for filter in((NEAREST,_A1),(LANCZOS,'Image.LANCZOS'),(BILINEAR,_A2),(BICUBIC,_A3),(BOX,_A4),(HAMMING,_A5))];raise ValueError(message+_A6+', '.join(filters[:-1])+' or '+filters[-1])
		if reducing_gap is not _A and reducing_gap<_P:raise ValueError('reducing_gap must be 1.0 or greater')
		size=tuple(size)
		if box is _A:box=(0,0)+self.size
		else:box=tuple(box)
		if self.size==size and box==(0,0)+self.size:return self.copy()
		if self.mode in(_K,_B):resample=NEAREST
		if self.mode in[_L,_F]and resample!=NEAREST:im=self.convert(self.mode[:-1]+'a');im=im.resize(size,resample,box);return im.convert(self.mode)
		self.load()
		if reducing_gap is not _A and resample!=NEAREST:
			factor_x=int((box[2]-box[0])/size[0]/reducing_gap)or 1;factor_y=int((box[3]-box[1])/size[1]/reducing_gap)or 1
			if factor_x>1 or factor_y>1:
				reduce_box=self._get_safe_box(size,resample,box);factor=factor_x,factor_y
				if callable(self.reduce):self=self.reduce(factor,box=reduce_box)
				else:self=Image.reduce(self,factor,box=reduce_box)
				box=(box[0]-reduce_box[0])/factor_x,(box[1]-reduce_box[1])/factor_y,(box[2]-reduce_box[0])/factor_x,(box[3]-reduce_box[1])/factor_y
		return self._new(self.im.resize(size,resample,box))
	def reduce(self,factor,box=_A):
		if not isinstance(factor,(list,tuple)):factor=factor,factor
		if box is _A:box=(0,0)+self.size
		else:box=tuple(box)
		if factor==(1,1)and box==(0,0)+self.size:return self.copy()
		if self.mode in[_L,_F]:im=self.convert(self.mode[:-1]+'a');im=im.reduce(factor,box);return im.convert(self.mode)
		self.load();return self._new(self.im.reduce(factor,box))
	def rotate(self,angle,resample=NEAREST,expand=0,center=_A,translate=_A,fillcolor=_A):
		angle=angle%360.0
		if not(center or translate):
			if angle==0:return self.copy()
			if angle==180:return self.transpose(ROTATE_180)
			if angle==90 and expand:return self.transpose(ROTATE_90)
			if angle==270 and expand:return self.transpose(ROTATE_270)
		w,h=self.size
		if translate is _A:post_trans=0,0
		else:post_trans=translate
		if center is _A:rotn_center=w/2.0,h/2.0
		else:rotn_center=center
		angle=-math.radians(angle);matrix=[round(math.cos(angle),15),round(math.sin(angle),15),_S,round(-math.sin(angle),15),round(math.cos(angle),15),_S]
		def transform(x,y,matrix):a,b,c,d,e,f=matrix;return a*x+b*y+c,d*x+e*y+f
		matrix[2],matrix[5]=transform(-rotn_center[0]-post_trans[0],-rotn_center[1]-post_trans[1],matrix);matrix[2]+=rotn_center[0];matrix[5]+=rotn_center[1]
		if expand:
			xx=[];yy=[]
			for (x,y) in ((0,0),(w,0),(w,h),(0,h)):x,y=transform(x,y,matrix);xx.append(x);yy.append(y)
			nw=math.ceil(max(xx))-math.floor(min(xx));nh=math.ceil(max(yy))-math.floor(min(yy));matrix[2],matrix[5]=transform(-(nw-w)/2.0,-(nh-h)/2.0,matrix);w,h=nw,nh
		return self.transform((w,h),AFFINE,matrix,resample,fillcolor=fillcolor)
	def save(self,fp,format=_A,**params):
		filename='';open_fp=_O
		if isPath(fp):filename=fp;open_fp=_M
		elif isinstance(fp,Path):filename=str(fp);open_fp=_M
		if not filename and hasattr(fp,'name')and isPath(fp.name):filename=fp.name
		self._ensure_mutable();save_all=params.pop('save_all',_O);self.encoderinfo=params;self.encoderconfig=();preinit();ext=os.path.splitext(filename)[1].lower()
		if not format:
			if ext not in EXTENSION:init()
			try:format=EXTENSION[ext]
			except KeyError as e:raise ValueError(f"unknown file extension: {ext}") from e
		if format.upper()not in SAVE:init()
		if save_all:save_handler=SAVE_ALL[format.upper()]
		else:save_handler=SAVE[format.upper()]
		if open_fp:
			if params.get('append',_O):fp=builtins.open(filename,'r+b')
			else:fp=builtins.open(filename,'w+b')
		try:save_handler(self,fp,filename)
		finally:
			if open_fp:fp.close()
	def seek(self,frame):
		if frame!=0:raise EOFError
	def show(self,title=_A,command=_A):
		if command is not _A:warnings.warn('The command parameter is deprecated and will be removed in Pillow 9 (2022-01-02). Use a subclass of ImageShow.Viewer instead.',DeprecationWarning)
		_show(self,title=title,command=command)
	def split(self):
		self.load()
		if self.im.bands==1:ims=[self.copy()]
		else:ims=map(self._new,self.im.split())
		return tuple(ims)
	def getchannel(self,channel):
		self.load()
		if isinstance(channel,str):
			try:channel=self.getbands().index(channel)
			except ValueError as e:raise ValueError(f'The image has no channel "{channel}"') from e
		return self._new(self.im.getband(channel))
	def tell(self):return 0
	def thumbnail(self,size,resample=BICUBIC,reducing_gap=2.0):
		x,y=map(math.floor,size)
		if x>=self.width and y>=self.height:return
		def round_aspect(number,key):return max(min(math.floor(number),math.ceil(number),key=key),1)
		aspect=self.width/self.height
		if x/y>=aspect:x=round_aspect(y*aspect,key=lambda n:abs(aspect-n/y))
		else:y=round_aspect(x/aspect,key=lambda n:0 if n==0 else abs(aspect-x/n))
		size=x,y;box=_A
		if reducing_gap is not _A:
			res=self.draft(_A,(size[0]*reducing_gap,size[1]*reducing_gap))
			if res is not _A:box=res[1]
		if self.size!=size:im=self.resize(size,resample,box=box,reducing_gap=reducing_gap);self.im=im.im;self._size=size;self.mode=self.im.mode
		self.readonly=0;self.pyaccess=_A
	def transform(self,size,method,data=_A,resample=NEAREST,fill=1,fillcolor=_A):
		if self.mode==_L and resample!=NEAREST:return self.convert('La').transform(size,method,data,resample,fill,fillcolor).convert(_L)
		if self.mode==_F and resample!=NEAREST:return self.convert(_z).transform(size,method,data,resample,fill,fillcolor).convert(_F)
		if isinstance(method,ImageTransformHandler):return method.transform(size,self,resample=resample,fill=fill)
		if hasattr(method,'getdata'):method,data=method.getdata()
		if data is _A:raise ValueError('missing method data')
		im=new(self.mode,size,fillcolor);im.info=self.info.copy()
		if method==MESH:
			for (box,quad) in data:im.__transformer(box,self,QUAD,quad,resample,fillcolor is _A)
		else:im.__transformer((0,0)+size,self,method,data,resample,fillcolor is _A)
		return im
	def __transformer(self,box,image,method,data,resample=NEAREST,fill=1):
		w=box[2]-box[0];h=box[3]-box[1]
		if method==AFFINE:data=data[0:6]
		elif method==EXTENT:x0,y0,x1,y1=data;xs=(x1-x0)/w;ys=(y1-y0)/h;method=AFFINE;data=xs,0,x0,0,ys,y0
		elif method==PERSPECTIVE:data=data[0:8]
		elif method==QUAD:nw=data[0:2];sw=data[2:4];se=data[4:6];ne=data[6:8];x0,y0=nw;As=_P/w;At=_P/h;data=x0,(ne[0]-x0)*As,(sw[0]-x0)*At,(se[0]-sw[0]-ne[0]+x0)*As*At,y0,(ne[1]-y0)*As,(sw[1]-y0)*At,(se[1]-sw[1]-ne[1]+y0)*As*At
		else:raise ValueError('unknown transformation method')
		if resample not in(NEAREST,BILINEAR,BICUBIC):
			if resample in(BOX,HAMMING,LANCZOS):message={BOX:_A4,HAMMING:_A5,LANCZOS:'Image.LANCZOS/Image.ANTIALIAS'}[resample]+f" ({resample}) cannot be used."
			else:message=f"Unknown resampling filter ({resample})."
			filters=[_A0.format(filter[1],filter[0])for filter in((NEAREST,_A1),(BILINEAR,_A2),(BICUBIC,_A3))];raise ValueError(message+_A6+', '.join(filters[:-1])+' or '+filters[-1])
		image.load();self.load()
		if image.mode in(_K,_B):resample=NEAREST
		self.im.transform2(box,image.im,method,data,resample,fill)
	def transpose(self,method):self.load();return self._new(self.im.transpose(method))
	def effect_spread(self,distance):self.load();return self._new(self.im.effect_spread(distance))
	def toqimage(self):
		from .  import ImageQt
		if not ImageQt.qt_is_installed:raise ImportError(_U)
		return ImageQt.toqimage(self)
	def toqpixmap(self):
		from .  import ImageQt
		if not ImageQt.qt_is_installed:raise ImportError(_U)
		return ImageQt.toqpixmap(self)
class ImagePointHandler:0
class ImageTransformHandler:0
def _wedge():return Image()._new(core.wedge(_C))
def _check_size(size):
	if not isinstance(size,(list,tuple)):raise ValueError('Size must be a tuple')
	if len(size)!=2:raise ValueError('Size must be a tuple of length 2')
	if size[0]<0 or size[1]<0:raise ValueError('Width and height must be >= 0')
	return _M
def new(mode,size,color=0):
	_check_size(size)
	if color is _A:return Image()._new(core.new(mode,size))
	if isinstance(color,str):from .  import ImageColor;color=ImageColor.getcolor(color,mode)
	im=Image()
	if mode==_B and isinstance(color,(list,tuple))and len(color)in[3,4]:from .  import ImagePalette;im.palette=ImagePalette.ImagePalette();color=im.palette.getcolor(color)
	return im._new(core.fill(mode,size,color))
def frombytes(mode,size,data,decoder_name=_N,*args):
	_check_size(size)
	if len(args)==1 and isinstance(args[0],tuple):args=args[0]
	if decoder_name==_N and args==():args=mode
	im=new(mode,size);im.frombytes(data,decoder_name,args);return im
def frombuffer(mode,size,data,decoder_name=_N,*args):
	_check_size(size)
	if len(args)==1 and isinstance(args[0],tuple):args=args[0]
	if decoder_name==_N:
		if args==():args=mode,0,1
		if args[0]in _MAPMODES:im=new(mode,(1,1));im=im._new(core.map_buffer(data,size,decoder_name,0,args));im.readonly=1;return im
	return frombytes(mode,size,data,decoder_name,args)
def fromarray(obj,mode=_A):
	arr=obj.__array_interface__;shape=arr[_x];ndim=len(shape);strides=arr.get('strides',_A)
	if mode is _A:
		try:typekey=(1,1)+shape[2:],arr[_y]
		except KeyError as e:raise TypeError('Cannot handle this data type') from e
		try:mode,rawmode=_fromarray_typemap[typekey]
		except KeyError as e:raise TypeError('Cannot handle this data type: %s, %s'%typekey) from e
	else:rawmode=mode
	if mode in[_K,_C,_H,_B,_J]:ndmax=2
	elif mode==_D:ndmax=3
	else:ndmax=4
	if ndim>ndmax:raise ValueError(f"Too many dimensions: {ndim} > {ndmax}.")
	size=1 if ndim==1 else shape[1],shape[0]
	if strides is not _A:
		if hasattr(obj,'tobytes'):obj=obj.tobytes()
		else:obj=obj.tostring()
	return frombuffer(mode,size,obj,_N,rawmode,0,1)
def fromqimage(im):
	from .  import ImageQt
	if not ImageQt.qt_is_installed:raise ImportError(_U)
	return ImageQt.fromqimage(im)
def fromqpixmap(im):
	from .  import ImageQt
	if not ImageQt.qt_is_installed:raise ImportError(_U)
	return ImageQt.fromqpixmap(im)
_fromarray_typemap={((1,1),_r):(_K,'1;8'),((1,1),_I):(_C,_C),((1,1),'|i1'):(_H,'I;8'),((1,1),_Z):(_H,_R),((1,1),_s):(_H,_Y),((1,1),_a):(_H,_l),((1,1),_t):(_H,_m),((1,1),_b):(_H,_n),((1,1),_u):(_H,_o),((1,1),_c):(_H,_p),((1,1),_v):(_H,_q),((1,1),'<f4'):(_J,'F;32F'),((1,1),'>f4'):(_J,'F;32BF'),((1,1),'<f8'):(_J,'F;64F'),((1,1),'>f8'):(_J,'F;64BF'),((1,1,2),_I):(_L,_L),((1,1,3),_I):(_D,_D),((1,1,4),_I):(_F,_F)}
_fromarray_typemap[((1,1),_ENDIAN+'i4')]=_H,_H
_fromarray_typemap[((1,1),_ENDIAN+'f4')]=_J,_J
def _decompression_bomb_check(size):
	if MAX_IMAGE_PIXELS is _A:return
	pixels=size[0]*size[1]
	if pixels>2*MAX_IMAGE_PIXELS:raise DecompressionBombError(f"Image size ({pixels} pixels) exceeds limit of {2*MAX_IMAGE_PIXELS} pixels, could be decompression bomb DOS attack.")
	if pixels>MAX_IMAGE_PIXELS:warnings.warn(f"Image size ({pixels} pixels) exceeds limit of {MAX_IMAGE_PIXELS} pixels, could be decompression bomb DOS attack.",DecompressionBombWarning)
def open(fp,mode='r',formats=_A):
	if mode!='r':raise ValueError(f"bad mode {repr(mode)}")
	elif isinstance(fp,io.StringIO):raise ValueError('StringIO cannot be used to open an image. Binary data must be used instead.')
	if formats is _A:formats=ID
	elif not isinstance(formats,(list,tuple)):raise TypeError('formats must be a list or tuple')
	exclusive_fp=_O;filename=''
	if isinstance(fp,Path):filename=str(fp.resolve())
	elif isPath(fp):filename=fp
	if filename:fp=builtins.open(filename,'rb');exclusive_fp=_M
	try:fp.seek(0)
	except (AttributeError,io.UnsupportedOperation):fp=io.BytesIO(fp.read());exclusive_fp=_M
	prefix=fp.read(16);preinit();accept_warnings=[]
	def _open_core(fp,filename,prefix,formats):
		for i in formats:
			i=i.upper()
			if i not in OPEN:init()
			try:
				factory,accept=OPEN[i];result=not accept or accept(prefix)
				if type(result)in[str,bytes]:accept_warnings.append(result)
				elif result:fp.seek(0);im=factory(fp,filename);_decompression_bomb_check(im.size);return im
			except (SyntaxError,IndexError,TypeError,struct.error):continue
			except BaseException:
				if exclusive_fp:fp.close()
				raise
		return _A
	im=_open_core(fp,filename,prefix,formats)
	if im is _A:
		if init():im=_open_core(fp,filename,prefix,formats)
	if im:im._exclusive_fp=exclusive_fp;return im
	if exclusive_fp:fp.close()
	for message in accept_warnings:warnings.warn(message)
	raise UnidentifiedImageError('cannot identify image file %r'%(filename if filename else fp))
def alpha_composite(im1,im2):im1.load();im2.load();return im1._new(core.alpha_composite(im1.im,im2.im))
def blend(im1,im2,alpha):im1.load();im2.load();return im1._new(core.blend(im1.im,im2.im,alpha))
def composite(image1,image2,mask):image=image2.copy();image.paste(image1,_A,mask);return image
def eval(image,*args):return image.point(args[0])
def merge(mode,bands):
	if getmodebands(mode)!=len(bands)or'*'in mode:raise ValueError('wrong number of bands')
	for band in bands[1:]:
		if band.mode!=getmodetype(mode):raise ValueError('mode mismatch')
		if band.size!=bands[0].size:raise ValueError('size mismatch')
	for band in bands:band.load()
	return bands[0]._new(core.merge(mode,*[b.im for b in bands]))
def register_open(id,factory,accept=_A):id=id.upper();ID.append(id);OPEN[id]=factory,accept
def register_mime(id,mimetype):MIME[id.upper()]=mimetype
def register_save(id,driver):SAVE[id.upper()]=driver
def register_save_all(id,driver):SAVE_ALL[id.upper()]=driver
def register_extension(id,extension):EXTENSION[extension.lower()]=id.upper()
def register_extensions(id,extensions):
	for extension in extensions:register_extension(id,extension)
def registered_extensions():
	if not EXTENSION:init()
	return EXTENSION
def register_decoder(name,decoder):DECODERS[name]=decoder
def register_encoder(name,encoder):ENCODERS[name]=encoder
def _show(image,**options):options[_f]=_M;_showxv(image,**options)
def _showxv(image,title=_A,**options):
	from .  import ImageShow
	if _f in options:del options[_f]
	else:warnings.warn('_showxv is deprecated and will be removed in Pillow 9 (2022-01-02). Use Image.show instead.',DeprecationWarning)
	ImageShow.show(image,title,**options)
def effect_mandelbrot(size,extent,quality):return Image()._new(core.effect_mandelbrot(size,extent,quality))
def effect_noise(size,sigma):return Image()._new(core.effect_noise(size,sigma))
def linear_gradient(mode):return Image()._new(core.linear_gradient(mode))
def radial_gradient(mode):return Image()._new(core.radial_gradient(mode))
def _apply_env_variables(env=_A):
	if env is _A:env=os.environ
	for (var_name,setter) in [('PILLOW_ALIGNMENT',core.set_alignment),('PILLOW_BLOCK_SIZE',core.set_block_size),('PILLOW_BLOCKS_MAX',core.set_blocks_max)]:
		if var_name not in env:continue
		var=env[var_name].lower();units=1
		for (postfix,mul) in [('k',1024),('m',1024*1024)]:
			if var.endswith(postfix):units=mul;var=var[:-len(postfix)]
		try:var=int(var)*units
		except ValueError:warnings.warn(f"{var_name} is not int");continue
		try:setter(var)
		except ValueError as e:warnings.warn(f"{var_name}: {e}")
_apply_env_variables()
atexit.register(core.clear_cache)
class Exif(MutableMapping):
	endian='<'
	def __init__(self):self._data={};self._ifds={};self._info=_A;self._loaded_exif=_A
	def _fixup(self,value):
		try:
			if len(value)==1 and isinstance(value,tuple):return value[0]
		except Exception:pass
		return value
	def _fixup_dict(self,src_dict):return{k:self._fixup(v)for(k,v)in src_dict.items()}
	def _get_ifd_dict(self,offset):
		try:self.fp.seek(offset)
		except (KeyError,TypeError):pass
		else:from .  import TiffImagePlugin;info=TiffImagePlugin.ImageFileDirectory_v2(self.head);info.load(self.fp);return self._fixup_dict(info)
	def load(self,data):
		if data==self._loaded_exif:return
		self._loaded_exif=data;self._data.clear();self._ifds.clear();self._info=_A
		if not data:return
		if data.startswith(_A7):data=data[6:]
		self.fp=io.BytesIO(data);self.head=self.fp.read(8);from .  import TiffImagePlugin;self._info=TiffImagePlugin.ImageFileDirectory_v2(self.head);self.endian=self._info._endian;self.fp.seek(self._info.next);self._info.load(self.fp)
	def _get_merged_dict(self):
		merged_dict=dict(self)
		if 34665 in self:
			ifd=self._get_ifd_dict(self[34665])
			if ifd:merged_dict.update(ifd)
		if 34853 in self:merged_dict[34853]=self._get_ifd_dict(self[34853])
		return merged_dict
	def tobytes(self,offset=8):
		from .  import TiffImagePlugin
		if self.endian=='<':head=b'II*\x00\x08\x00\x00\x00'
		else:head=b'MM\x00*\x00\x00\x00\x08'
		ifd=TiffImagePlugin.ImageFileDirectory_v2(ifh=head)
		for (tag,value) in self.items():
			if tag in[34665,33317,34853]and not isinstance(value,dict):
				value=self.get_ifd(tag)
				if tag==34665 and 40965 in value and not isinstance(value[40965],dict):value=value.copy();value[40965]=self.get_ifd(40965)
			ifd[tag]=value
		return _A7+head+ifd.tobytes(offset)
	def get_ifd(self,tag):
		if tag not in self._ifds:
			if tag in[34665,34853]:
				if tag in self:self._ifds[tag]=self._get_ifd_dict(self[tag])
			elif tag in[40965,37500]:
				if 34665 not in self._ifds:self.get_ifd(34665)
				tag_data=self._ifds[34665][tag]
				if tag==37500:
					from .TiffImagePlugin import ImageFileDirectory_v2
					if tag_data[:8]==b'FUJIFILM':
						ifd_offset=i32le(tag_data,8);ifd_data=tag_data[ifd_offset:];makernote={}
						for i in range(0,struct.unpack('<H',ifd_data[:2])[0]):
							ifd_tag,typ,count,data=struct.unpack('<HHL4s',ifd_data[i*12+2:(i+1)*12+2])
							try:unit_size,handler=ImageFileDirectory_v2._load_dispatch[typ]
							except KeyError:continue
							size=count*unit_size
							if size>4:offset,=struct.unpack('<L',data);data=ifd_data[offset-12:offset+size-12]
							else:data=data[:size]
							if len(data)!=size:warnings.warn(f"Possibly corrupt EXIF MakerNote data.  Expecting to read {size} bytes but only got {len(data)}. Skipping tag {ifd_tag}");continue
							if not data:continue
							makernote[ifd_tag]=handler(ImageFileDirectory_v2(),data,_O)
						self._ifds[tag]=dict(self._fixup_dict(makernote))
					elif self.get(271)=='Nintendo':
						makernote={}
						for i in range(0,struct.unpack('>H',tag_data[:2])[0]):
							ifd_tag,typ,count,data=struct.unpack('>HHL4s',tag_data[i*12+2:(i+1)*12+2])
							if ifd_tag==4353:offset,=struct.unpack('>L',data);self.fp.seek(offset);camerainfo={'ModelID':self.fp.read(4)};self.fp.read(4);camerainfo['TimeStamp']=i32le(self.fp.read(12));self.fp.read(4);camerainfo['InternalSerialNumber']=self.fp.read(4);self.fp.read(12);parallax=self.fp.read(4);handler=ImageFileDirectory_v2._load_dispatch[TiffTags.FLOAT][1];camerainfo['Parallax']=handler(ImageFileDirectory_v2(),parallax,_O);self.fp.read(4);camerainfo['Category']=self.fp.read(2);makernote={4353:dict(self._fixup_dict(camerainfo))}
						self._ifds[tag]=makernote
				else:self._ifds[tag]=self._get_ifd_dict(tag_data)
		return self._ifds.get(tag,{})
	def __str__(self):
		if self._info is not _A:
			for tag in self._info.keys():self[tag]
		return str(self._data)
	def __len__(self):
		keys=set(self._data)
		if self._info is not _A:keys.update(self._info)
		return len(keys)
	def __getitem__(self,tag):
		if self._info is not _A and tag not in self._data and tag in self._info:self._data[tag]=self._fixup(self._info[tag]);del self._info[tag]
		return self._data[tag]
	def __contains__(self,tag):return tag in self._data or self._info is not _A and tag in self._info
	def __setitem__(self,tag,value):
		if self._info is not _A and tag in self._info:del self._info[tag]
		self._data[tag]=value
	def __delitem__(self,tag):
		if self._info is not _A and tag in self._info:del self._info[tag]
		else:del self._data[tag]
	def __iter__(self):
		keys=set(self._data)
		if self._info is not _A:keys.update(self._info)
		return iter(keys)