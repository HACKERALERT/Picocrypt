import os
def pycryptodome_filename(dir_comps,filename):
	A=dir_comps
	if A[0]!='Crypto':raise ValueError("Only available for modules under 'Crypto'")
	A=list(A[1:])+[filename];B,_=os.path.split(os.path.abspath(__file__));C=os.path.join(B,'..');return os.path.join(C,*A)