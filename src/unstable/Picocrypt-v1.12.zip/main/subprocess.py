_J='subprocess.Popen'
_I='path-like args is not allowed when shell is true'
_H='_devnull'
_G='\n'
_F='stdout'
_E=b''
_D='handle_list'
_C=False
_B=True
_A=None
import builtins,errno,io,os,time,signal,sys,threading,warnings,contextlib
from time import monotonic as _time
__all__=['Popen','PIPE','STDOUT','call','check_call','getstatusoutput','getoutput','check_output','run','CalledProcessError','DEVNULL','SubprocessError','TimeoutExpired','CompletedProcess']
try:import msvcrt,_winapi;_mswindows=_B
except ModuleNotFoundError:_mswindows=_C;import _posixsubprocess;import select;import selectors
else:from _winapi import CREATE_NEW_CONSOLE,CREATE_NEW_PROCESS_GROUP,STD_INPUT_HANDLE,STD_OUTPUT_HANDLE,STD_ERROR_HANDLE,SW_HIDE,STARTF_USESTDHANDLES,STARTF_USESHOWWINDOW,ABOVE_NORMAL_PRIORITY_CLASS,BELOW_NORMAL_PRIORITY_CLASS,HIGH_PRIORITY_CLASS,IDLE_PRIORITY_CLASS,NORMAL_PRIORITY_CLASS,REALTIME_PRIORITY_CLASS,CREATE_NO_WINDOW,DETACHED_PROCESS,CREATE_DEFAULT_ERROR_MODE,CREATE_BREAKAWAY_FROM_JOB;__all__.extend(['CREATE_NEW_CONSOLE','CREATE_NEW_PROCESS_GROUP','STD_INPUT_HANDLE','STD_OUTPUT_HANDLE','STD_ERROR_HANDLE','SW_HIDE','STARTF_USESTDHANDLES','STARTF_USESHOWWINDOW','STARTUPINFO','ABOVE_NORMAL_PRIORITY_CLASS','BELOW_NORMAL_PRIORITY_CLASS','HIGH_PRIORITY_CLASS','IDLE_PRIORITY_CLASS','NORMAL_PRIORITY_CLASS','REALTIME_PRIORITY_CLASS','CREATE_NO_WINDOW','DETACHED_PROCESS','CREATE_DEFAULT_ERROR_MODE','CREATE_BREAKAWAY_FROM_JOB'])
class SubprocessError(Exception):0
class CalledProcessError(SubprocessError):
	def __init__(A,returncode,cmd,output=_A,stderr=_A):A.returncode=returncode;A.cmd=cmd;A.output=output;A.stderr=stderr
	def __str__(A):
		if A.returncode and A.returncode<0:
			try:return"Command '%s' died with %r."%(A.cmd,signal.Signals(-A.returncode))
			except ValueError:return"Command '%s' died with unknown signal %d."%(A.cmd,-A.returncode)
		else:return"Command '%s' returned non-zero exit status %d."%(A.cmd,A.returncode)
	@property
	def stdout(self):return self.output
	@stdout.setter
	def stdout(self,value):self.output=value
class TimeoutExpired(SubprocessError):
	def __init__(A,cmd,timeout,output=_A,stderr=_A):A.cmd=cmd;A.timeout=timeout;A.output=output;A.stderr=stderr
	def __str__(A):return"Command '%s' timed out after %s seconds"%(A.cmd,A.timeout)
	@property
	def stdout(self):return self.output
	@stdout.setter
	def stdout(self,value):self.output=value
if _mswindows:
	class STARTUPINFO:
		def __init__(A,*,dwFlags=0,hStdInput=_A,hStdOutput=_A,hStdError=_A,wShowWindow=0,lpAttributeList=_A):A.dwFlags=dwFlags;A.hStdInput=hStdInput;A.hStdOutput=hStdOutput;A.hStdError=hStdError;A.wShowWindow=wShowWindow;A.lpAttributeList=lpAttributeList or{_D:[]}
		def copy(A):
			B=A.lpAttributeList.copy()
			if _D in B:B[_D]=list(B[_D])
			return STARTUPINFO(dwFlags=A.dwFlags,hStdInput=A.hStdInput,hStdOutput=A.hStdOutput,hStdError=A.hStdError,wShowWindow=A.wShowWindow,lpAttributeList=B)
	class Handle(int):
		closed=_C
		def Close(A,CloseHandle=_winapi.CloseHandle):
			if not A.closed:A.closed=_B;CloseHandle(A)
		def Detach(A):
			if not A.closed:A.closed=_B;return int(A)
			raise ValueError('already closed')
		def __repr__(A):return'%s(%d)'%(A.__class__.__name__,int(A))
		__del__=Close
else:
	_PIPE_BUF=getattr(select,'PIPE_BUF',512)
	if hasattr(selectors,'PollSelector'):_PopenSelector=selectors.PollSelector
	else:_PopenSelector=selectors.SelectSelector
if _mswindows:
	_active=_A
	def _cleanup():0
else:
	_active=[]
	def _cleanup():
		if _active is _A:return
		for A in _active[:]:
			B=A._internal_poll(_deadstate=sys.maxsize)
			if B is not _A:
				try:_active.remove(A)
				except ValueError:pass
PIPE=-1
STDOUT=-2
DEVNULL=-3
def _optim_args_from_interpreter_flags():
	A=[];B=sys.flags.optimize
	if B>0:A.append('-'+'O'*B)
	return A
def _args_from_interpreter_flags():
	M='-X';L='dev';J={'debug':'d','dont_write_bytecode':'B','no_site':'S','verbose':'v','bytes_warning':'b','quiet':'q'};A=_optim_args_from_interpreter_flags()
	for (K,B) in J.items():
		E=getattr(sys.flags,K)
		if E>0:A.append('-'+B*E)
	if sys.flags.isolated:A.append('-I')
	else:
		if sys.flags.ignore_environment:A.append('-E')
		if sys.flags.no_user_site:A.append('-s')
	C=sys.warnoptions[:];F=sys.flags.bytes_warning;D=getattr(sys,'_xoptions',{});G=L in D
	if F>1:C.remove('error::BytesWarning')
	elif F:C.remove('default::BytesWarning')
	if G:C.remove('default')
	for B in C:A.append('-W'+B)
	if G:A.extend((M,L))
	for B in ('faulthandler','tracemalloc','importtime','showalloccount','showrefcount','utf8'):
		if B in D:
			H=D[B]
			if H is _B:I=B
			else:I='%s=%s'%(B,H)
			A.extend((M,I))
	return A
def call(*B,timeout=_A,**C):
	with Popen(*B,**C)as A:
		try:return A.wait(timeout=timeout)
		except:A.kill();raise
def check_call(*B,**C):
	D=call(*B,**C)
	if D:
		A=C.get('args')
		if A is _A:A=B[0]
		raise CalledProcessError(D,A)
	return 0
def check_output(*D,timeout=_A,**A):
	C='input'
	if _F in A:raise ValueError('stdout argument not allowed, it will be overridden.')
	if C in A and A[C]is _A:
		if A.get('universal_newlines')or A.get('text'):B=''
		else:B=_E
		A[C]=B
	return run(*D,stdout=PIPE,timeout=timeout,check=_B,**A).stdout
class CompletedProcess:
	def __init__(A,args,returncode,stdout=_A,stderr=_A):A.args=args;A.returncode=returncode;A.stdout=stdout;A.stderr=stderr
	def __repr__(A):
		B=['args={!r}'.format(A.args),'returncode={!r}'.format(A.returncode)]
		if A.stdout is not _A:B.append('stdout={!r}'.format(A.stdout))
		if A.stderr is not _A:B.append('stderr={!r}'.format(A.stderr))
		return '{}({})'.format(type(A).__name__,', '.join(B))
	def check_returncode(A):
		if A.returncode:raise CalledProcessError(A.returncode,A.args,A.stdout,A.stderr)
def run(*G,input=_A,capture_output=_C,timeout=_A,check=_C,**B):
	I='stderr';H='stdin'
	if input is not _A:
		if B.get(H)is not _A:raise ValueError('stdin and input arguments may not both be used.')
		B[H]=PIPE
	if capture_output:
		if B.get(_F)is not _A or B.get(I)is not _A:raise ValueError('stdout and stderr arguments may not be used with capture_output.')
		B[_F]=PIPE;B[I]=PIPE
	with Popen(*G,**B)as A:
		try:D,E=A.communicate(input,timeout=timeout)
		except TimeoutExpired as F:
			A.kill()
			if _mswindows:F.stdout,F.stderr=A.communicate()
			else:A.wait()
			raise
		except:A.kill();raise
		C=A.poll()
		if check and C:raise CalledProcessError(C,A.args,output=D,stderr=E)
	return CompletedProcess(A.args,C,D,E)
def list2cmdline(seq):
	H='\\';G=' ';F='"';A=[];E=_C
	for C in map(os.fsdecode,seq):
		B=[]
		if A:A.append(G)
		E=G in C or'\t'in C or not C
		if E:A.append(F)
		for D in C:
			if D==H:B.append(D)
			elif D==F:A.append(H*len(B)*2);B=[];A.append('\\"')
			else:
				if B:A.extend(B);B=[]
				A.append(D)
		if B:A.extend(B)
		if E:A.extend(B);A.append(F)
	return ''.join(A)
def getstatusoutput(cmd):
	try:A=check_output(cmd,shell=_B,text=_B,stderr=STDOUT);B=0
	except CalledProcessError as C:A=C.output;B=C.returncode
	if A[-1:]==_G:A=A[:-1]
	return B,A
def getoutput(cmd):return getstatusoutput(cmd)[1]
def _use_posix_spawn():
	if _mswindows or not hasattr(os,'posix_spawn'):return _C
	if sys.platform=='darwin':return _B
	try:
		B=os.confstr('CS_GNU_LIBC_VERSION');A=B.split(maxsplit=1)
		if len(A)!=2:raise ValueError
		C=A[0];D=tuple(map(int,A[1].split('.')))
		if sys.platform=='linux'and C=='glibc'and D>=(2,24):return _B
	except (AttributeError,ValueError,OSError):pass
	return _C
_USE_POSIX_SPAWN=_use_posix_spawn()
class Popen:
	_child_created=_C
	def __init__(A,args,bufsize=-1,executable=_A,stdin=_A,stdout=_A,stderr=_A,preexec_fn=_A,close_fds=_B,shell=_C,cwd=_A,env=_A,universal_newlines=_A,startupinfo=_A,creationflags=0,restore_signals=_B,start_new_session=_C,pass_fds=(),*,encoding=_A,errors=_A,text=_A):
		Y='rb';S=pass_fds;R=creationflags;Q=startupinfo;P=preexec_fn;O=stderr;N=stdout;M=stdin;K=text;J=universal_newlines;I=close_fds;G=errors;F=encoding;B=bufsize;_cleanup();A._waitpid_lock=threading.Lock();A._input=_A;A._communication_started=_C
		if B is _A:B=-1
		if not isinstance(B,int):raise TypeError('bufsize must be an integer')
		if _mswindows:
			if P is not _A:raise ValueError('preexec_fn is not supported on Windows platforms')
		else:
			if S and not I:warnings.warn('pass_fds overriding close_fds.',RuntimeWarning);I=_B
			if Q is not _A:raise ValueError('startupinfo is only supported on Windows platforms')
			if R!=0:raise ValueError('creationflags is only supported on Windows platforms')
		A.args=args;A.stdin=_A;A.stdout=_A;A.stderr=_A;A.pid=_A;A.returncode=_A;A.encoding=F;A.errors=G
		if K is not _A and J is not _A and bool(J)!=bool(K):raise SubprocessError('Cannot disambiguate when both text and universal_newlines are supplied but different. Pass one or the other.')
		T,C,D,U,E,V=A._get_handles(M,N,O)
		if _mswindows:
			if C!=-1:C=msvcrt.open_osfhandle(C.Detach(),0)
			if D!=-1:D=msvcrt.open_osfhandle(D.Detach(),0)
			if E!=-1:E=msvcrt.open_osfhandle(E.Detach(),0)
		A.text_mode=F or G or K or J;A._sigint_wait_secs=0.25;A._closed_child_pipe_fds=_C
		if A.text_mode:
			if B==1:W=_B;B=-1
			else:W=_C
		try:
			if C!=-1:
				A.stdin=io.open(C,'wb',B)
				if A.text_mode:A.stdin=io.TextIOWrapper(A.stdin,write_through=_B,line_buffering=W,encoding=F,errors=G)
			if D!=-1:
				A.stdout=io.open(D,Y,B)
				if A.text_mode:A.stdout=io.TextIOWrapper(A.stdout,encoding=F,errors=G)
			if E!=-1:
				A.stderr=io.open(E,Y,B)
				if A.text_mode:A.stderr=io.TextIOWrapper(A.stderr,encoding=F,errors=G)
			A._execute_child(args,executable,P,I,S,cwd,env,Q,R,shell,T,C,D,U,E,V,restore_signals,start_new_session)
		except:
			for X in filter(_A,(A.stdin,A.stdout,A.stderr)):
				try:X.close()
				except OSError:pass
			if not A._closed_child_pipe_fds:
				H=[]
				if M==PIPE:H.append(T)
				if N==PIPE:H.append(U)
				if O==PIPE:H.append(V)
				if hasattr(A,_H):H.append(A._devnull)
				for L in H:
					try:
						if _mswindows and isinstance(L,Handle):L.Close()
						else:os.close(L)
					except OSError:pass
			raise
	@property
	def universal_newlines(self):return self.text_mode
	@universal_newlines.setter
	def universal_newlines(self,universal_newlines):self.text_mode=bool(universal_newlines)
	def _translate_newlines(B,data,encoding,errors):A=data;A=A.decode(encoding,errors);return A.replace('\r\n',_G).replace('\r',_G)
	def __enter__(A):return A
	def __exit__(A,exc_type,value,traceback):
		if A.stdout:A.stdout.close()
		if A.stderr:A.stderr.close()
		try:
			if A.stdin:A.stdin.close()
		finally:
			if exc_type==KeyboardInterrupt:
				if A._sigint_wait_secs>0:
					try:A._wait(timeout=A._sigint_wait_secs)
					except TimeoutExpired:pass
				A._sigint_wait_secs=0;return
			A.wait()
	def __del__(A,_maxsize=sys.maxsize,_warn=warnings.warn):
		if not A._child_created:return
		if A.returncode is _A:_warn('subprocess %s is still running'%A.pid,ResourceWarning,source=A)
		A._internal_poll(_deadstate=_maxsize)
		if A.returncode is _A and _active is not _A:_active.append(A)
	def _get_devnull(A):
		if not hasattr(A,_H):A._devnull=os.open(os.devnull,os.O_RDWR)
		return A._devnull
	def _stdin_write(B,input):
		if input:
			try:B.stdin.write(input)
			except BrokenPipeError:pass
			except OSError as A:
				if A.errno==errno.EINVAL:0
				else:raise
		try:B.stdin.close()
		except BrokenPipeError:pass
		except OSError as A:
			if A.errno==errno.EINVAL:0
			else:raise
	def communicate(A,input=_A,timeout=_A):
		B=timeout
		if A._communication_started and input:raise ValueError('Cannot send input after starting communication')
		if B is _A and not A._communication_started and [A.stdin,A.stdout,A.stderr].count(_A)>=2:
			D=_A;E=_A
			if A.stdin:A._stdin_write(input)
			elif A.stdout:D=A.stdout.read();A.stdout.close()
			elif A.stderr:E=A.stderr.read();A.stderr.close()
			A.wait()
		else:
			if B is not _A:C=_time()+B
			else:C=_A
			try:D,E=A._communicate(input,C,B)
			except KeyboardInterrupt:
				if B is not _A:F=min(A._sigint_wait_secs,A._remaining_time(C))
				else:F=A._sigint_wait_secs
				A._sigint_wait_secs=0
				try:A._wait(timeout=F)
				except TimeoutExpired:pass
				raise
			finally:A._communication_started=_B
			G=A.wait(timeout=A._remaining_time(C))
		return D,E
	def poll(A):return A._internal_poll()
	def _remaining_time(B,endtime):
		A=endtime
		if A is _A:return _A
		else:return A-_time()
	def _check_timeout(D,endtime,orig_timeout,stdout_seq,stderr_seq,skip_check_and_raise=_C):
		C=stderr_seq;B=stdout_seq;A=endtime
		if A is _A:return
		if skip_check_and_raise or _time()>A:raise TimeoutExpired(D.args,orig_timeout,output=_E.join(B)if B else _A,stderr=_E.join(C)if C else _A)
	def wait(A,timeout=_A):
		B=timeout
		if B is not _A:D=_time()+B
		try:return A._wait(timeout=B)
		except KeyboardInterrupt:
			if B is not _A:C=min(A._sigint_wait_secs,A._remaining_time(D))
			else:C=A._sigint_wait_secs
			A._sigint_wait_secs=0
			try:A._wait(timeout=C)
			except TimeoutExpired:pass
			raise
	def _close_pipe_fds(F,p2cread,p2cwrite,c2pread,c2pwrite,errread,errwrite):
		D=errwrite;C=c2pwrite;B=p2cread;E=getattr(F,_H,_A)
		with contextlib.ExitStack()as A:
			if _mswindows:
				if B!=-1:A.callback(B.Close)
				if C!=-1:A.callback(C.Close)
				if D!=-1:A.callback(D.Close)
			else:
				if B!=-1 and p2cwrite!=-1 and B!=E:A.callback(os.close,B)
				if C!=-1 and c2pread!=-1 and C!=E:A.callback(os.close,C)
				if D!=-1 and errread!=-1 and D!=E:A.callback(os.close,D)
			if E is not _A:A.callback(os.close,E)
		F._closed_child_pipe_fds=_B
	if _mswindows:
		def _get_handles(G,stdin,stdout,stderr):
			F=stdout;E=stdin;D=stderr
			if E is _A and F is _A and D is _A:return-1,-1,-1,-1,-1,-1
			C,H=-1,-1;I,A=-1,-1;J,B=-1,-1
			if E is _A:
				C=_winapi.GetStdHandle(_winapi.STD_INPUT_HANDLE)
				if C is _A:C,_=_winapi.CreatePipe(_A,0);C=Handle(C);_winapi.CloseHandle(_)
			elif E==PIPE:C,H=_winapi.CreatePipe(_A,0);C,H=Handle(C),Handle(H)
			elif E==DEVNULL:C=msvcrt.get_osfhandle(G._get_devnull())
			elif isinstance(E,int):C=msvcrt.get_osfhandle(E)
			else:C=msvcrt.get_osfhandle(E.fileno())
			C=G._make_inheritable(C)
			if F is _A:
				A=_winapi.GetStdHandle(_winapi.STD_OUTPUT_HANDLE)
				if A is _A:_,A=_winapi.CreatePipe(_A,0);A=Handle(A);_winapi.CloseHandle(_)
			elif F==PIPE:I,A=_winapi.CreatePipe(_A,0);I,A=Handle(I),Handle(A)
			elif F==DEVNULL:A=msvcrt.get_osfhandle(G._get_devnull())
			elif isinstance(F,int):A=msvcrt.get_osfhandle(F)
			else:A=msvcrt.get_osfhandle(F.fileno())
			A=G._make_inheritable(A)
			if D is _A:
				B=_winapi.GetStdHandle(_winapi.STD_ERROR_HANDLE)
				if B is _A:_,B=_winapi.CreatePipe(_A,0);B=Handle(B);_winapi.CloseHandle(_)
			elif D==PIPE:J,B=_winapi.CreatePipe(_A,0);J,B=Handle(J),Handle(B)
			elif D==STDOUT:B=A
			elif D==DEVNULL:B=msvcrt.get_osfhandle(G._get_devnull())
			elif isinstance(D,int):B=msvcrt.get_osfhandle(D)
			else:B=msvcrt.get_osfhandle(D.fileno())
			B=G._make_inheritable(B);return C,H,I,A,J,B
		def _make_inheritable(B,handle):A=_winapi.DuplicateHandle(_winapi.GetCurrentProcess(),handle,_winapi.GetCurrentProcess(),0,1,_winapi.DUPLICATE_SAME_ACCESS);return Handle(A)
		def _filter_handle_list(A,handle_list):return list({A for A in handle_list if A&3!=3 or _winapi.GetFileType(A)!=_winapi.FILE_TYPE_CHAR})
		def _execute_child(D,args,executable,preexec_fn,close_fds,pass_fds,cwd,env,startupinfo,creationflags,shell,p2cread,p2cwrite,c2pread,c2pwrite,errread,errwrite,unused_restore_signals,unused_start_new_session):
			L=shell;J=errwrite;I=c2pwrite;H=p2cread;G=close_fds;F=cwd;E=executable;B=startupinfo;A=args;assert not pass_fds,'pass_fds not supported on Windows.'
			if isinstance(A,str):0
			elif isinstance(A,bytes):
				if L:raise TypeError('bytes args is not allowed on Windows')
				A=list2cmdline([A])
			elif isinstance(A,os.PathLike):
				if L:raise TypeError(_I)
				A=list2cmdline([A])
			else:A=list2cmdline(A)
			if E is not _A:E=os.fsdecode(E)
			if B is _A:B=STARTUPINFO()
			else:B=B.copy()
			M=-1 not in(H,I,J)
			if M:B.dwFlags|=_winapi.STARTF_USESTDHANDLES;B.hStdInput=H;B.hStdOutput=I;B.hStdError=J
			C=B.lpAttributeList;N=bool(C and _D in C and C[_D])
			if N or M and G:
				if C is _A:C=B.lpAttributeList={}
				K=C[_D]=list(C.get(_D,[]))
				if M:K+=[int(H),int(I),int(J)]
				K[:]=D._filter_handle_list(K)
				if K:
					if not G:warnings.warn("startupinfo.lpAttributeList['handle_list'] overriding close_fds",RuntimeWarning)
					G=_C
			if L:B.dwFlags|=_winapi.STARTF_USESHOWWINDOW;B.wShowWindow=_winapi.SW_HIDE;O=os.environ.get('COMSPEC','cmd.exe');A='{} /c "{}"'.format(O,A)
			if F is not _A:F=os.fsdecode(F)
			sys.audit(_J,E,A,F,env)
			try:P,Q,R,S=_winapi.CreateProcess(E,A,_A,_A,int(not G),creationflags,env,F,B)
			finally:D._close_pipe_fds(H,p2cwrite,c2pread,I,errread,J)
			D._child_created=_B;D._handle=Handle(P);D.pid=R;_winapi.CloseHandle(Q)
		def _internal_poll(A,_deadstate=_A,_WaitForSingleObject=_winapi.WaitForSingleObject,_WAIT_OBJECT_0=_winapi.WAIT_OBJECT_0,_GetExitCodeProcess=_winapi.GetExitCodeProcess):
			if A.returncode is _A:
				if _WaitForSingleObject(A._handle,0)==_WAIT_OBJECT_0:A.returncode=_GetExitCodeProcess(A._handle)
			return A.returncode
		def _wait(A,timeout):
			B=timeout
			if B is _A:C=_winapi.INFINITE
			else:C=int(B*1000)
			if A.returncode is _A:
				D=_winapi.WaitForSingleObject(A._handle,C)
				if D==_winapi.WAIT_TIMEOUT:raise TimeoutExpired(A.args,B)
				A.returncode=_winapi.GetExitCodeProcess(A._handle)
			return A.returncode
		def _readerthread(A,fh,buffer):buffer.append(fh.read());fh.close()
		def _communicate(A,input,endtime,orig_timeout):
			E=orig_timeout;D=endtime
			if A.stdout and not hasattr(A,'_stdout_buff'):A._stdout_buff=[];A.stdout_thread=threading.Thread(target=A._readerthread,args=(A.stdout,A._stdout_buff));A.stdout_thread.daemon=_B;A.stdout_thread.start()
			if A.stderr and not hasattr(A,'_stderr_buff'):A._stderr_buff=[];A.stderr_thread=threading.Thread(target=A._readerthread,args=(A.stderr,A._stderr_buff));A.stderr_thread.daemon=_B;A.stderr_thread.start()
			if A.stdin:A._stdin_write(input)
			if A.stdout is not _A:
				A.stdout_thread.join(A._remaining_time(D))
				if A.stdout_thread.is_alive():raise TimeoutExpired(A.args,E)
			if A.stderr is not _A:
				A.stderr_thread.join(A._remaining_time(D))
				if A.stderr_thread.is_alive():raise TimeoutExpired(A.args,E)
			B=_A;C=_A
			if A.stdout:B=A._stdout_buff;A.stdout.close()
			if A.stderr:C=A._stderr_buff;A.stderr.close()
			B=B[0]if B else _A;C=C[0]if C else _A;return B,C
		def send_signal(A,sig):
			B=sig
			if A.returncode is not _A:return
			if B==signal.SIGTERM:A.terminate()
			elif B==signal.CTRL_C_EVENT:os.kill(A.pid,signal.CTRL_C_EVENT)
			elif B==signal.CTRL_BREAK_EVENT:os.kill(A.pid,signal.CTRL_BREAK_EVENT)
			else:raise ValueError('Unsupported signal: {}'.format(B))
		def terminate(A):
			if A.returncode is not _A:return
			try:_winapi.TerminateProcess(A._handle,1)
			except PermissionError:
				B=_winapi.GetExitCodeProcess(A._handle)
				if B==_winapi.STILL_ACTIVE:raise
				A.returncode=B
		kill=terminate
	else:
		def _get_handles(G,stdin,stdout,stderr):
			E=stdout;D=stdin;A=stderr;F,H=-1,-1;I,B=-1,-1;J,C=-1,-1
			if D is _A:0
			elif D==PIPE:F,H=os.pipe()
			elif D==DEVNULL:F=G._get_devnull()
			elif isinstance(D,int):F=D
			else:F=D.fileno()
			if E is _A:0
			elif E==PIPE:I,B=os.pipe()
			elif E==DEVNULL:B=G._get_devnull()
			elif isinstance(E,int):B=E
			else:B=E.fileno()
			if A is _A:0
			elif A==PIPE:J,C=os.pipe()
			elif A==STDOUT:
				if B!=-1:C=B
				else:C=sys.__stdout__.fileno()
			elif A==DEVNULL:C=G._get_devnull()
			elif isinstance(A,int):C=A
			else:C=A.fileno()
			return F,H,I,B,J,C
		def _posix_spawn(C,args,executable,env,restore_signals,p2cread,p2cwrite,c2pread,c2pwrite,errread,errwrite):
			K=errwrite;J=errread;I=c2pwrite;H=c2pread;G=p2cwrite;F=p2cread;D=env
			if D is _A:D=os.environ
			E={}
			if restore_signals:
				L=[]
				for N in ('SIGPIPE','SIGXFZ','SIGXFSZ'):
					M=getattr(signal,N,_A)
					if M is not _A:L.append(M)
				E['setsigdef']=L
			B=[]
			for A in (G,H,J):
				if A!=-1:B.append((os.POSIX_SPAWN_CLOSE,A))
			for (A,O) in ((F,0),(I,1),(K,2)):
				if A!=-1:B.append((os.POSIX_SPAWN_DUP2,A,O))
			if B:E['file_actions']=B
			C.pid=os.posix_spawn(executable,args,D,**E);C._child_created=_B;C._close_pipe_fds(F,G,H,I,J,K)
		def _execute_child(C,args,executable,preexec_fn,close_fds,pass_fds,cwd,env,startupinfo,creationflags,shell,p2cread,p2cwrite,c2pread,c2pwrite,errread,errwrite,restore_signals,start_new_session):
			n=b'=';Z=start_new_session;Y=restore_signals;X=shell;W=pass_fds;V=close_fds;U=preexec_fn;O=errread;N=c2pread;M=p2cwrite;K=cwd;I=errwrite;H=c2pwrite;G=p2cread;F=env;B=executable;A=args
			if isinstance(A,(str,bytes)):A=[A]
			elif isinstance(A,os.PathLike):
				if X:raise TypeError(_I)
				A=[A]
			else:A=list(A)
			if X:
				g='/system/bin/sh'if hasattr(sys,'getandroidapilevel')else'/bin/sh';A=[g,'-c']+A
				if B:A[0]=B
			if B is _A:B=A[0]
			sys.audit(_J,B,A,K,F)
			if _USE_POSIX_SPAWN and os.path.dirname(B)and U is _A and not V and not W and K is _A and(G==-1 or G>2)and(H==-1 or H>2)and(I==-1 or I>2)and not Z:C._posix_spawn(A,B,F,Y,G,M,N,H,O,I);return
			h=B;P,E=os.pipe();a=[]
			while E<3:a.append(E);E=os.dup(E)
			for i in a:os.close(i)
			try:
				try:
					if F is not _A:
						Q=[]
						for (L,j) in F.items():
							L=os.fsencode(L)
							if n in L:raise ValueError('illegal environment variable name')
							Q.append(L+n+os.fsencode(j))
					else:Q=_A
					B=os.fsencode(B)
					if os.path.dirname(B):b=B,
					else:b=tuple((os.path.join(os.fsencode(dir),B)for dir in os.get_exec_path(F)))
					c=set(W);c.add(E);C.pid=_posixsubprocess.fork_exec(A,b,V,tuple(sorted(map(int,c))),K,Q,G,M,N,H,O,I,P,E,Y,Z,U);C._child_created=_B
				finally:os.close(E)
				C._close_pipe_fds(G,M,N,H,O,I);J=bytearray()
				while _B:
					d=os.read(P,50000);J+=d
					if not d or len(J)>50000:break
			finally:os.close(P)
			if J:
				try:
					k,l=os.waitpid(C.pid,0)
					if k==C.pid:C._handle_exitstatus(l)
					else:C.returncode=sys.maxsize
				except ChildProcessError:pass
				try:e,R,D=J.split(b':',2);D=D.decode()
				except ValueError:e=b'SubprocessError';R=b'0';D='Bad exception data from child: {!r}'.format(bytes(J))
				S=getattr(builtins,e.decode('ascii'),SubprocessError)
				if issubclass(S,OSError)and R:
					T=int(R,16);m=D=='noexec'
					if m:D='';f=K
					else:f=h
					if T!=0:D=os.strerror(T)
					raise S(T,D,f)
				raise S(D)
		def _handle_exitstatus(B,sts,_WIFSIGNALED=os.WIFSIGNALED,_WTERMSIG=os.WTERMSIG,_WIFEXITED=os.WIFEXITED,_WEXITSTATUS=os.WEXITSTATUS,_WIFSTOPPED=os.WIFSTOPPED,_WSTOPSIG=os.WSTOPSIG):
			A=sts
			if _WIFSIGNALED(A):B.returncode=-_WTERMSIG(A)
			elif _WIFEXITED(A):B.returncode=_WEXITSTATUS(A)
			elif _WIFSTOPPED(A):B.returncode=-_WSTOPSIG(A)
			else:raise SubprocessError('Unknown child exit status!')
		def _internal_poll(A,_deadstate=_A,_waitpid=os.waitpid,_WNOHANG=os.WNOHANG,_ECHILD=errno.ECHILD):
			B=_deadstate
			if A.returncode is _A:
				if not A._waitpid_lock.acquire(_C):return _A
				try:
					if A.returncode is not _A:return A.returncode
					C,D=_waitpid(A.pid,_WNOHANG)
					if C==A.pid:A._handle_exitstatus(D)
				except OSError as E:
					if B is not _A:A.returncode=B
					elif E.errno==_ECHILD:A.returncode=0
				finally:A._waitpid_lock.release()
			return A.returncode
		def _try_wait(A,wait_flags):
			try:B,C=os.waitpid(A.pid,wait_flags)
			except ChildProcessError:B=A.pid;C=0
			return B,C
		def _wait(A,timeout):
			C=timeout
			if A.returncode is not _A:return A.returncode
			if C is not _A:
				G=_time()+C;D=0.0005
				while _B:
					if A._waitpid_lock.acquire(_C):
						try:
							if A.returncode is not _A:break
							B,E=A._try_wait(os.WNOHANG);assert B==A.pid or B==0
							if B==A.pid:A._handle_exitstatus(E);break
						finally:A._waitpid_lock.release()
					F=A._remaining_time(G)
					if F<=0:raise TimeoutExpired(A.args,C)
					D=min(D*2,F,0.05);time.sleep(D)
			else:
				while A.returncode is _A:
					with A._waitpid_lock:
						if A.returncode is not _A:break
						B,E=A._try_wait(0)
						if B==A.pid:A._handle_exitstatus(E)
			return A.returncode
		def _communicate(A,input,endtime,orig_timeout):
			H=orig_timeout;F=endtime
			if A.stdin and not A._communication_started:
				try:A.stdin.flush()
				except BrokenPipeError:pass
				if not input:
					try:A.stdin.close()
					except BrokenPipeError:pass
			C=_A;D=_A
			if not A._communication_started:
				A._fileobj2output={}
				if A.stdout:A._fileobj2output[A.stdout]=[]
				if A.stderr:A._fileobj2output[A.stderr]=[]
			if A.stdout:C=A._fileobj2output[A.stdout]
			if A.stderr:D=A._fileobj2output[A.stderr]
			A._save_input(input)
			if A._input:J=memoryview(A._input)
			with _PopenSelector()as E:
				if A.stdin and input:E.register(A.stdin,selectors.EVENT_WRITE)
				if A.stdout and not A.stdout.closed:E.register(A.stdout,selectors.EVENT_READ)
				if A.stderr and not A.stderr.closed:E.register(A.stderr,selectors.EVENT_READ)
				while E.get_map():
					G=A._remaining_time(F)
					if G is not _A and G<0:A._check_timeout(F,H,C,D,skip_check_and_raise=_B);raise RuntimeError('_check_timeout(..., skip_check_and_raise=True) failed to raise TimeoutExpired.')
					K=E.select(G);A._check_timeout(F,H,C,D)
					for (B,M) in K:
						if B.fileobj is A.stdin:
							L=J[A._input_offset:A._input_offset+_PIPE_BUF]
							try:A._input_offset+=os.write(B.fd,L)
							except BrokenPipeError:E.unregister(B.fileobj);B.fileobj.close()
							else:
								if A._input_offset>=len(A._input):E.unregister(B.fileobj);B.fileobj.close()
						elif B.fileobj in(A.stdout,A.stderr):
							I=os.read(B.fd,32768)
							if not I:E.unregister(B.fileobj);B.fileobj.close()
							A._fileobj2output[B.fileobj].append(I)
			A.wait(timeout=A._remaining_time(F))
			if C is not _A:C=_E.join(C)
			if D is not _A:D=_E.join(D)
			if A.text_mode:
				if C is not _A:C=A._translate_newlines(C,A.stdout.encoding,A.stdout.errors)
				if D is not _A:D=A._translate_newlines(D,A.stderr.encoding,A.stderr.errors)
			return C,D
		def _save_input(A,input):
			if A.stdin and A._input is _A:
				A._input_offset=0;A._input=input
				if input is not _A and A.text_mode:A._input=A._input.encode(A.stdin.encoding,A.stdin.errors)
		def send_signal(A,sig):
			if A.returncode is _A:os.kill(A.pid,sig)
		def terminate(A):A.send_signal(signal.SIGTERM)
		def kill(A):A.send_signal(signal.SIGKILL)