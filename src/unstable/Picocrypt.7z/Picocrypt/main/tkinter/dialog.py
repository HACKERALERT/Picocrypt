_G='command'
_F='strings'
_E='default'
_D='bitmap'
_C='title'
_B='text'
_A=None
from tkinter import *
from tkinter import _cnfmerge
DIALOG_ICON='questhead'
class Dialog(Widget):
	def __init__(self,master=_A,cnf={},**kw):
		cnf=_cnfmerge((cnf,kw));self.widgetName='__dialog__';Widget._setup(self,master,cnf);self.num=self.tk.getint(self.tk.call('tk_dialog',self._w,cnf[_C],cnf[_B],cnf[_D],cnf[_E],*cnf[_F]))
		try:Widget.destroy(self)
		except TclError:pass
	def destroy(self):0
def _test():d=Dialog(_A,{_C:'File Modified',_B:'File "Python.h" has been modified since the last time it was saved. Do you want to save it before exiting the application.',_D:DIALOG_ICON,_E:0,_F:('Save File','Discard Changes','Return to Editor')});print(d.num)
if __name__=='__main__':t=Button(_A,{_B:'Test',_G:_test,Pack:{}});q=Button(_A,{_B:'Quit',_G:t.quit,Pack:{}});t.mainloop()