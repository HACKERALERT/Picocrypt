_M='__contains__'
_L='__len__'
_K='__next__'
_J='__anext__'
_I='close'
_H='throw'
_G='send'
_F='__await__'
_E='__aiter__'
_D='__iter__'
_C=True
_B=False
_A=None
from abc import ABCMeta,abstractmethod
import sys
__all__=['Awaitable','Coroutine','AsyncIterable','AsyncIterator','AsyncGenerator','Hashable','Iterable','Iterator','Generator','Reversible','Sized','Container','Callable','Collection','Set','MutableSet','Mapping','MutableMapping','MappingView','KeysView','ItemsView','ValuesView','Sequence','MutableSequence','ByteString']
__name__='collections.abc'
bytes_iterator=type(iter(b''))
bytearray_iterator=type(iter(bytearray()))
dict_keyiterator=type(iter({}.keys()))
dict_valueiterator=type(iter({}.values()))
dict_itemiterator=type(iter({}.items()))
list_iterator=type(iter([]))
list_reverseiterator=type(iter(reversed([])))
range_iterator=type(iter(range(0)))
longrange_iterator=type(iter(range(1<<1000)))
set_iterator=type(iter(set()))
str_iterator=type(iter(''))
tuple_iterator=type(iter(()))
zip_iterator=type(iter(zip()))
dict_keys=type({}.keys())
dict_values=type({}.values())
dict_items=type({}.items())
mappingproxy=type(type.__dict__)
generator=type((lambda:(yield))())
async def _coro():0
_coro=_coro()
coroutine=type(_coro)
_coro.close()
del _coro
async def _ag():yield
_ag=_ag()
async_generator=type(_ag)
del _ag
def _check_methods(C,*D):
	E=C.__mro__
	for A in D:
		for B in E:
			if A in B.__dict__:
				if B.__dict__[A]is _A:return NotImplemented
				break
		else:return NotImplemented
	return _C
class Hashable(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __hash__(self):return 0
	@classmethod
	def __subclasshook__(A,C):
		if A is Hashable:return _check_methods(C,'__hash__')
		return NotImplemented
class Awaitable(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __await__(self):yield
	@classmethod
	def __subclasshook__(A,C):
		if A is Awaitable:return _check_methods(C,_F)
		return NotImplemented
class Coroutine(Awaitable):
	__slots__=()
	@abstractmethod
	def send(self,value):raise StopIteration
	@abstractmethod
	def throw(self,typ,val=_A,tb=_A):
		A=val
		if A is _A:
			if tb is _A:raise typ
			A=typ()
		if tb is not _A:A=A.with_traceback(tb)
		raise A
	def close(A):
		try:A.throw(GeneratorExit)
		except (GeneratorExit,StopIteration):pass
		else:raise RuntimeError('coroutine ignored GeneratorExit')
	@classmethod
	def __subclasshook__(A,C):
		if A is Coroutine:return _check_methods(C,_F,_G,_H,_I)
		return NotImplemented
Coroutine.register(coroutine)
class AsyncIterable(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __aiter__(self):return AsyncIterator()
	@classmethod
	def __subclasshook__(A,C):
		if A is AsyncIterable:return _check_methods(C,_E)
		return NotImplemented
class AsyncIterator(AsyncIterable):
	__slots__=()
	@abstractmethod
	async def __anext__(self):raise StopAsyncIteration
	def __aiter__(A):return A
	@classmethod
	def __subclasshook__(A,C):
		if A is AsyncIterator:return _check_methods(C,_J,_E)
		return NotImplemented
class AsyncGenerator(AsyncIterator):
	__slots__=()
	async def __anext__(A):return await A.asend(_A)
	@abstractmethod
	async def asend(self,value):raise StopAsyncIteration
	@abstractmethod
	async def athrow(self,typ,val=_A,tb=_A):
		A=val
		if A is _A:
			if tb is _A:raise typ
			A=typ()
		if tb is not _A:A=A.with_traceback(tb)
		raise A
	async def aclose(A):
		try:await A.athrow(GeneratorExit)
		except (GeneratorExit,StopAsyncIteration):pass
		else:raise RuntimeError('asynchronous generator ignored GeneratorExit')
	@classmethod
	def __subclasshook__(A,C):
		if A is AsyncGenerator:return _check_methods(C,_E,_J,'asend','athrow','aclose')
		return NotImplemented
AsyncGenerator.register(async_generator)
class Iterable(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __iter__(self):
		while _B:yield _A
	@classmethod
	def __subclasshook__(A,C):
		if A is Iterable:return _check_methods(C,_D)
		return NotImplemented
class Iterator(Iterable):
	__slots__=()
	@abstractmethod
	def __next__(self):raise StopIteration
	def __iter__(A):return A
	@classmethod
	def __subclasshook__(A,C):
		if A is Iterator:return _check_methods(C,_D,_K)
		return NotImplemented
Iterator.register(bytes_iterator)
Iterator.register(bytearray_iterator)
Iterator.register(dict_keyiterator)
Iterator.register(dict_valueiterator)
Iterator.register(dict_itemiterator)
Iterator.register(list_iterator)
Iterator.register(list_reverseiterator)
Iterator.register(range_iterator)
Iterator.register(longrange_iterator)
Iterator.register(set_iterator)
Iterator.register(str_iterator)
Iterator.register(tuple_iterator)
Iterator.register(zip_iterator)
class Reversible(Iterable):
	__slots__=()
	@abstractmethod
	def __reversed__(self):
		while _B:yield _A
	@classmethod
	def __subclasshook__(A,C):
		if A is Reversible:return _check_methods(C,'__reversed__',_D)
		return NotImplemented
class Generator(Iterator):
	__slots__=()
	def __next__(A):return A.send(_A)
	@abstractmethod
	def send(self,value):raise StopIteration
	@abstractmethod
	def throw(self,typ,val=_A,tb=_A):
		A=val
		if A is _A:
			if tb is _A:raise typ
			A=typ()
		if tb is not _A:A=A.with_traceback(tb)
		raise A
	def close(A):
		try:A.throw(GeneratorExit)
		except (GeneratorExit,StopIteration):pass
		else:raise RuntimeError('generator ignored GeneratorExit')
	@classmethod
	def __subclasshook__(A,C):
		if A is Generator:return _check_methods(C,_D,_K,_G,_H,_I)
		return NotImplemented
Generator.register(generator)
class Sized(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __len__(self):return 0
	@classmethod
	def __subclasshook__(A,C):
		if A is Sized:return _check_methods(C,_L)
		return NotImplemented
class Container(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __contains__(self,x):return _B
	@classmethod
	def __subclasshook__(A,C):
		if A is Container:return _check_methods(C,_M)
		return NotImplemented
class Collection(Sized,Iterable,Container):
	__slots__=()
	@classmethod
	def __subclasshook__(A,C):
		if A is Collection:return _check_methods(C,_L,_D,_M)
		return NotImplemented
class Callable(metaclass=ABCMeta):
	__slots__=()
	@abstractmethod
	def __call__(self,*A,**B):return _B
	@classmethod
	def __subclasshook__(A,C):
		if A is Callable:return _check_methods(C,'__call__')
		return NotImplemented
class Set(Collection):
	__slots__=()
	def __le__(B,other):
		A=other
		if not isinstance(A,Set):return NotImplemented
		if len(B)>len(A):return _B
		for C in B:
			if C not in A:return _B
		return _C
	def __lt__(B,other):
		A=other
		if not isinstance(A,Set):return NotImplemented
		return len(B)<len(A)and B.__le__(A)
	def __gt__(B,other):
		A=other
		if not isinstance(A,Set):return NotImplemented
		return len(B)>len(A)and B.__ge__(A)
	def __ge__(B,other):
		A=other
		if not isinstance(A,Set):return NotImplemented
		if len(B)<len(A):return _B
		for C in A:
			if C not in B:return _B
		return _C
	def __eq__(B,other):
		A=other
		if not isinstance(A,Set):return NotImplemented
		return len(B)==len(A)and B.__le__(A)
	@classmethod
	def _from_iterable(A,it):return A(it)
	def __and__(A,other):
		B=other
		if not isinstance(B,Iterable):return NotImplemented
		return A._from_iterable((C for C in B if C in A))
	__rand__=__and__
	def isdisjoint(A,other):
		for B in other:
			if B in A:return _B
		return _C
	def __or__(A,other):
		B=other
		if not isinstance(B,Iterable):return NotImplemented
		C=(D for C in(A,B)for D in C);return A._from_iterable(C)
	__ror__=__or__
	def __sub__(B,other):
		A=other
		if not isinstance(A,Set):
			if not isinstance(A,Iterable):return NotImplemented
			A=B._from_iterable(A)
		return B._from_iterable((C for C in B if C not in A))
	def __rsub__(B,other):
		A=other
		if not isinstance(A,Set):
			if not isinstance(A,Iterable):return NotImplemented
			A=B._from_iterable(A)
		return B._from_iterable((C for C in A if C not in B))
	def __xor__(B,other):
		A=other
		if not isinstance(A,Set):
			if not isinstance(A,Iterable):return NotImplemented
			A=B._from_iterable(A)
		return B-A|A-B
	__rxor__=__xor__
	def _hash(C):
		D=sys.maxsize;B=2*D+1;F=len(C);A=1927868237*(F+1);A&=B
		for G in C:E=hash(G);A^=(E^E<<16^89869747)*3644798167;A&=B
		A=A*69069+907133923;A&=B
		if A>D:A-=B+1
		if A==-1:A=590923713
		return A
Set.register(frozenset)
class MutableSet(Set):
	__slots__=()
	@abstractmethod
	def add(self,value):raise NotImplementedError
	@abstractmethod
	def discard(self,value):raise NotImplementedError
	def remove(B,value):
		A=value
		if A not in B:raise KeyError(A)
		B.discard(A)
	def pop(A):
		C=iter(A)
		try:B=next(C)
		except StopIteration:raise KeyError from _A
		A.discard(B);return B
	def clear(A):
		try:
			while _C:A.pop()
		except KeyError:pass
	def __ior__(A,it):
		for B in it:A.add(B)
		return A
	def __iand__(A,it):
		for B in A-it:A.discard(B)
		return A
	def __ixor__(A,it):
		B=it
		if B is A:A.clear()
		else:
			if not isinstance(B,Set):B=A._from_iterable(B)
			for C in B:
				if C in A:A.discard(C)
				else:A.add(C)
		return A
	def __isub__(A,it):
		if it is A:A.clear()
		else:
			for B in it:A.discard(B)
		return A
MutableSet.register(set)
class Mapping(Collection):
	__slots__=()
	@abstractmethod
	def __getitem__(self,key):raise KeyError
	def get(A,key,default=_A):
		try:return A[key]
		except KeyError:return default
	def __contains__(A,key):
		try:A[key]
		except KeyError:return _B
		else:return _C
	def keys(A):return KeysView(A)
	def items(A):return ItemsView(A)
	def values(A):return ValuesView(A)
	def __eq__(B,other):
		A=other
		if not isinstance(A,Mapping):return NotImplemented
		return dict(B.items())==dict(A.items())
	__reversed__=_A
Mapping.register(mappingproxy)
class MappingView(Sized):
	__slots__='_mapping',
	def __init__(A,mapping):A._mapping=mapping
	def __len__(A):return len(A._mapping)
	def __repr__(A):return '{0.__class__.__name__}({0._mapping!r})'.format(A)
class KeysView(MappingView,Set):
	__slots__=()
	@classmethod
	def _from_iterable(A,it):return set(it)
	def __contains__(A,key):return key in A._mapping
	def __iter__(A):yield from A._mapping
KeysView.register(dict_keys)
class ItemsView(MappingView,Set):
	__slots__=()
	@classmethod
	def _from_iterable(A,it):return set(it)
	def __contains__(C,item):
		D,A=item
		try:B=C._mapping[D]
		except KeyError:return _B
		else:return B is A or B==A
	def __iter__(A):
		for B in A._mapping:yield(B,A._mapping[B])
ItemsView.register(dict_items)
class ValuesView(MappingView,Collection):
	__slots__=()
	def __contains__(A,value):
		B=value
		for D in A._mapping:
			C=A._mapping[D]
			if C is B or C==B:return _C
		return _B
	def __iter__(A):
		for B in A._mapping:yield A._mapping[B]
ValuesView.register(dict_values)
class MutableMapping(Mapping):
	__slots__=()
	@abstractmethod
	def __setitem__(self,key,value):raise KeyError
	@abstractmethod
	def __delitem__(self,key):raise KeyError
	__marker=object()
	def pop(A,key,default=__marker):
		B=default
		try:C=A[key]
		except KeyError:
			if B is A.__marker:raise
			return B
		else:del A[key];return C
	def popitem(A):
		try:B=next(iter(A))
		except StopIteration:raise KeyError from _A
		C=A[B];del A[B];return B,C
	def clear(A):
		try:
			while _C:A.popitem()
		except KeyError:pass
	def update(C,B=(),**E):
		if isinstance(B,Mapping):
			for A in B:C[A]=B[A]
		elif hasattr(B,'keys'):
			for A in B.keys():C[A]=B[A]
		else:
			for (A,D) in B:C[A]=D
		for (A,D) in E.items():C[A]=D
	def setdefault(A,key,default=_A):
		B=default
		try:return A[key]
		except KeyError:A[key]=B
		return B
MutableMapping.register(dict)
class Sequence(Reversible,Collection):
	__slots__=()
	@abstractmethod
	def __getitem__(self,index):raise IndexError
	def __iter__(B):
		A=0
		try:
			while _C:C=B[A];yield C;A+=1
		except IndexError:return
	def __contains__(C,value):
		A=value
		for B in C:
			if B is A or B==A:return _C
		return _B
	def __reversed__(A):
		for B in reversed(range(len(A))):yield A[B]
	def index(D,value,start=0,stop=_A):
		E=value;B=stop;A=start
		if A is not _A and A<0:A=max(len(D)+A,0)
		if B is not _A and B<0:B+=len(D)
		C=A
		while B is _A or C<B:
			try:
				F=D[C]
				if F is E or F==E:return C
			except IndexError:break
			C+=1
		raise ValueError
	def count(C,value):A=value;return sum((1 for B in C if B is A or B==A))
Sequence.register(tuple)
Sequence.register(str)
Sequence.register(range)
Sequence.register(memoryview)
class ByteString(Sequence):__slots__=()
ByteString.register(bytes)
ByteString.register(bytearray)
class MutableSequence(Sequence):
	__slots__=()
	@abstractmethod
	def __setitem__(self,index,value):raise IndexError
	@abstractmethod
	def __delitem__(self,index):raise IndexError
	@abstractmethod
	def insert(self,index,value):raise IndexError
	def append(A,value):A.insert(len(A),value)
	def clear(A):
		try:
			while _C:A.pop()
		except IndexError:pass
	def reverse(A):
		C=len(A)
		for B in range(C//2):A[B],A[C-B-1]=A[C-B-1],A[B]
	def extend(B,values):
		A=values
		if A is B:A=list(A)
		for C in A:B.append(C)
	def pop(A,index=-1):B=index;C=A[B];del A[B];return C
	def remove(A,value):del A[A.index(value)]
	def __iadd__(A,values):A.extend(values);return A
MutableSequence.register(list)
MutableSequence.register(bytearray)