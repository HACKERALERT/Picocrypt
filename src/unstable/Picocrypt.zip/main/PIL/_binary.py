from struct import pack,unpack_from
def i8(c):return c if c.__class__ is int else c[0]
def o8(i):return bytes((i&255,))
def i16le(c,o=0):return unpack_from('<H',c,o)[0]
def si16le(c,o=0):return unpack_from('<h',c,o)[0]
def i32le(c,o=0):return unpack_from('<I',c,o)[0]
def si32le(c,o=0):return unpack_from('<i',c,o)[0]
def i16be(c,o=0):return unpack_from('>H',c,o)[0]
def i32be(c,o=0):return unpack_from('>I',c,o)[0]
def o16le(i):return pack('<H',i)
def o32le(i):return pack('<I',i)
def o16be(i):return pack('>H',i)
def o32be(i):return pack('>I',i)