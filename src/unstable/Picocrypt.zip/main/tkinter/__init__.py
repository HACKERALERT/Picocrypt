_Ay='coord'
_Ax='transparency'
_Aw='menubutton'
_Av='cascade'
_Au='range'
_At='present'
_As='deselect'
_Ar='scale'
_Aq='itemconfigure'
_Ap='itemcget'
_Ao='bitmap'
_An='coords'
_Am='withtag'
_Al='overlapping'
_Ak='enclosed'
_Aj='closest'
_Ai='below'
_Ah='above'
_Ag='destroy'
_Af='WM_DELETE_WINDOW'
_Ae='-default'
_Ad='frame'
_Ac='scroll'
_Ab='types'
_Aa='update'
_AZ='visual'
_AY='toplevel'
_AX='screen'
_AW='geometry'
_AV='UTF8_STRING'
_AU='copy'
_AT='separator'
_AS='radiobutton'
_AR='activate'
_AQ='checkbutton'
_AP='from'
_AO='adjust'
_AN='icursor'
_AM='text'
_AL='flash'
_AK='moveto'
_AJ='xview'
_AI='anchor'
_AH='slaves'
_AG='raise'
_AF='lower'
_AE='-displayof'
_AD='tkwait'
_AC='invalid literal for getboolean()'
_AB='remove'
_AA='exists'
_A9='height'
_A8='width'
_A7='delta'
_A6='identify'
_A5='menu'
_A4='class_'
_A3='yview'
_A2='event'
_A1='propagate'
_A0='all'
_z='option'
_y='clipboard'
_x='after'
_v='PY_VAR'
_u='state'
_t=True
_s='dragto'
_r='create'
_q='invoke'
_p='bbox'
_o='class'
_n='grab'
_m='variable'
_l=False
_k='name'
_j='insert'
_i='index'
_h='forget'
_g='place'
_f='pack'
_e='cget'
_d='.'
_c='none'
_b='window'
_a='add'
_Z='trace'
_Y='select'
_X='names'
_W='_'
_V='clear'
_U='focus'
_T='command'
_S='set'
_R='info'
_Q='scan'
_P='in'
_O='delete'
_N='type'
_M='configure'
_L='bind'
_K='displayof'
_J='mark'
_I='tag'
_H='image'
_G='grid'
_F='get'
_E='selection'
_D='-'
_C='wm'
_B='winfo'
_A=None
import enum,sys,_tkinter
TclError=_tkinter.TclError
from tkinter.constants import *
import re
wantobjects=1
TkVersion=float(_tkinter.TK_VERSION)
TclVersion=float(_tkinter.TCL_VERSION)
READABLE=_tkinter.READABLE
WRITABLE=_tkinter.WRITABLE
EXCEPTION=_tkinter.EXCEPTION
_magic_re=re.compile('([\\\\{}])')
_space_re=re.compile('([\\s])',re.ASCII)
def _join(value):return ' '.join(map(_stringify,value))
def _stringify(value):
	C='"';B='\\\\\\1';A='{%s}'
	if isinstance(value,(list,tuple)):
		if len(value)==1:
			value=_stringify(value[0])
			if _magic_re.search(value):value=A%value
		else:value=A%_join(value)
	else:
		value=str(value)
		if not value:value='{}'
		elif _magic_re.search(value):
			value=_magic_re.sub(B,value);value=value.replace('\n','\\n');value=_space_re.sub(B,value)
			if value[0]==C:value='\\'+value
		elif value[0]==C or _space_re.search(value):value=A%value
	return value
def _flatten(seq):
	res=()
	for item in seq:
		if isinstance(item,(tuple,list)):res=res+_flatten(item)
		elif item is not _A:res=res+(item,)
	return res
try:_flatten=_tkinter._flatten
except AttributeError:pass
def _cnfmerge(cnfs):
	if isinstance(cnfs,dict):return cnfs
	elif isinstance(cnfs,(type(_A),str)):return cnfs
	else:
		cnf={}
		for c in _flatten(cnfs):
			try:cnf.update(c)
			except (AttributeError,TypeError)as msg:
				print('_cnfmerge: fallback due to:',msg)
				for (k,v) in c.items():cnf[k]=v
		return cnf
try:_cnfmerge=_tkinter._cnfmerge
except AttributeError:pass
def _splitdict(tk,v,cut_minus=_t,conv=_A):
	t=tk.splitlist(v)
	if len(t)%2:raise RuntimeError('Tcl list representing a dict is expected to contain an even number of elements')
	it=iter(t);dict={}
	for (key,value) in zip(it,it):
		key=str(key)
		if cut_minus and key[0]==_D:key=key[1:]
		if conv:value=conv(value)
		dict[key]=value
	return dict
class EventType(str,enum.Enum):KeyPress='2';Key=KeyPress;KeyRelease='3';ButtonPress='4';Button=ButtonPress;ButtonRelease='5';Motion='6';Enter='7';Leave='8';FocusIn='9';FocusOut='10';Keymap='11';Expose='12';GraphicsExpose='13';NoExpose='14';Visibility='15';Create='16';Destroy='17';Unmap='18';Map='19';MapRequest='20';Reparent='21';Configure='22';ConfigureRequest='23';Gravity='24';ResizeRequest='25';Circulate='26';CirculateRequest='27';Property='28';SelectionClear='29';SelectionRequest='30';Selection='31';Colormap='32';ClientMessage='33';Mapping='34';VirtualEvent='35';Activate='36';Deactivate='37';MouseWheel='38';__str__=str.__str__
class Event:
	def __repr__(self):
		C='??';B='send_event';A='char';attrs={k:v for(k,v)in self.__dict__.items()if v!=C}
		if not self.char:del attrs[A]
		elif self.char!=C:attrs[A]=repr(self.char)
		if not getattr(self,B,_t):del attrs[B]
		if self.state==0:del attrs[_u]
		elif isinstance(self.state,int):
			state=self.state;mods='Shift','Lock','Control','Mod1','Mod2','Mod3','Mod4','Mod5','Button1','Button2','Button3','Button4','Button5';s=[]
			for (i,n) in enumerate(mods):
				if state&1<<i:s.append(n)
			state=state&~((1<<len(mods))-1)
			if state or not s:s.append(hex(state))
			attrs[_u]='|'.join(s)
		if self.delta==0:del attrs[_A7]
		keys=B,_u,'keysym','keycode',A,'num',_A7,_U,'x','y',_A8,_A9;return'<%s event%s>'%(getattr(self.type,_k,self.type),''.join((' %s=%s'%(k,attrs[k])for k in keys if k in attrs)))
_support_default_root=_t
_default_root=_A
def NoDefaultRoot():global _support_default_root,_default_root;_support_default_root=_l;_default_root=_A;del _default_root
def _get_default_root(what=_A):
	if not _support_default_root:raise RuntimeError('No master specified and tkinter is configured to not support default root')
	if not _default_root:
		if what:raise RuntimeError(f"Too early to {what}: no default root window")
		root=Tk();assert _default_root is root
	return _default_root
def _tkerror(err):0
def _exit(code=0):
	try:code=int(code)
	except ValueError:pass
	raise SystemExit(code)
_varnum=0
class Variable:
	_default='';_tk=_A;_tclCommands=_A
	def __init__(self,master=_A,value=_A,name=_A):
		if name is not _A and not isinstance(name,str):raise TypeError('name must be a string')
		global _varnum
		if not master:master=_get_default_root('create variable')
		self._root=master._root();self._tk=master.tk
		if name:self._name=name
		else:self._name=_v+repr(_varnum);_varnum+=1
		if value is not _A:self.initialize(value)
		elif not self._tk.getboolean(self._tk.call(_R,_AA,self._name)):self.initialize(self._default)
	def __del__(self):
		if self._tk is _A:return
		if self._tk.getboolean(self._tk.call(_R,_AA,self._name)):self._tk.globalunsetvar(self._name)
		if self._tclCommands is not _A:
			for name in self._tclCommands:self._tk.deletecommand(name)
			self._tclCommands=_A
	def __str__(self):return self._name
	def set(self,value):return self._tk.globalsetvar(self._name,value)
	initialize=set
	def get(self):return self._tk.globalgetvar(self._name)
	def _register(self,callback):
		f=CallWrapper(callback,_A,self._root).__call__;cbname=repr(id(f))
		try:callback=callback.__func__
		except AttributeError:pass
		try:cbname=cbname+callback.__name__
		except AttributeError:pass
		self._tk.createcommand(cbname,f)
		if self._tclCommands is _A:self._tclCommands=[]
		self._tclCommands.append(cbname);return cbname
	def trace_add(self,mode,callback):cbname=self._register(callback);self._tk.call(_Z,_a,_m,self._name,mode,(cbname,));return cbname
	def trace_remove(self,mode,cbname):
		self._tk.call(_Z,_AB,_m,self._name,mode,cbname)
		for (m,ca) in self.trace_info():
			if self._tk.splitlist(ca)[0]==cbname:break
		else:
			self._tk.deletecommand(cbname)
			try:self._tclCommands.remove(cbname)
			except ValueError:pass
	def trace_info(self):splitlist=self._tk.splitlist;return[(splitlist(k),v)for(k,v)in map(splitlist,splitlist(self._tk.call(_Z,_R,_m,self._name)))]
	def trace_variable(self,mode,callback):cbname=self._register(callback);self._tk.call(_Z,_m,self._name,mode,cbname);return cbname
	trace=trace_variable
	def trace_vdelete(self,mode,cbname):
		self._tk.call(_Z,'vdelete',self._name,mode,cbname);cbname=self._tk.splitlist(cbname)[0]
		for (m,ca) in self.trace_info():
			if self._tk.splitlist(ca)[0]==cbname:break
		else:
			self._tk.deletecommand(cbname)
			try:self._tclCommands.remove(cbname)
			except ValueError:pass
	def trace_vinfo(self):return[self._tk.splitlist(x)for x in self._tk.splitlist(self._tk.call(_Z,'vinfo',self._name))]
	def __eq__(self,other):
		if not isinstance(other,Variable):return NotImplemented
		return self._name==other._name and self.__class__.__name__==other.__class__.__name__ and self._tk==other._tk
class StringVar(Variable):
	_default=''
	def __init__(self,master=_A,value=_A,name=_A):Variable.__init__(self,master,value,name)
	def get(self):
		value=self._tk.globalgetvar(self._name)
		if isinstance(value,str):return value
		return str(value)
class IntVar(Variable):
	_default=0
	def __init__(self,master=_A,value=_A,name=_A):Variable.__init__(self,master,value,name)
	def get(self):
		value=self._tk.globalgetvar(self._name)
		try:return self._tk.getint(value)
		except (TypeError,TclError):return int(self._tk.getdouble(value))
class DoubleVar(Variable):
	_default=0.0
	def __init__(self,master=_A,value=_A,name=_A):Variable.__init__(self,master,value,name)
	def get(self):return self._tk.getdouble(self._tk.globalgetvar(self._name))
class BooleanVar(Variable):
	_default=_l
	def __init__(self,master=_A,value=_A,name=_A):Variable.__init__(self,master,value,name)
	def set(self,value):return self._tk.globalsetvar(self._name,self._tk.getboolean(value))
	initialize=set
	def get(self):
		try:return self._tk.getboolean(self._tk.globalgetvar(self._name))
		except TclError:raise ValueError(_AC)
def mainloop(n=0):_get_default_root('run the main loop').tk.mainloop(n)
getint=int
getdouble=float
def getboolean(s):
	try:return _get_default_root('use getboolean()').tk.getboolean(s)
	except TclError:raise ValueError(_AC)
class Misc:
	_last_child_ids=_A;_tclCommands=_A
	def destroy(self):
		if self._tclCommands is not _A:
			for name in self._tclCommands:self.tk.deletecommand(name)
			self._tclCommands=_A
	def deletecommand(self,name):
		self.tk.deletecommand(name)
		try:self._tclCommands.remove(name)
		except ValueError:pass
	def tk_strictMotif(self,boolean=_A):return self.tk.getboolean(self.tk.call(_S,'tk_strictMotif',boolean))
	def tk_bisque(self):self.tk.call('tk_bisque')
	def tk_setPalette(self,*args,**kw):self.tk.call(('tk_setPalette',)+_flatten(args)+_flatten(list(kw.items())))
	def wait_variable(self,name=_v):self.tk.call(_AD,_m,name)
	waitvar=wait_variable
	def wait_window(self,window=_A):
		if window is _A:window=self
		self.tk.call(_AD,_b,window._w)
	def wait_visibility(self,window=_A):
		if window is _A:window=self
		self.tk.call(_AD,'visibility',window._w)
	def setvar(self,name=_v,value='1'):self.tk.setvar(name,value)
	def getvar(self,name=_v):return self.tk.getvar(name)
	def getint(self,s):
		try:return self.tk.getint(s)
		except TclError as exc:raise ValueError(str(exc))
	def getdouble(self,s):
		try:return self.tk.getdouble(s)
		except TclError as exc:raise ValueError(str(exc))
	def getboolean(self,s):
		try:return self.tk.getboolean(s)
		except TclError:raise ValueError(_AC)
	def focus_set(self):self.tk.call(_U,self._w)
	focus=focus_set
	def focus_force(self):self.tk.call(_U,'-force',self._w)
	def focus_get(self):
		name=self.tk.call(_U)
		if name==_c or not name:return _A
		return self._nametowidget(name)
	def focus_displayof(self):
		name=self.tk.call(_U,_AE,self._w)
		if name==_c or not name:return _A
		return self._nametowidget(name)
	def focus_lastfor(self):
		name=self.tk.call(_U,'-lastfor',self._w)
		if name==_c or not name:return _A
		return self._nametowidget(name)
	def tk_focusFollowsMouse(self):self.tk.call('tk_focusFollowsMouse')
	def tk_focusNext(self):
		name=self.tk.call('tk_focusNext',self._w)
		if not name:return _A
		return self._nametowidget(name)
	def tk_focusPrev(self):
		name=self.tk.call('tk_focusPrev',self._w)
		if not name:return _A
		return self._nametowidget(name)
	def after(self,ms,func=_A,*args):
		if not func:self.tk.call(_x,ms);return _A
		else:
			def callit():
				try:func(*args)
				finally:
					try:self.deletecommand(name)
					except TclError:pass
			callit.__name__=func.__name__;name=self._register(callit);return self.tk.call(_x,ms,name)
	def after_idle(self,func,*args):return self.after('idle',func,*args)
	def after_cancel(self,id):
		if not id:raise ValueError('id must be a valid identifier returned from after or after_idle')
		try:data=self.tk.call(_x,_R,id);script=self.tk.splitlist(data)[0];self.deletecommand(script)
		except TclError:pass
		self.tk.call(_x,'cancel',id)
	def bell(self,displayof=0):self.tk.call(('bell',)+self._displayof(displayof))
	def clipboard_get(self,**kw):
		if _N not in kw and self._windowingsystem=='x11':
			try:kw[_N]=_AV;return self.tk.call((_y,_F)+self._options(kw))
			except TclError:del kw[_N]
		return self.tk.call((_y,_F)+self._options(kw))
	def clipboard_clear(self,**kw):
		if _K not in kw:kw[_K]=self._w
		self.tk.call((_y,_V)+self._options(kw))
	def clipboard_append(self,string,**kw):
		if _K not in kw:kw[_K]=self._w
		self.tk.call((_y,'append')+self._options(kw)+('--',string))
	def grab_current(self):
		name=self.tk.call(_n,'current',self._w)
		if not name:return _A
		return self._nametowidget(name)
	def grab_release(self):self.tk.call(_n,'release',self._w)
	def grab_set(self):self.tk.call(_n,_S,self._w)
	def grab_set_global(self):self.tk.call(_n,_S,'-global',self._w)
	def grab_status(self):
		status=self.tk.call(_n,'status',self._w)
		if status==_c:status=_A
		return status
	def option_add(self,pattern,value,priority=_A):self.tk.call(_z,_a,pattern,value,priority)
	def option_clear(self):self.tk.call(_z,_V)
	def option_get(self,name,className):return self.tk.call(_z,_F,self._w,name,className)
	def option_readfile(self,fileName,priority=_A):self.tk.call(_z,'readfile',fileName,priority)
	def selection_clear(self,**kw):
		if _K not in kw:kw[_K]=self._w
		self.tk.call((_E,_V)+self._options(kw))
	def selection_get(self,**kw):
		if _K not in kw:kw[_K]=self._w
		if _N not in kw and self._windowingsystem=='x11':
			try:kw[_N]=_AV;return self.tk.call((_E,_F)+self._options(kw))
			except TclError:del kw[_N]
		return self.tk.call((_E,_F)+self._options(kw))
	def selection_handle(self,command,**kw):name=self._register(command);self.tk.call((_E,'handle')+self._options(kw)+(self._w,name))
	def selection_own(self,**kw):self.tk.call((_E,'own')+self._options(kw)+(self._w,))
	def selection_own_get(self,**kw):
		if _K not in kw:kw[_K]=self._w
		name=self.tk.call((_E,'own')+self._options(kw))
		if not name:return _A
		return self._nametowidget(name)
	def send(self,interp,cmd,*args):return self.tk.call(('send',interp,cmd)+args)
	def lower(self,belowThis=_A):self.tk.call(_AF,self._w,belowThis)
	def tkraise(self,aboveThis=_A):self.tk.call(_AG,self._w,aboveThis)
	lift=tkraise
	def winfo_atom(self,name,displayof=0):args=(_B,'atom')+self._displayof(displayof)+(name,);return self.tk.getint(self.tk.call(args))
	def winfo_atomname(self,id,displayof=0):args=(_B,'atomname')+self._displayof(displayof)+(id,);return self.tk.call(args)
	def winfo_cells(self):return self.tk.getint(self.tk.call(_B,'cells',self._w))
	def winfo_children(self):
		result=[]
		for child in self.tk.splitlist(self.tk.call(_B,'children',self._w)):
			try:result.append(self._nametowidget(child))
			except KeyError:pass
		return result
	def winfo_class(self):return self.tk.call(_B,_o,self._w)
	def winfo_colormapfull(self):return self.tk.getboolean(self.tk.call(_B,'colormapfull',self._w))
	def winfo_containing(self,rootX,rootY,displayof=0):
		args=(_B,'containing')+self._displayof(displayof)+(rootX,rootY);name=self.tk.call(args)
		if not name:return _A
		return self._nametowidget(name)
	def winfo_depth(self):return self.tk.getint(self.tk.call(_B,'depth',self._w))
	def winfo_exists(self):return self.tk.getint(self.tk.call(_B,_AA,self._w))
	def winfo_fpixels(self,number):return self.tk.getdouble(self.tk.call(_B,'fpixels',self._w,number))
	def winfo_geometry(self):return self.tk.call(_B,_AW,self._w)
	def winfo_height(self):return self.tk.getint(self.tk.call(_B,_A9,self._w))
	def winfo_id(self):return int(self.tk.call(_B,'id',self._w),0)
	def winfo_interps(self,displayof=0):args=(_B,'interps')+self._displayof(displayof);return self.tk.splitlist(self.tk.call(args))
	def winfo_ismapped(self):return self.tk.getint(self.tk.call(_B,'ismapped',self._w))
	def winfo_manager(self):return self.tk.call(_B,'manager',self._w)
	def winfo_name(self):return self.tk.call(_B,_k,self._w)
	def winfo_parent(self):return self.tk.call(_B,'parent',self._w)
	def winfo_pathname(self,id,displayof=0):args=(_B,'pathname')+self._displayof(displayof)+(id,);return self.tk.call(args)
	def winfo_pixels(self,number):return self.tk.getint(self.tk.call(_B,'pixels',self._w,number))
	def winfo_pointerx(self):return self.tk.getint(self.tk.call(_B,'pointerx',self._w))
	def winfo_pointerxy(self):return self._getints(self.tk.call(_B,'pointerxy',self._w))
	def winfo_pointery(self):return self.tk.getint(self.tk.call(_B,'pointery',self._w))
	def winfo_reqheight(self):return self.tk.getint(self.tk.call(_B,'reqheight',self._w))
	def winfo_reqwidth(self):return self.tk.getint(self.tk.call(_B,'reqwidth',self._w))
	def winfo_rgb(self,color):return self._getints(self.tk.call(_B,'rgb',self._w,color))
	def winfo_rootx(self):return self.tk.getint(self.tk.call(_B,'rootx',self._w))
	def winfo_rooty(self):return self.tk.getint(self.tk.call(_B,'rooty',self._w))
	def winfo_screen(self):return self.tk.call(_B,_AX,self._w)
	def winfo_screencells(self):return self.tk.getint(self.tk.call(_B,'screencells',self._w))
	def winfo_screendepth(self):return self.tk.getint(self.tk.call(_B,'screendepth',self._w))
	def winfo_screenheight(self):return self.tk.getint(self.tk.call(_B,'screenheight',self._w))
	def winfo_screenmmheight(self):return self.tk.getint(self.tk.call(_B,'screenmmheight',self._w))
	def winfo_screenmmwidth(self):return self.tk.getint(self.tk.call(_B,'screenmmwidth',self._w))
	def winfo_screenvisual(self):return self.tk.call(_B,'screenvisual',self._w)
	def winfo_screenwidth(self):return self.tk.getint(self.tk.call(_B,'screenwidth',self._w))
	def winfo_server(self):return self.tk.call(_B,'server',self._w)
	def winfo_toplevel(self):return self._nametowidget(self.tk.call(_B,_AY,self._w))
	def winfo_viewable(self):return self.tk.getint(self.tk.call(_B,'viewable',self._w))
	def winfo_visual(self):return self.tk.call(_B,_AZ,self._w)
	def winfo_visualid(self):return self.tk.call(_B,'visualid',self._w)
	def winfo_visualsavailable(self,includeids=_l):data=self.tk.call(_B,'visualsavailable',self._w,'includeids'if includeids else _A);data=[self.tk.splitlist(x)for x in self.tk.splitlist(data)];return[self.__winfo_parseitem(x)for x in data]
	def __winfo_parseitem(self,t):return t[:1]+tuple(map(self.__winfo_getint,t[1:]))
	def __winfo_getint(self,x):return int(x,0)
	def winfo_vrootheight(self):return self.tk.getint(self.tk.call(_B,'vrootheight',self._w))
	def winfo_vrootwidth(self):return self.tk.getint(self.tk.call(_B,'vrootwidth',self._w))
	def winfo_vrootx(self):return self.tk.getint(self.tk.call(_B,'vrootx',self._w))
	def winfo_vrooty(self):return self.tk.getint(self.tk.call(_B,'vrooty',self._w))
	def winfo_width(self):return self.tk.getint(self.tk.call(_B,_A8,self._w))
	def winfo_x(self):return self.tk.getint(self.tk.call(_B,'x',self._w))
	def winfo_y(self):return self.tk.getint(self.tk.call(_B,'y',self._w))
	def update(self):self.tk.call(_Aa)
	def update_idletasks(self):self.tk.call(_Aa,'idletasks')
	def bindtags(self,tagList=_A):
		A='bindtags'
		if tagList is _A:return self.tk.splitlist(self.tk.call(A,self._w))
		else:self.tk.call(A,self._w,tagList)
	def _bind(self,what,sequence,func,add,needcleanup=1):
		if isinstance(func,str):self.tk.call(what+(sequence,func))
		elif func:funcid=self._register(func,self._substitute,needcleanup);cmd='%sif {"[%s %s]" == "break"} break\n'%(add and'+'or'',funcid,self._subst_format_str);self.tk.call(what+(sequence,cmd));return funcid
		elif sequence:return self.tk.call(what+(sequence,))
		else:return self.tk.splitlist(self.tk.call(what))
	def bind(self,sequence=_A,func=_A,add=_A):return self._bind((_L,self._w),sequence,func,add)
	def unbind(self,sequence,funcid=_A):
		self.tk.call(_L,self._w,sequence,'')
		if funcid:self.deletecommand(funcid)
	def bind_all(self,sequence=_A,func=_A,add=_A):return self._bind((_L,_A0),sequence,func,add,0)
	def unbind_all(self,sequence):self.tk.call(_L,_A0,sequence,'')
	def bind_class(self,className,sequence=_A,func=_A,add=_A):return self._bind((_L,className),sequence,func,add,0)
	def unbind_class(self,className,sequence):self.tk.call(_L,className,sequence,'')
	def mainloop(self,n=0):self.tk.mainloop(n)
	def quit(self):self.tk.quit()
	def _getints(self,string):
		if string:return tuple(map(self.tk.getint,self.tk.splitlist(string)))
	def _getdoubles(self,string):
		if string:return tuple(map(self.tk.getdouble,self.tk.splitlist(string)))
	def _getboolean(self,string):
		if string:return self.tk.getboolean(string)
	def _displayof(self,displayof):
		if displayof:return _AE,displayof
		if displayof is _A:return _AE,self._w
		return()
	@property
	def _windowingsystem(self):
		try:return self._root()._windowingsystem_cached
		except AttributeError:ws=self._root()._windowingsystem_cached=self.tk.call('tk','windowingsystem');return ws
	def _options(self,cnf,kw=_A):
		if kw:cnf=_cnfmerge((cnf,kw))
		else:cnf=_cnfmerge(cnf)
		res=()
		for (k,v) in cnf.items():
			if v is not _A:
				if k[-1]==_W:k=k[:-1]
				if callable(v):v=self._register(v)
				elif isinstance(v,(tuple,list)):
					nv=[]
					for item in v:
						if isinstance(item,int):nv.append(str(item))
						elif isinstance(item,str):nv.append(_stringify(item))
						else:break
					else:v=' '.join(nv)
				res=res+(_D+k,v)
		return res
	def nametowidget(self,name):
		name=str(name).split(_d);w=self
		if not name[0]:w=w._root();name=name[1:]
		for n in name:
			if not n:break
			w=w.children[n]
		return w
	_nametowidget=nametowidget
	def _register(self,func,subst=_A,needcleanup=1):
		f=CallWrapper(func,subst,self).__call__;name=repr(id(f))
		try:func=func.__func__
		except AttributeError:pass
		try:name=name+func.__name__
		except AttributeError:pass
		self.tk.createcommand(name,f)
		if needcleanup:
			if self._tclCommands is _A:self._tclCommands=[]
			self._tclCommands.append(name)
		return name
	register=_register
	def _root(self):
		w=self
		while w.master:w=w.master
		return w
	_subst_format='%#','%b','%f','%h','%k','%s','%t','%w','%x','%y','%A','%E','%K','%N','%W','%T','%X','%Y','%D';_subst_format_str=' '.join(_subst_format)
	def _substitute(self,*args):
		if len(args)!=len(self._subst_format):return args
		getboolean=self.tk.getboolean;getint=self.tk.getint
		def getint_event(s):
			try:return getint(s)
			except (ValueError,TclError):return s
		nsign,b,f,h,k,s,t,w,x,y,A,E,K,N,W,T,X,Y,D=args;e=Event();e.serial=getint(nsign);e.num=getint_event(b)
		try:e.focus=getboolean(f)
		except TclError:pass
		e.height=getint_event(h);e.keycode=getint_event(k);e.state=getint_event(s);e.time=getint_event(t);e.width=getint_event(w);e.x=getint_event(x);e.y=getint_event(y);e.char=A
		try:e.send_event=getboolean(E)
		except TclError:pass
		e.keysym=K;e.keysym_num=getint_event(N)
		try:e.type=EventType(T)
		except ValueError:e.type=T
		try:e.widget=self._nametowidget(W)
		except KeyError:e.widget=W
		e.x_root=getint_event(X);e.y_root=getint_event(Y)
		try:e.delta=getint(D)
		except (ValueError,TclError):e.delta=0
		return e,
	def _report_exception(self):exc,val,tb=sys.exc_info();root=self._root();root.report_callback_exception(exc,val,tb)
	def _getconfigure(self,*args):
		cnf={}
		for x in self.tk.splitlist(self.tk.call(*args)):x=self.tk.splitlist(x);cnf[x[0][1:]]=(x[0][1:],)+x[1:]
		return cnf
	def _getconfigure1(self,*args):x=self.tk.splitlist(self.tk.call(*args));return(x[0][1:],)+x[1:]
	def _configure(self,cmd,cnf,kw):
		if kw:cnf=_cnfmerge((cnf,kw))
		elif cnf:cnf=_cnfmerge(cnf)
		if cnf is _A:return self._getconfigure(_flatten((self._w,cmd)))
		if isinstance(cnf,str):return self._getconfigure1(_flatten((self._w,cmd,_D+cnf)))
		self.tk.call(_flatten((self._w,cmd))+self._options(cnf))
	def configure(self,cnf=_A,**kw):return self._configure(_M,cnf,kw)
	config=configure
	def cget(self,key):return self.tk.call(self._w,_e,_D+key)
	__getitem__=cget
	def __setitem__(self,key,value):self.configure({key:value})
	def keys(self):splitlist=self.tk.splitlist;return[splitlist(x)[0][1:]for x in splitlist(self.tk.call(self._w,_M))]
	def __str__(self):return self._w
	def __repr__(self):return'<%s.%s object %s>'%(self.__class__.__module__,self.__class__.__qualname__,self._w)
	_noarg_=['_noarg_']
	def pack_propagate(self,flag=_noarg_):
		if flag is Misc._noarg_:return self._getboolean(self.tk.call(_f,_A1,self._w))
		else:self.tk.call(_f,_A1,self._w,flag)
	propagate=pack_propagate
	def pack_slaves(self):return[self._nametowidget(x)for x in self.tk.splitlist(self.tk.call(_f,_AH,self._w))]
	slaves=pack_slaves
	def place_slaves(self):return[self._nametowidget(x)for x in self.tk.splitlist(self.tk.call(_g,_AH,self._w))]
	def grid_anchor(self,anchor=_A):self.tk.call(_G,_AI,self._w,anchor)
	anchor=grid_anchor
	def grid_bbox(self,column=_A,row=_A,col2=_A,row2=_A):
		args=_G,_p,self._w
		if column is not _A and row is not _A:args=args+(column,row)
		if col2 is not _A and row2 is not _A:args=args+(col2,row2)
		return self._getints(self.tk.call(*args))or _A
	bbox=grid_bbox
	def _gridconvvalue(self,value):
		if isinstance(value,(str,_tkinter.Tcl_Obj)):
			try:
				svalue=str(value)
				if not svalue:return _A
				elif _d in svalue:return self.tk.getdouble(svalue)
				else:return self.tk.getint(svalue)
			except (ValueError,TclError):pass
		return value
	def _grid_configure(self,command,index,cnf,kw):
		if isinstance(cnf,str)and not kw:
			if cnf[-1:]==_W:cnf=cnf[:-1]
			if cnf[:1]!=_D:cnf=_D+cnf
			options=cnf,
		else:options=self._options(cnf,kw)
		if not options:return _splitdict(self.tk,self.tk.call(_G,command,self._w,index),conv=self._gridconvvalue)
		res=self.tk.call((_G,command,self._w,index)+options)
		if len(options)==1:return self._gridconvvalue(res)
	def grid_columnconfigure(self,index,cnf={},**kw):return self._grid_configure('columnconfigure',index,cnf,kw)
	columnconfigure=grid_columnconfigure
	def grid_location(self,x,y):return self._getints(self.tk.call(_G,'location',self._w,x,y))or _A
	def grid_propagate(self,flag=_noarg_):
		if flag is Misc._noarg_:return self._getboolean(self.tk.call(_G,_A1,self._w))
		else:self.tk.call(_G,_A1,self._w,flag)
	def grid_rowconfigure(self,index,cnf={},**kw):return self._grid_configure('rowconfigure',index,cnf,kw)
	rowconfigure=grid_rowconfigure
	def grid_size(self):return self._getints(self.tk.call(_G,'size',self._w))or _A
	size=grid_size
	def grid_slaves(self,row=_A,column=_A):
		args=()
		if row is not _A:args=args+('-row',row)
		if column is not _A:args=args+('-column',column)
		return[self._nametowidget(x)for x in self.tk.splitlist(self.tk.call((_G,_AH,self._w)+args))]
	def event_add(self,virtual,*sequences):args=(_A2,_a,virtual)+sequences;self.tk.call(args)
	def event_delete(self,virtual,*sequences):args=(_A2,_O,virtual)+sequences;self.tk.call(args)
	def event_generate(self,sequence,**kw):
		args=_A2,'generate',self._w,sequence
		for (k,v) in kw.items():args=args+('-%s'%k,str(v))
		self.tk.call(args)
	def event_info(self,virtual=_A):return self.tk.splitlist(self.tk.call(_A2,_R,virtual))
	def image_names(self):return self.tk.splitlist(self.tk.call(_H,_X))
	def image_types(self):return self.tk.splitlist(self.tk.call(_H,_Ab))
class CallWrapper:
	def __init__(self,func,subst,widget):self.func=func;self.subst=subst;self.widget=widget
	def __call__(self,*args):
		try:
			if self.subst:args=self.subst(*args)
			return self.func(*args)
		except SystemExit:raise
		except:self.widget._report_exception()
class XView:
	def xview(self,*args):
		res=self.tk.call(self._w,_AJ,*args)
		if not args:return self._getdoubles(res)
	def xview_moveto(self,fraction):self.tk.call(self._w,_AJ,_AK,fraction)
	def xview_scroll(self,number,what):self.tk.call(self._w,_AJ,_Ac,number,what)
class YView:
	def yview(self,*args):
		res=self.tk.call(self._w,_A3,*args)
		if not args:return self._getdoubles(res)
	def yview_moveto(self,fraction):self.tk.call(self._w,_A3,_AK,fraction)
	def yview_scroll(self,number,what):self.tk.call(self._w,_A3,_Ac,number,what)
class Wm:
	def wm_aspect(self,minNumer=_A,minDenom=_A,maxNumer=_A,maxDenom=_A):return self._getints(self.tk.call(_C,'aspect',self._w,minNumer,minDenom,maxNumer,maxDenom))
	aspect=wm_aspect
	def wm_attributes(self,*args):args=(_C,'attributes',self._w)+args;return self.tk.call(args)
	attributes=wm_attributes
	def wm_client(self,name=_A):return self.tk.call(_C,'client',self._w,name)
	client=wm_client
	def wm_colormapwindows(self,*wlist):
		if len(wlist)>1:wlist=wlist,
		args=(_C,'colormapwindows',self._w)+wlist
		if wlist:self.tk.call(args)
		else:return[self._nametowidget(x)for x in self.tk.splitlist(self.tk.call(args))]
	colormapwindows=wm_colormapwindows
	def wm_command(self,value=_A):return self.tk.call(_C,_T,self._w,value)
	command=wm_command
	def wm_deiconify(self):return self.tk.call(_C,'deiconify',self._w)
	deiconify=wm_deiconify
	def wm_focusmodel(self,model=_A):return self.tk.call(_C,'focusmodel',self._w,model)
	focusmodel=wm_focusmodel
	def wm_forget(self,window):self.tk.call(_C,_h,window)
	forget=wm_forget
	def wm_frame(self):return self.tk.call(_C,_Ad,self._w)
	frame=wm_frame
	def wm_geometry(self,newGeometry=_A):return self.tk.call(_C,_AW,self._w,newGeometry)
	geometry=wm_geometry
	def wm_grid(self,baseWidth=_A,baseHeight=_A,widthInc=_A,heightInc=_A):return self._getints(self.tk.call(_C,_G,self._w,baseWidth,baseHeight,widthInc,heightInc))
	grid=wm_grid
	def wm_group(self,pathName=_A):return self.tk.call(_C,'group',self._w,pathName)
	group=wm_group
	def wm_iconbitmap(self,bitmap=_A,default=_A):
		A='iconbitmap'
		if default:return self.tk.call(_C,A,self._w,_Ae,default)
		else:return self.tk.call(_C,A,self._w,bitmap)
	iconbitmap=wm_iconbitmap
	def wm_iconify(self):return self.tk.call(_C,'iconify',self._w)
	iconify=wm_iconify
	def wm_iconmask(self,bitmap=_A):return self.tk.call(_C,'iconmask',self._w,bitmap)
	iconmask=wm_iconmask
	def wm_iconname(self,newName=_A):return self.tk.call(_C,'iconname',self._w,newName)
	iconname=wm_iconname
	def wm_iconphoto(self,default=_l,*args):
		A='iconphoto'
		if default:self.tk.call(_C,A,self._w,_Ae,*args)
		else:self.tk.call(_C,A,self._w,*args)
	iconphoto=wm_iconphoto
	def wm_iconposition(self,x=_A,y=_A):return self._getints(self.tk.call(_C,'iconposition',self._w,x,y))
	iconposition=wm_iconposition
	def wm_iconwindow(self,pathName=_A):return self.tk.call(_C,'iconwindow',self._w,pathName)
	iconwindow=wm_iconwindow
	def wm_manage(self,widget):self.tk.call(_C,'manage',widget)
	manage=wm_manage
	def wm_maxsize(self,width=_A,height=_A):return self._getints(self.tk.call(_C,'maxsize',self._w,width,height))
	maxsize=wm_maxsize
	def wm_minsize(self,width=_A,height=_A):return self._getints(self.tk.call(_C,'minsize',self._w,width,height))
	minsize=wm_minsize
	def wm_overrideredirect(self,boolean=_A):return self._getboolean(self.tk.call(_C,'overrideredirect',self._w,boolean))
	overrideredirect=wm_overrideredirect
	def wm_positionfrom(self,who=_A):return self.tk.call(_C,'positionfrom',self._w,who)
	positionfrom=wm_positionfrom
	def wm_protocol(self,name=_A,func=_A):
		if callable(func):command=self._register(func)
		else:command=func
		return self.tk.call(_C,'protocol',self._w,name,command)
	protocol=wm_protocol
	def wm_resizable(self,width=_A,height=_A):return self.tk.call(_C,'resizable',self._w,width,height)
	resizable=wm_resizable
	def wm_sizefrom(self,who=_A):return self.tk.call(_C,'sizefrom',self._w,who)
	sizefrom=wm_sizefrom
	def wm_state(self,newstate=_A):return self.tk.call(_C,_u,self._w,newstate)
	state=wm_state
	def wm_title(self,string=_A):return self.tk.call(_C,'title',self._w,string)
	title=wm_title
	def wm_transient(self,master=_A):return self.tk.call(_C,'transient',self._w,master)
	transient=wm_transient
	def wm_withdraw(self):return self.tk.call(_C,'withdraw',self._w)
	withdraw=wm_withdraw
class Tk(Misc,Wm):
	_w=_d
	def __init__(self,screenName=_A,baseName=_A,className='Tk',useTk=1,sync=0,use=_A):
		self.master=_A;self.children={};self._tkloaded=_l;self.tk=_A
		if baseName is _A:
			import os;baseName=os.path.basename(sys.argv[0]);baseName,ext=os.path.splitext(baseName)
			if ext not in('.py','.pyc'):baseName=baseName+ext
		interactive=0;self.tk=_tkinter.create(screenName,baseName,className,interactive,wantobjects,useTk,sync,use)
		if useTk:self._loadtk()
		if not sys.flags.ignore_environment:self.readprofile(baseName,className)
	def loadtk(self):
		if not self._tkloaded:self.tk.loadtk();self._loadtk()
	def _loadtk(self):
		B='exit';A='tkerror';self._tkloaded=_t;global _default_root;tk_version=self.tk.getvar('tk_version')
		if tk_version!=_tkinter.TK_VERSION:raise RuntimeError("tk.h version (%s) doesn't match libtk.a version (%s)"%(_tkinter.TK_VERSION,tk_version))
		tcl_version=str(self.tk.getvar('tcl_version'))
		if tcl_version!=_tkinter.TCL_VERSION:raise RuntimeError("tcl.h version (%s) doesn't match libtcl.a version (%s)"%(_tkinter.TCL_VERSION,tcl_version))
		if self._tclCommands is _A:self._tclCommands=[]
		self.tk.createcommand(A,_tkerror);self.tk.createcommand(B,_exit);self._tclCommands.append(A);self._tclCommands.append(B)
		if _support_default_root and not _default_root:_default_root=self
		self.protocol(_Af,self.destroy)
	def destroy(self):
		for c in list(self.children.values()):c.destroy()
		self.tk.call(_Ag,self._w);Misc.destroy(self);global _default_root
		if _support_default_root and _default_root is self:_default_root=_A
	def readprofile(self,baseName,className):
		D='source';C='.%s.py';B='.%s.tcl';A='HOME';import os
		if A in os.environ:home=os.environ[A]
		else:home=os.curdir
		class_tcl=os.path.join(home,B%className);class_py=os.path.join(home,C%className);base_tcl=os.path.join(home,B%baseName);base_py=os.path.join(home,C%baseName);dir={'self':self};exec('from tkinter import *',dir)
		if os.path.isfile(class_tcl):self.tk.call(D,class_tcl)
		if os.path.isfile(class_py):exec(open(class_py).read(),dir)
		if os.path.isfile(base_tcl):self.tk.call(D,base_tcl)
		if os.path.isfile(base_py):exec(open(base_py).read(),dir)
	def report_callback_exception(self,exc,val,tb):import traceback;print('Exception in Tkinter callback',file=sys.stderr);sys.last_type=exc;sys.last_value=val;sys.last_traceback=tb;traceback.print_exception(exc,val,tb)
	def __getattr__(self,attr):return getattr(self.tk,attr)
def Tcl(screenName=_A,baseName=_A,className='Tk',useTk=0):return Tk(screenName,baseName,className,useTk)
class Pack:
	def pack_configure(self,cnf={},**kw):self.tk.call((_f,_M,self._w)+self._options(cnf,kw))
	pack=configure=config=pack_configure
	def pack_forget(self):self.tk.call(_f,_h,self._w)
	forget=pack_forget
	def pack_info(self):
		d=_splitdict(self.tk,self.tk.call(_f,_R,self._w))
		if _P in d:d[_P]=self.nametowidget(d[_P])
		return d
	info=pack_info;propagate=pack_propagate=Misc.pack_propagate;slaves=pack_slaves=Misc.pack_slaves
class Place:
	def place_configure(self,cnf={},**kw):self.tk.call((_g,_M,self._w)+self._options(cnf,kw))
	place=configure=config=place_configure
	def place_forget(self):self.tk.call(_g,_h,self._w)
	forget=place_forget
	def place_info(self):
		d=_splitdict(self.tk,self.tk.call(_g,_R,self._w))
		if _P in d:d[_P]=self.nametowidget(d[_P])
		return d
	info=place_info;slaves=place_slaves=Misc.place_slaves
class Grid:
	def grid_configure(self,cnf={},**kw):self.tk.call((_G,_M,self._w)+self._options(cnf,kw))
	grid=configure=config=grid_configure;bbox=grid_bbox=Misc.grid_bbox;columnconfigure=grid_columnconfigure=Misc.grid_columnconfigure
	def grid_forget(self):self.tk.call(_G,_h,self._w)
	forget=grid_forget
	def grid_remove(self):self.tk.call(_G,_AB,self._w)
	def grid_info(self):
		d=_splitdict(self.tk,self.tk.call(_G,_R,self._w))
		if _P in d:d[_P]=self.nametowidget(d[_P])
		return d
	info=grid_info;location=grid_location=Misc.grid_location;propagate=grid_propagate=Misc.grid_propagate;rowconfigure=grid_rowconfigure=Misc.grid_rowconfigure;size=grid_size=Misc.grid_size;slaves=grid_slaves=Misc.grid_slaves
class BaseWidget(Misc):
	def _setup(self,master,cnf):
		if not master:master=_get_default_root()
		self.master=master;self.tk=master.tk;name=_A
		if _k in cnf:name=cnf[_k];del cnf[_k]
		if not name:
			name=self.__class__.__name__.lower()
			if master._last_child_ids is _A:master._last_child_ids={}
			count=master._last_child_ids.get(name,0)+1;master._last_child_ids[name]=count
			if count==1:name='!%s'%(name,)
			else:name='!%s%d'%(name,count)
		self._name=name
		if master._w==_d:self._w=_d+name
		else:self._w=master._w+_d+name
		self.children={}
		if self._name in self.master.children:self.master.children[self._name].destroy()
		self.master.children[self._name]=self
	def __init__(self,master,widgetName,cnf={},kw={},extra=()):
		if kw:cnf=_cnfmerge((cnf,kw))
		self.widgetName=widgetName;BaseWidget._setup(self,master,cnf)
		if self._tclCommands is _A:self._tclCommands=[]
		classes=[(k,v)for(k,v)in cnf.items()if isinstance(k,type)]
		for (k,v) in classes:del cnf[k]
		self.tk.call((widgetName,self._w)+extra+self._options(cnf))
		for (k,v) in classes:k.configure(self,v)
	def destroy(self):
		for c in list(self.children.values()):c.destroy()
		self.tk.call(_Ag,self._w)
		if self._name in self.master.children:del self.master.children[self._name]
		Misc.destroy(self)
	def _do(self,name,args=()):return self.tk.call((self._w,name)+args)
class Widget(BaseWidget,Pack,Place,Grid):0
class Toplevel(BaseWidget,Wm):
	def __init__(self,master=_A,cnf={},**kw):
		if kw:cnf=_cnfmerge((cnf,kw))
		extra=()
		for wmkey in [_AX,_A4,_o,_AZ,'colormap']:
			if wmkey in cnf:
				val=cnf[wmkey]
				if wmkey[-1]==_W:opt=_D+wmkey[:-1]
				else:opt=_D+wmkey
				extra=extra+(opt,val);del cnf[wmkey]
		BaseWidget.__init__(self,master,_AY,cnf,{},extra);root=self._root();self.iconname(root.iconname());self.title(root.title());self.protocol(_Af,self.destroy)
class Button(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'button',cnf,kw)
	def flash(self):self.tk.call(self._w,_AL)
	def invoke(self):return self.tk.call(self._w,_q)
class Canvas(Widget,XView,YView):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'canvas',cnf,kw)
	def addtag(self,*args):self.tk.call((self._w,'addtag')+args)
	def addtag_above(self,newtag,tagOrId):self.addtag(newtag,_Ah,tagOrId)
	def addtag_all(self,newtag):self.addtag(newtag,_A0)
	def addtag_below(self,newtag,tagOrId):self.addtag(newtag,_Ai,tagOrId)
	def addtag_closest(self,newtag,x,y,halo=_A,start=_A):self.addtag(newtag,_Aj,x,y,halo,start)
	def addtag_enclosed(self,newtag,x1,y1,x2,y2):self.addtag(newtag,_Ak,x1,y1,x2,y2)
	def addtag_overlapping(self,newtag,x1,y1,x2,y2):self.addtag(newtag,_Al,x1,y1,x2,y2)
	def addtag_withtag(self,newtag,tagOrId):self.addtag(newtag,_Am,tagOrId)
	def bbox(self,*args):return self._getints(self.tk.call((self._w,_p)+args))or _A
	def tag_unbind(self,tagOrId,sequence,funcid=_A):
		self.tk.call(self._w,_L,tagOrId,sequence,'')
		if funcid:self.deletecommand(funcid)
	def tag_bind(self,tagOrId,sequence=_A,func=_A,add=_A):return self._bind((self._w,_L,tagOrId),sequence,func,add)
	def canvasx(self,screenx,gridspacing=_A):return self.tk.getdouble(self.tk.call(self._w,'canvasx',screenx,gridspacing))
	def canvasy(self,screeny,gridspacing=_A):return self.tk.getdouble(self.tk.call(self._w,'canvasy',screeny,gridspacing))
	def coords(self,*args):return[self.tk.getdouble(x)for x in self.tk.splitlist(self.tk.call((self._w,_An)+args))]
	def _create(self,itemType,args,kw):
		args=_flatten(args);cnf=args[-1]
		if isinstance(cnf,(dict,tuple)):args=args[:-1]
		else:cnf={}
		return self.tk.getint(self.tk.call(self._w,_r,itemType,*args+self._options(cnf,kw)))
	def create_arc(self,*args,**kw):return self._create('arc',args,kw)
	def create_bitmap(self,*args,**kw):return self._create(_Ao,args,kw)
	def create_image(self,*args,**kw):return self._create(_H,args,kw)
	def create_line(self,*args,**kw):return self._create('line',args,kw)
	def create_oval(self,*args,**kw):return self._create('oval',args,kw)
	def create_polygon(self,*args,**kw):return self._create('polygon',args,kw)
	def create_rectangle(self,*args,**kw):return self._create('rectangle',args,kw)
	def create_text(self,*args,**kw):return self._create(_AM,args,kw)
	def create_window(self,*args,**kw):return self._create(_b,args,kw)
	def dchars(self,*args):self.tk.call((self._w,'dchars')+args)
	def delete(self,*args):self.tk.call((self._w,_O)+args)
	def dtag(self,*args):self.tk.call((self._w,'dtag')+args)
	def find(self,*args):return self._getints(self.tk.call((self._w,'find')+args))or()
	def find_above(self,tagOrId):return self.find(_Ah,tagOrId)
	def find_all(self):return self.find(_A0)
	def find_below(self,tagOrId):return self.find(_Ai,tagOrId)
	def find_closest(self,x,y,halo=_A,start=_A):return self.find(_Aj,x,y,halo,start)
	def find_enclosed(self,x1,y1,x2,y2):return self.find(_Ak,x1,y1,x2,y2)
	def find_overlapping(self,x1,y1,x2,y2):return self.find(_Al,x1,y1,x2,y2)
	def find_withtag(self,tagOrId):return self.find(_Am,tagOrId)
	def focus(self,*args):return self.tk.call((self._w,_U)+args)
	def gettags(self,*args):return self.tk.splitlist(self.tk.call((self._w,'gettags')+args))
	def icursor(self,*args):self.tk.call((self._w,_AN)+args)
	def index(self,*args):return self.tk.getint(self.tk.call((self._w,_i)+args))
	def insert(self,*args):self.tk.call((self._w,_j)+args)
	def itemcget(self,tagOrId,option):return self.tk.call((self._w,_Ap)+(tagOrId,_D+option))
	def itemconfigure(self,tagOrId,cnf=_A,**kw):return self._configure((_Aq,tagOrId),cnf,kw)
	itemconfig=itemconfigure
	def tag_lower(self,*args):self.tk.call((self._w,_AF)+args)
	lower=tag_lower
	def move(self,*args):self.tk.call((self._w,'move')+args)
	def moveto(self,tagOrId,x='',y=''):self.tk.call(self._w,_AK,tagOrId,x,y)
	def postscript(self,cnf={},**kw):return self.tk.call((self._w,'postscript')+self._options(cnf,kw))
	def tag_raise(self,*args):self.tk.call((self._w,_AG)+args)
	lift=tkraise=tag_raise
	def scale(self,*args):self.tk.call((self._w,_Ar)+args)
	def scan_mark(self,x,y):self.tk.call(self._w,_Q,_J,x,y)
	def scan_dragto(self,x,y,gain=10):self.tk.call(self._w,_Q,_s,x,y,gain)
	def select_adjust(self,tagOrId,index):self.tk.call(self._w,_Y,_AO,tagOrId,index)
	def select_clear(self):self.tk.call(self._w,_Y,_V)
	def select_from(self,tagOrId,index):self.tk.call(self._w,_Y,_AP,tagOrId,index)
	def select_item(self):return self.tk.call(self._w,_Y,'item')or _A
	def select_to(self,tagOrId,index):self.tk.call(self._w,_Y,'to',tagOrId,index)
	def type(self,tagOrId):return self.tk.call(self._w,_N,tagOrId)or _A
class Checkbutton(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,_AQ,cnf,kw)
	def deselect(self):self.tk.call(self._w,_As)
	def flash(self):self.tk.call(self._w,_AL)
	def invoke(self):return self.tk.call(self._w,_q)
	def select(self):self.tk.call(self._w,_Y)
	def toggle(self):self.tk.call(self._w,'toggle')
class Entry(Widget,XView):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'entry',cnf,kw)
	def delete(self,first,last=_A):self.tk.call(self._w,_O,first,last)
	def get(self):return self.tk.call(self._w,_F)
	def icursor(self,index):self.tk.call(self._w,_AN,index)
	def index(self,index):return self.tk.getint(self.tk.call(self._w,_i,index))
	def insert(self,index,string):self.tk.call(self._w,_j,index,string)
	def scan_mark(self,x):self.tk.call(self._w,_Q,_J,x)
	def scan_dragto(self,x):self.tk.call(self._w,_Q,_s,x)
	def selection_adjust(self,index):self.tk.call(self._w,_E,_AO,index)
	select_adjust=selection_adjust
	def selection_clear(self):self.tk.call(self._w,_E,_V)
	select_clear=selection_clear
	def selection_from(self,index):self.tk.call(self._w,_E,_AP,index)
	select_from=selection_from
	def selection_present(self):return self.tk.getboolean(self.tk.call(self._w,_E,_At))
	select_present=selection_present
	def selection_range(self,start,end):self.tk.call(self._w,_E,_Au,start,end)
	select_range=selection_range
	def selection_to(self,index):self.tk.call(self._w,_E,'to',index)
	select_to=selection_to
class Frame(Widget):
	def __init__(self,master=_A,cnf={},**kw):
		A='-class';cnf=_cnfmerge((cnf,kw));extra=()
		if _A4 in cnf:extra=A,cnf[_A4];del cnf[_A4]
		elif _o in cnf:extra=A,cnf[_o];del cnf[_o]
		Widget.__init__(self,master,_Ad,cnf,{},extra)
class Label(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'label',cnf,kw)
class Listbox(Widget,XView,YView):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'listbox',cnf,kw)
	def activate(self,index):self.tk.call(self._w,_AR,index)
	def bbox(self,index):return self._getints(self.tk.call(self._w,_p,index))or _A
	def curselection(self):return self._getints(self.tk.call(self._w,'curselection'))or()
	def delete(self,first,last=_A):self.tk.call(self._w,_O,first,last)
	def get(self,first,last=_A):
		if last is not _A:return self.tk.splitlist(self.tk.call(self._w,_F,first,last))
		else:return self.tk.call(self._w,_F,first)
	def index(self,index):
		i=self.tk.call(self._w,_i,index)
		if i==_c:return _A
		return self.tk.getint(i)
	def insert(self,index,*elements):self.tk.call((self._w,_j,index)+elements)
	def nearest(self,y):return self.tk.getint(self.tk.call(self._w,'nearest',y))
	def scan_mark(self,x,y):self.tk.call(self._w,_Q,_J,x,y)
	def scan_dragto(self,x,y):self.tk.call(self._w,_Q,_s,x,y)
	def see(self,index):self.tk.call(self._w,'see',index)
	def selection_anchor(self,index):self.tk.call(self._w,_E,_AI,index)
	select_anchor=selection_anchor
	def selection_clear(self,first,last=_A):self.tk.call(self._w,_E,_V,first,last)
	select_clear=selection_clear
	def selection_includes(self,index):return self.tk.getboolean(self.tk.call(self._w,_E,'includes',index))
	select_includes=selection_includes
	def selection_set(self,first,last=_A):self.tk.call(self._w,_E,_S,first,last)
	select_set=selection_set
	def size(self):return self.tk.getint(self.tk.call(self._w,'size'))
	def itemcget(self,index,option):return self.tk.call((self._w,_Ap)+(index,_D+option))
	def itemconfigure(self,index,cnf=_A,**kw):return self._configure((_Aq,index),cnf,kw)
	itemconfig=itemconfigure
class Menu(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,_A5,cnf,kw)
	def tk_popup(self,x,y,entry=''):self.tk.call('tk_popup',self._w,x,y,entry)
	def activate(self,index):self.tk.call(self._w,_AR,index)
	def add(self,itemType,cnf={},**kw):self.tk.call((self._w,_a,itemType)+self._options(cnf,kw))
	def add_cascade(self,cnf={},**kw):self.add(_Av,cnf or kw)
	def add_checkbutton(self,cnf={},**kw):self.add(_AQ,cnf or kw)
	def add_command(self,cnf={},**kw):self.add(_T,cnf or kw)
	def add_radiobutton(self,cnf={},**kw):self.add(_AS,cnf or kw)
	def add_separator(self,cnf={},**kw):self.add(_AT,cnf or kw)
	def insert(self,index,itemType,cnf={},**kw):self.tk.call((self._w,_j,index,itemType)+self._options(cnf,kw))
	def insert_cascade(self,index,cnf={},**kw):self.insert(index,_Av,cnf or kw)
	def insert_checkbutton(self,index,cnf={},**kw):self.insert(index,_AQ,cnf or kw)
	def insert_command(self,index,cnf={},**kw):self.insert(index,_T,cnf or kw)
	def insert_radiobutton(self,index,cnf={},**kw):self.insert(index,_AS,cnf or kw)
	def insert_separator(self,index,cnf={},**kw):self.insert(index,_AT,cnf or kw)
	def delete(self,index1,index2=_A):
		if index2 is _A:index2=index1
		num_index1,num_index2=self.index(index1),self.index(index2)
		if num_index1 is _A or num_index2 is _A:num_index1,num_index2=0,-1
		for i in range(num_index1,num_index2+1):
			if _T in self.entryconfig(i):
				c=str(self.entrycget(i,_T))
				if c:self.deletecommand(c)
		self.tk.call(self._w,_O,index1,index2)
	def entrycget(self,index,option):return self.tk.call(self._w,'entrycget',index,_D+option)
	def entryconfigure(self,index,cnf=_A,**kw):return self._configure(('entryconfigure',index),cnf,kw)
	entryconfig=entryconfigure
	def index(self,index):
		i=self.tk.call(self._w,_i,index)
		if i==_c:return _A
		return self.tk.getint(i)
	def invoke(self,index):return self.tk.call(self._w,_q,index)
	def post(self,x,y):self.tk.call(self._w,'post',x,y)
	def type(self,index):return self.tk.call(self._w,_N,index)
	def unpost(self):self.tk.call(self._w,'unpost')
	def xposition(self,index):return self.tk.getint(self.tk.call(self._w,'xposition',index))
	def yposition(self,index):return self.tk.getint(self.tk.call(self._w,'yposition',index))
class Menubutton(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,_Aw,cnf,kw)
class Message(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'message',cnf,kw)
class Radiobutton(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,_AS,cnf,kw)
	def deselect(self):self.tk.call(self._w,_As)
	def flash(self):self.tk.call(self._w,_AL)
	def invoke(self):return self.tk.call(self._w,_q)
	def select(self):self.tk.call(self._w,_Y)
class Scale(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,_Ar,cnf,kw)
	def get(self):
		value=self.tk.call(self._w,_F)
		try:return self.tk.getint(value)
		except (ValueError,TypeError,TclError):return self.tk.getdouble(value)
	def set(self,value):self.tk.call(self._w,_S,value)
	def coords(self,value=_A):return self._getints(self.tk.call(self._w,_An,value))
	def identify(self,x,y):return self.tk.call(self._w,_A6,x,y)
class Scrollbar(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'scrollbar',cnf,kw)
	def activate(self,index=_A):return self.tk.call(self._w,_AR,index)or _A
	def delta(self,deltax,deltay):return self.tk.getdouble(self.tk.call(self._w,_A7,deltax,deltay))
	def fraction(self,x,y):return self.tk.getdouble(self.tk.call(self._w,'fraction',x,y))
	def identify(self,x,y):return self.tk.call(self._w,_A6,x,y)
	def get(self):return self._getdoubles(self.tk.call(self._w,_F))
	def set(self,first,last):self.tk.call(self._w,_S,first,last)
class Text(Widget,XView,YView):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,_AM,cnf,kw)
	def bbox(self,index):return self._getints(self.tk.call(self._w,_p,index))or _A
	def compare(self,index1,op,index2):return self.tk.getboolean(self.tk.call(self._w,'compare',index1,op,index2))
	def count(self,index1,index2,*args):
		args=['-%s'%arg for arg in args if not arg.startswith(_D)];args+=[index1,index2];res=self.tk.call(self._w,'count',*args)or _A
		if res is not _A and len(args)<=3:return res,
		else:return res
	def debug(self,boolean=_A):
		A='debug'
		if boolean is _A:return self.tk.getboolean(self.tk.call(self._w,A))
		self.tk.call(self._w,A,boolean)
	def delete(self,index1,index2=_A):self.tk.call(self._w,_O,index1,index2)
	def dlineinfo(self,index):return self._getints(self.tk.call(self._w,'dlineinfo',index))
	def dump(self,index1,index2=_A,command=_A,**kw):
		args=[];func_name=_A;result=_A
		if not command:
			result=[]
			def append_triple(key,value,index,result=result):result.append((key,value,index))
			command=append_triple
		try:
			if not isinstance(command,str):func_name=command=self._register(command)
			args+=['-command',command]
			for key in kw:
				if kw[key]:args.append(_D+key)
			args.append(index1)
			if index2:args.append(index2)
			self.tk.call(self._w,'dump',*args);return result
		finally:
			if func_name:self.deletecommand(func_name)
	def edit(self,*args):return self.tk.call(self._w,'edit',*args)
	def edit_modified(self,arg=_A):return self.edit('modified',arg)
	def edit_redo(self):return self.edit('redo')
	def edit_reset(self):return self.edit('reset')
	def edit_separator(self):return self.edit(_AT)
	def edit_undo(self):return self.edit('undo')
	def get(self,index1,index2=_A):return self.tk.call(self._w,_F,index1,index2)
	def image_cget(self,index,option):
		if option[:1]!=_D:option=_D+option
		if option[-1:]==_W:option=option[:-1]
		return self.tk.call(self._w,_H,_e,index,option)
	def image_configure(self,index,cnf=_A,**kw):return self._configure((_H,_M,index),cnf,kw)
	def image_create(self,index,cnf={},**kw):return self.tk.call(self._w,_H,_r,index,*self._options(cnf,kw))
	def image_names(self):return self.tk.call(self._w,_H,_X)
	def index(self,index):return str(self.tk.call(self._w,_i,index))
	def insert(self,index,chars,*args):self.tk.call((self._w,_j,index,chars)+args)
	def mark_gravity(self,markName,direction=_A):return self.tk.call((self._w,_J,'gravity',markName,direction))
	def mark_names(self):return self.tk.splitlist(self.tk.call(self._w,_J,_X))
	def mark_set(self,markName,index):self.tk.call(self._w,_J,_S,markName,index)
	def mark_unset(self,*markNames):self.tk.call((self._w,_J,'unset')+markNames)
	def mark_next(self,index):return self.tk.call(self._w,_J,'next',index)or _A
	def mark_previous(self,index):return self.tk.call(self._w,_J,'previous',index)or _A
	def peer_create(self,newPathName,cnf={},**kw):self.tk.call(self._w,'peer',_r,newPathName,*self._options(cnf,kw))
	def peer_names(self):return self.tk.splitlist(self.tk.call(self._w,'peer',_X))
	def replace(self,index1,index2,chars,*args):self.tk.call(self._w,'replace',index1,index2,chars,*args)
	def scan_mark(self,x,y):self.tk.call(self._w,_Q,_J,x,y)
	def scan_dragto(self,x,y):self.tk.call(self._w,_Q,_s,x,y)
	def search(self,pattern,index,stopindex=_A,forwards=_A,backwards=_A,exact=_A,regexp=_A,nocase=_A,count=_A,elide=_A):
		args=[self._w,'search']
		if forwards:args.append('-forwards')
		if backwards:args.append('-backwards')
		if exact:args.append('-exact')
		if regexp:args.append('-regexp')
		if nocase:args.append('-nocase')
		if elide:args.append('-elide')
		if count:args.append('-count');args.append(count)
		if pattern and pattern[0]==_D:args.append('--')
		args.append(pattern);args.append(index)
		if stopindex:args.append(stopindex)
		return str(self.tk.call(tuple(args)))
	def see(self,index):self.tk.call(self._w,'see',index)
	def tag_add(self,tagName,index1,*args):self.tk.call((self._w,_I,_a,tagName,index1)+args)
	def tag_unbind(self,tagName,sequence,funcid=_A):
		self.tk.call(self._w,_I,_L,tagName,sequence,'')
		if funcid:self.deletecommand(funcid)
	def tag_bind(self,tagName,sequence,func,add=_A):return self._bind((self._w,_I,_L,tagName),sequence,func,add)
	def tag_cget(self,tagName,option):
		if option[:1]!=_D:option=_D+option
		if option[-1:]==_W:option=option[:-1]
		return self.tk.call(self._w,_I,_e,tagName,option)
	def tag_configure(self,tagName,cnf=_A,**kw):return self._configure((_I,_M,tagName),cnf,kw)
	tag_config=tag_configure
	def tag_delete(self,*tagNames):self.tk.call((self._w,_I,_O)+tagNames)
	def tag_lower(self,tagName,belowThis=_A):self.tk.call(self._w,_I,_AF,tagName,belowThis)
	def tag_names(self,index=_A):return self.tk.splitlist(self.tk.call(self._w,_I,_X,index))
	def tag_nextrange(self,tagName,index1,index2=_A):return self.tk.splitlist(self.tk.call(self._w,_I,'nextrange',tagName,index1,index2))
	def tag_prevrange(self,tagName,index1,index2=_A):return self.tk.splitlist(self.tk.call(self._w,_I,'prevrange',tagName,index1,index2))
	def tag_raise(self,tagName,aboveThis=_A):self.tk.call(self._w,_I,_AG,tagName,aboveThis)
	def tag_ranges(self,tagName):return self.tk.splitlist(self.tk.call(self._w,_I,'ranges',tagName))
	def tag_remove(self,tagName,index1,index2=_A):self.tk.call(self._w,_I,_AB,tagName,index1,index2)
	def window_cget(self,index,option):
		if option[:1]!=_D:option=_D+option
		if option[-1:]==_W:option=option[:-1]
		return self.tk.call(self._w,_b,_e,index,option)
	def window_configure(self,index,cnf=_A,**kw):return self._configure((_b,_M,index),cnf,kw)
	window_config=window_configure
	def window_create(self,index,cnf={},**kw):self.tk.call((self._w,_b,_r,index)+self._options(cnf,kw))
	def window_names(self):return self.tk.splitlist(self.tk.call(self._w,_b,_X))
	def yview_pickplace(self,*what):self.tk.call((self._w,_A3,'-pickplace')+what)
class _setit:
	def __init__(self,var,value,callback=_A):self.__value=value;self.__var=var;self.__callback=callback
	def __call__(self,*args):
		self.__var.set(self.__value)
		if self.__callback:self.__callback(self.__value,*args)
class OptionMenu(Menubutton):
	def __init__(self,master,variable,value,*values,**kwargs):
		kw={'borderwidth':2,'textvariable':variable,'indicatoron':1,'relief':RAISED,_AI:'c','highlightthickness':2};Widget.__init__(self,master,_Aw,kw);self.widgetName='tk_optionMenu';menu=self.__menu=Menu(self,name=_A5,tearoff=0);self.menuname=menu._w;callback=kwargs.get(_T)
		if _T in kwargs:del kwargs[_T]
		if kwargs:raise TclError('unknown option -'+next(iter(kwargs)))
		menu.add_command(label=value,command=_setit(variable,value,callback))
		for v in values:menu.add_command(label=v,command=_setit(variable,v,callback))
		self[_A5]=menu
	def __getitem__(self,name):
		if name==_A5:return self.__menu
		return Widget.__getitem__(self,name)
	def destroy(self):Menubutton.destroy(self);self.__menu=_A
class Image:
	_last_id=0
	def __init__(self,imgtype,name=_A,cnf={},master=_A,**kw):
		self.name=_A
		if not master:master=_get_default_root('create image')
		self.tk=getattr(master,'tk',master)
		if not name:Image._last_id+=1;name='pyimage%r'%(Image._last_id,)
		if kw and cnf:cnf=_cnfmerge((cnf,kw))
		elif kw:cnf=kw
		options=()
		for (k,v) in cnf.items():
			if callable(v):v=self._register(v)
			options=options+(_D+k,v)
		self.tk.call((_H,_r,imgtype,name)+options);self.name=name
	def __str__(self):return self.name
	def __del__(self):
		if self.name:
			try:self.tk.call(_H,_O,self.name)
			except TclError:pass
	def __setitem__(self,key,value):self.tk.call(self.name,_M,_D+key,value)
	def __getitem__(self,key):return self.tk.call(self.name,_M,_D+key)
	def configure(self,**kw):
		res=()
		for (k,v) in _cnfmerge(kw).items():
			if v is not _A:
				if k[-1]==_W:k=k[:-1]
				if callable(v):v=self._register(v)
				res=res+(_D+k,v)
		self.tk.call((self.name,'config')+res)
	config=configure
	def height(self):return self.tk.getint(self.tk.call(_H,_A9,self.name))
	def type(self):return self.tk.call(_H,_N,self.name)
	def width(self):return self.tk.getint(self.tk.call(_H,_A8,self.name))
class PhotoImage(Image):
	def __init__(self,name=_A,cnf={},master=_A,**kw):Image.__init__(self,'photo',name,cnf,master,**kw)
	def blank(self):self.tk.call(self.name,'blank')
	def cget(self,option):return self.tk.call(self.name,_e,_D+option)
	def __getitem__(self,key):return self.tk.call(self.name,_e,_D+key)
	def copy(self):destImage=PhotoImage(master=self.tk);self.tk.call(destImage,_AU,self.name);return destImage
	def zoom(self,x,y=''):
		destImage=PhotoImage(master=self.tk)
		if y=='':y=x
		self.tk.call(destImage,_AU,self.name,'-zoom',x,y);return destImage
	def subsample(self,x,y=''):
		destImage=PhotoImage(master=self.tk)
		if y=='':y=x
		self.tk.call(destImage,_AU,self.name,'-subsample',x,y);return destImage
	def get(self,x,y):return self.tk.call(self.name,_F,x,y)
	def put(self,data,to=_A):
		A='-to';args=self.name,'put',data
		if to:
			if to[0]==A:to=to[1:]
			args=args+(A,)+tuple(to)
		self.tk.call(args)
	def write(self,filename,format=_A,from_coords=_A):
		args=self.name,'write',filename
		if format:args=args+('-format',format)
		if from_coords:args=args+('-from',)+tuple(from_coords)
		self.tk.call(args)
	def transparency_get(self,x,y):return self.tk.getboolean(self.tk.call(self.name,_Ax,_F,x,y))
	def transparency_set(self,x,y,boolean):self.tk.call(self.name,_Ax,_S,x,y,boolean)
class BitmapImage(Image):
	def __init__(self,name=_A,cnf={},master=_A,**kw):Image.__init__(self,_Ao,name,cnf,master,**kw)
def image_names():tk=_get_default_root('use image_names()').tk;return tk.splitlist(tk.call(_H,_X))
def image_types():tk=_get_default_root('use image_types()').tk;return tk.splitlist(tk.call(_H,_Ab))
class Spinbox(Widget,XView):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'spinbox',cnf,kw)
	def bbox(self,index):return self._getints(self.tk.call(self._w,_p,index))or _A
	def delete(self,first,last=_A):return self.tk.call(self._w,_O,first,last)
	def get(self):return self.tk.call(self._w,_F)
	def icursor(self,index):return self.tk.call(self._w,_AN,index)
	def identify(self,x,y):return self.tk.call(self._w,_A6,x,y)
	def index(self,index):return self.tk.call(self._w,_i,index)
	def insert(self,index,s):return self.tk.call(self._w,_j,index,s)
	def invoke(self,element):return self.tk.call(self._w,_q,element)
	def scan(self,*args):return self._getints(self.tk.call((self._w,_Q)+args))or()
	def scan_mark(self,x):return self.scan(_J,x)
	def scan_dragto(self,x):return self.scan(_s,x)
	def selection(self,*args):return self._getints(self.tk.call((self._w,_E)+args))or()
	def selection_adjust(self,index):return self.selection(_AO,index)
	def selection_clear(self):return self.selection(_V)
	def selection_element(self,element=_A):return self.tk.call(self._w,_E,'element',element)
	def selection_from(self,index):self.selection(_AP,index)
	def selection_present(self):return self.tk.getboolean(self.tk.call(self._w,_E,_At))
	def selection_range(self,start,end):self.selection(_Au,start,end)
	def selection_to(self,index):self.selection('to',index)
class LabelFrame(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'labelframe',cnf,kw)
class PanedWindow(Widget):
	def __init__(self,master=_A,cnf={},**kw):Widget.__init__(self,master,'panedwindow',cnf,kw)
	def add(self,child,**kw):self.tk.call((self._w,_a,child)+self._options(kw))
	def remove(self,child):self.tk.call(self._w,_h,child)
	forget=remove
	def identify(self,x,y):return self.tk.call(self._w,_A6,x,y)
	def proxy(self,*args):return self._getints(self.tk.call((self._w,'proxy')+args))or()
	def proxy_coord(self):return self.proxy(_Ay)
	def proxy_forget(self):return self.proxy(_h)
	def proxy_place(self,x,y):return self.proxy(_g,x,y)
	def sash(self,*args):return self._getints(self.tk.call((self._w,'sash')+args))or()
	def sash_coord(self,index):return self.sash(_Ay,index)
	def sash_mark(self,index):return self.sash(_J,index)
	def sash_place(self,index,x,y):return self.sash(_g,index,x,y)
	def panecget(self,child,option):return self.tk.call((self._w,'panecget')+(child,_D+option))
	def paneconfigure(self,tagOrId,cnf=_A,**kw):
		A='paneconfigure'
		if cnf is _A and not kw:return self._getconfigure(self._w,A,tagOrId)
		if isinstance(cnf,str)and not kw:return self._getconfigure1(self._w,A,tagOrId,_D+cnf)
		self.tk.call((self._w,A,tagOrId)+self._options(cnf,kw))
	paneconfig=paneconfigure
	def panes(self):return self.tk.splitlist(self.tk.call(self._w,'panes'))
def _test():root=Tk();text='This is Tcl/Tk version %s'%TclVersion;text+='\nThis should be a cedilla: ç';label=Label(root,text=text);label.pack();test=Button(root,text='Click me!',command=lambda root=root:root.test.configure(text='[%s]'%root.test[_AM]));test.pack();root.test=test;quit=Button(root,text='QUIT',command=root.destroy);quit.pack();root.iconify();root.update();root.deiconify();root.mainloop()
if __name__=='__main__':_test()