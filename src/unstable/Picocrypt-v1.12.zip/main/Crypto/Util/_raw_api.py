_B='Object type %s cannot be passed to C code'
_A=None
import abc,sys
from Crypto.Util.py3compat import byte_string
from Crypto.Util._file_system import pycryptodome_filename
if sys.version_info[0]<3:
	import imp;extension_suffixes=[]
	for (ext,mod,typ) in imp.get_suffixes():
		if typ==imp.C_EXTENSION:extension_suffixes.append(ext)
else:from importlib import machinery;extension_suffixes=machinery.EXTENSION_SUFFIXES
_buffer_type=bytearray,memoryview
class _VoidPointer:
	@abc.abstractmethod
	def get(self):return
	@abc.abstractmethod
	def address_of(self):return
try:
	if'__pypy__'not in sys.builtin_module_names and sys.flags.optimize==2:raise ImportError('CFFI with optimize=2 fails due to pycparser bug.')
	from cffi import FFI;ffi=FFI();null_pointer=ffi.NULL;uint8_t_type=ffi.typeof(ffi.new('const uint8_t*'));_Array=ffi.new('uint8_t[1]').__class__.__bases__
	def load_lib(name,cdecl):A=ffi.dlopen(name);ffi.cdef(cdecl);return A
	def c_ulong(x):return x
	c_ulonglong=c_ulong;c_uint=c_ulong
	def c_size_t(x):return x
	def create_string_buffer(init_or_size,size=_A):
		D='uint8_t[]';B=size;A=init_or_size
		if isinstance(A,bytes):B=max(len(A)+1,B);C=ffi.new(D,B);C[:]=A
		else:
			if B:raise ValueError('Size must be specified once only')
			C=ffi.new(D,A)
		return C
	def get_c_string(c_string):return ffi.string(c_string)
	def get_raw_buffer(buf):return ffi.buffer(buf)[:]
	def c_uint8_ptr(data):
		A=data
		if isinstance(A,_buffer_type):return ffi.cast(uint8_t_type,ffi.from_buffer(A))
		elif byte_string(A)or isinstance(A,_Array):return A
		else:raise TypeError(_B%type(A))
	class VoidPointer_cffi(_VoidPointer):
		def __init__(A):A._pp=ffi.new('void *[1]')
		def get(A):return A._pp[0]
		def address_of(A):return A._pp
	def VoidPointer():return VoidPointer_cffi()
	backend='cffi'
except ImportError:
	import ctypes;from ctypes import CDLL,c_void_p,byref,c_ulong,c_ulonglong,c_size_t,create_string_buffer,c_ubyte,c_uint;from ctypes.util import find_library;from ctypes import Array as _Array;null_pointer=_A;cached_architecture=[]
	def load_lib(name,cdecl):
		A=name
		if not cached_architecture:import platform as C;cached_architecture[:]=C.architecture()
		E,D=cached_architecture
		if'.'not in A and not D.startswith('Win'):
			B=find_library(A)
			if B is _A:raise OSError("Cannot load library '%s'"%A)
			A=B
		return CDLL(A)
	def get_c_string(c_string):return c_string.value
	def get_raw_buffer(buf):return buf.raw
	_c_ssize_t=ctypes.c_ssize_t;_PyBUF_SIMPLE=0;_PyObject_GetBuffer=ctypes.pythonapi.PyObject_GetBuffer;_PyBuffer_Release=ctypes.pythonapi.PyBuffer_Release;_py_object=ctypes.py_object;_c_ssize_p=ctypes.POINTER(_c_ssize_t)
	class _Py_buffer(ctypes.Structure):
		_fields_=[('buf',c_void_p),('obj',ctypes.py_object),('len',_c_ssize_t),('itemsize',_c_ssize_t),('readonly',ctypes.c_int),('ndim',ctypes.c_int),('format',ctypes.c_char_p),('shape',_c_ssize_p),('strides',_c_ssize_p),('suboffsets',_c_ssize_p),('internal',c_void_p)]
		if sys.version_info[0]==2:_fields_.insert(-1,('smalltable',_c_ssize_t*2))
	def c_uint8_ptr(data):
		A=data
		if byte_string(A)or isinstance(A,_Array):return A
		elif isinstance(A,_buffer_type):
			C=_py_object(A);B=_Py_buffer();_PyObject_GetBuffer(C,byref(B),_PyBUF_SIMPLE)
			try:D=c_ubyte*B.len;return D.from_address(B.buf)
			finally:_PyBuffer_Release(byref(B))
		else:raise TypeError(_B%type(A))
	class VoidPointer_ctypes(_VoidPointer):
		def __init__(A):A._p=c_void_p()
		def get(A):return A._p
		def address_of(A):return byref(A._p)
	def VoidPointer():return VoidPointer_ctypes()
	backend='ctypes';del ctypes
class SmartPointer:
	def __init__(A,raw_pointer,destructor):A._raw_pointer=raw_pointer;A._destructor=destructor
	def get(A):return A._raw_pointer
	def release(A):B,A._raw_pointer=A._raw_pointer,_A;return B
	def __del__(A):
		try:
			if A._raw_pointer is not _A:A._destructor(A._raw_pointer);A._raw_pointer=_A
		except AttributeError:pass
def load_pycryptodome_raw_lib(name,cdecl):
	A=name.split('.');D,E=A[:-1],A[-1];B=[]
	for F in extension_suffixes:
		try:C=E+F;return load_lib(pycryptodome_filename(D,C),cdecl)
		except OSError as G:B.append("Trying '%s': %s"%(C,str(G)))
	raise OSError("Cannot load native module '%s': %s"%(name,', '.join(B)))
def is_buffer(x):return isinstance(x,(bytes,bytearray,memoryview))
def is_writeable_buffer(x):return isinstance(x,bytearray)or isinstance(x,memoryview)and not x.readonly