def shift_hue(image,hue):
	C=hue;C=(C-1.0)*180;B=image.copy().convert('HSV');D=B.load()
	for E in range(B.width):
		for F in range(B.height):
			A,G,H=D[(E,F)];A=abs(int(A+C))
			if A>255:A-=255
			D[(E,F)]=A,G,H
	return B.convert('RGBA')
def make_transparent(image):
	A=image;D=A.copy().getdata();B=[]
	for C in D:
		if _check_pixel(C)is True:B.append((255,255,255,255));continue
		B.append(C)
	A.putdata(B);return A
def _check_pixel(tup):A=tup;return A[0]==0 and A[1]==0 and A[2]==0