_M='Non-relative patterns are unsupported'
_L='%r has an empty name'
_K='_parts'
_J="Can't determine home directory for %r"
_I='_root'
_H='_drv'
_G='**'
_F='/'
_E='nt'
_D=True
_C='.'
_B=None
_A=False
import fnmatch,functools,io,ntpath,os,posixpath,re,sys
from _collections_abc import Sequence
from errno import EINVAL,ENOENT,ENOTDIR,EBADF,ELOOP
from operator import attrgetter
from stat import S_ISDIR,S_ISLNK,S_ISREG,S_ISSOCK,S_ISBLK,S_ISCHR,S_ISFIFO
from urllib.parse import quote_from_bytes as urlquote_from_bytes
supports_symlinks=_D
if os.name==_E:
	import nt
	if sys.getwindowsversion()[:2]>=(6,0):from nt import _getfinalpathname
	else:supports_symlinks=_A;_getfinalpathname=_B
else:nt=_B
__all__=['PurePath','PurePosixPath','PureWindowsPath','Path','PosixPath','WindowsPath']
_IGNORED_ERROS=ENOENT,ENOTDIR,EBADF,ELOOP
_IGNORED_WINERRORS=21,1921
def _ignore_error(exception):A=exception;return getattr(A,'errno',_B)in _IGNORED_ERROS or getattr(A,'winerror',_B)in _IGNORED_WINERRORS
def _is_wildcard_pattern(pat):A=pat;return'*'in A or'?'in A or'['in A
class _Flavour:
	def __init__(A):A.join=A.sep.join
	def parse_parts(F,parts):
		C=[];G=F.sep;H=F.altsep;B=D='';J=reversed(parts)
		for A in J:
			if not A:continue
			if H:A=A.replace(H,G)
			B,D,E=F.splitroot(A)
			if G in E:
				for I in reversed(E.split(G)):
					if I and I!=_C:C.append(sys.intern(I))
			elif E and E!=_C:C.append(sys.intern(E))
			if B or D:
				if not B:
					for A in J:
						if not A:continue
						if H:A=A.replace(H,G)
						B=F.splitroot(A)[0]
						if B:break
				break
		if B or D:C.append(B+D)
		C.reverse();return B,D,C
	def join_parsed_parts(E,drv,root,parts,drv2,root2,parts2):
		F=parts;D=parts2;C=root2;B=drv2;A=drv
		if C:
			if not B and A:return A,C,[A+C]+D[1:]
		elif B:
			if B==A or E.casefold(B)==E.casefold(A):return A,root,F+D[1:]
		else:return A,root,F+D
		return B,C,D
class _WindowsFlavour(_Flavour):
	sep='\\';altsep=_F;has_drv=_D;pathmod=ntpath;is_supported=os.name==_E;drive_letters=set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ');ext_namespace_prefix='\\\\?\\';reserved_names={'CON','PRN','AUX','NUL'}|{'COM%d'%A for A in range(1,10)}|{'LPT%d'%A for A in range(1,10)}
	def splitroot(H,part,sep=sep):
		B=sep;A=part;C=A[0:1];E=A[1:2]
		if E==B and C==B:F,A=H._split_extended_path(A);C=A[0:1];E=A[1:2]
		else:F=''
		I=A[2:3]
		if E==B and C==B and I!=B:
			G=A.find(B,2)
			if G!=-1:
				D=A.find(B,G+1)
				if D!=G+1:
					if D==-1:D=len(A)
					if F:return F+A[1:D],B,A[D+1:]
					else:return A[:D],B,A[D+1:]
		J=K=''
		if E==':'and C in H.drive_letters:J=A[:2];A=A[2:];C=I
		if C==B:K=C;A=A.lstrip(B)
		return F+J,K,A
	def casefold(A,s):return s.lower()
	def casefold_parts(A,parts):return[A.lower()for A in parts]
	def compile_pattern(A,pattern):return re.compile(fnmatch.translate(pattern),re.IGNORECASE).fullmatch
	def resolve(B,path,strict=_A):
		A=str(path)
		if not A:return os.getcwd()
		C=_B
		if _getfinalpathname is not _B:
			if strict:return B._ext_to_normal(_getfinalpathname(A))
			else:
				D=[]
				while _D:
					try:A=B._ext_to_normal(_getfinalpathname(A))
					except FileNotFoundError:
						C=A;A,E=os.path.split(A);D.append(E)
						if C==A:return path
					else:return os.path.join(A,*reversed(D))
		return _B
	def _split_extended_path(B,s,ext_prefix=ext_namespace_prefix):
		A=''
		if s.startswith(ext_prefix):
			A=s[:4];s=s[4:]
			if s.startswith('UNC\\'):A+=s[:3];s='\\'+s[3:]
		return A,s
	def _ext_to_normal(A,s):return A._split_extended_path(s)[1]
	def is_reserved(B,parts):
		A=parts
		if not A:return _A
		if A[0].startswith('\\\\'):return _A
		return A[-1].partition(_C)[0].upper()in B.reserved_names
	def make_uri(E,path):
		D='utf-8';A=path;B=A.drive
		if len(B)==2 and B[1]==':':C=A.as_posix()[2:].lstrip(_F);return'file:///%s/%s'%(B,urlquote_from_bytes(C.encode(D)))
		else:return'file:'+urlquote_from_bytes(A.as_posix().encode(D))
	def gethomedir(E,username):
		I='USERNAME';H='HOMEPATH';G='USERPROFILE';C=username
		if G in os.environ:A=os.environ[G]
		elif H in os.environ:
			try:B=os.environ['HOMEDRIVE']
			except KeyError:B=''
			A=B+os.environ[H]
		else:raise RuntimeError("Can't determine home directory")
		if C:
			if os.environ[I]!=C:
				B,F,D=E.parse_parts((A,))
				if D[-1]!=os.environ[I]:raise RuntimeError(_J%C)
				D[-1]=C
				if B or F:A=B+F+E.join(D[1:])
				else:A=E.join(D)
		return A
class _PosixFlavour(_Flavour):
	sep=_F;altsep='';has_drv=_A;pathmod=posixpath;is_supported=os.name!=_E
	def splitroot(D,part,sep=sep):
		B=sep;A=part
		if A and A[0]==B:
			C=A.lstrip(B)
			if len(A)-len(C)==2:return'',B*2,C
			else:return'',B,C
		else:return'','',A
	def casefold(A,s):return s
	def casefold_parts(A,parts):return parts
	def compile_pattern(A,pattern):return re.compile(fnmatch.translate(pattern)).fullmatch
	def resolve(B,path,strict=_A):
		A=path;C=B.sep;G=A._accessor;E={}
		def F(path,rest):
			A=path
			if rest.startswith(C):A=''
			for D in rest.split(C):
				if not D or D==_C:continue
				if D=='..':A,H,H=A.rpartition(C);continue
				if A.endswith(C):B=A+D
				else:B=A+C+D
				if B in E:
					A=E[B]
					if A is not _B:continue
					raise RuntimeError('Symlink loop from %r'%B)
				try:I=G.readlink(B)
				except OSError as J:
					if J.errno!=EINVAL and strict:raise
					A=B
				else:E[B]=_B;A=F(A,I);E[B]=A
			return A
		D=''if A.is_absolute()else os.getcwd();return F(D,str(A))or C
	def is_reserved(A,parts):return _A
	def make_uri(B,path):A=bytes(path);return'file://'+urlquote_from_bytes(A)
	def gethomedir(B,username):
		A=username
		if not A:
			try:return os.environ['HOME']
			except KeyError:import pwd;return pwd.getpwuid(os.getuid()).pw_dir
		else:
			import pwd
			try:return pwd.getpwnam(A).pw_dir
			except KeyError:raise RuntimeError(_J%A)
_windows_flavour=_WindowsFlavour()
_posix_flavour=_PosixFlavour()
class _Accessor:0
class _NormalAccessor(_Accessor):
	stat=os.stat;lstat=os.lstat;open=os.open;listdir=os.listdir;scandir=os.scandir;chmod=os.chmod
	if hasattr(os,'lchmod'):lchmod=os.lchmod
	else:
		def lchmod(A,pathobj,mode):raise NotImplementedError('lchmod() not available on this system')
	mkdir=os.mkdir;unlink=os.unlink
	if hasattr(os,'link'):link_to=os.link
	else:
		@staticmethod
		def link_to(self,target):raise NotImplementedError('os.link() not available on this system')
	rmdir=os.rmdir;rename=os.rename;replace=os.replace
	if nt:
		if supports_symlinks:symlink=os.symlink
		else:
			def symlink(A,b,target_is_directory):raise NotImplementedError('symlink() not available on this system')
	else:
		@staticmethod
		def symlink(a,b,target_is_directory):return os.symlink(a,b)
	utime=os.utime
	def readlink(A,path):return os.readlink(path)
_normal_accessor=_NormalAccessor()
def _make_selector(pattern_parts,flavour):
	C=pattern_parts;A=C[0];D=C[1:]
	if A==_G:B=_RecursiveWildcardSelector
	elif _G in A:raise ValueError("Invalid pattern: '**' can only be an entire path component")
	elif _is_wildcard_pattern(A):B=_WildcardSelector
	else:B=_PreciseSelector
	return B(A,D,flavour)
if hasattr(functools,'lru_cache'):_make_selector=functools.lru_cache()(_make_selector)
class _Selector:
	def __init__(A,child_parts,flavour):
		B=child_parts;A.child_parts=B
		if B:A.successor=_make_selector(B,flavour);A.dironly=_D
		else:A.successor=_TerminatingSelector();A.dironly=_A
	def select_from(D,parent_path):
		A=parent_path;B=type(A);C=B.is_dir;E=B.exists;F=A._accessor.scandir
		if not C(A):return iter([])
		return D._select_from(A,C,E,F)
class _TerminatingSelector:
	def _select_from(A,parent_path,is_dir,exists,scandir):yield parent_path
class _PreciseSelector(_Selector):
	def __init__(A,name,child_parts,flavour):A.name=name;_Selector.__init__(A,child_parts,flavour)
	def _select_from(A,parent_path,is_dir,exists,scandir):
		C=exists;B=is_dir
		try:
			D=parent_path._make_child_relpath(A.name)
			if(B if A.dironly else C)(D):
				for E in A.successor._select_from(D,B,C,scandir):yield E
		except PermissionError:return
class _WildcardSelector(_Selector):
	def __init__(A,pat,child_parts,flavour):B=flavour;A.match=B.compile_pattern(pat);_Selector.__init__(A,child_parts,B)
	def _select_from(A,parent_path,is_dir,exists,scandir):
		C=scandir;B=parent_path
		try:
			with C(B)as F:G=list(F)
			for D in G:
				if A.dironly:
					try:
						if not D.is_dir():continue
					except OSError as H:
						if not _ignore_error(H):raise
						continue
				E=D.name
				if A.match(E):
					I=B._make_child_relpath(E)
					for J in A.successor._select_from(I,is_dir,exists,C):yield J
		except PermissionError:return
class _RecursiveWildcardSelector(_Selector):
	def __init__(A,pat,child_parts,flavour):_Selector.__init__(A,child_parts,flavour)
	def _iterate_directories(E,parent_path,is_dir,scandir):
		C=scandir;A=parent_path;yield A
		try:
			with C(A)as F:G=list(F)
			for B in G:
				D=_A
				try:D=B.is_dir()
				except OSError as H:
					if not _ignore_error(H):raise
				if D and not B.is_symlink():
					I=A._make_child_relpath(B.name)
					for J in E._iterate_directories(I,is_dir,C):yield J
		except PermissionError:return
	def _select_from(C,parent_path,is_dir,exists,scandir):
		E=scandir;D=is_dir
		try:
			A=set()
			try:
				F=C.successor._select_from
				for G in C._iterate_directories(parent_path,D,E):
					for B in F(G,D,exists,E):
						if B not in A:yield B;A.add(B)
			finally:A.clear()
		except PermissionError:return
class _PathParents(Sequence):
	__slots__='_pathcls',_H,_I,_K
	def __init__(A,path):B=path;A._pathcls=type(B);A._drv=B._drv;A._root=B._root;A._parts=B._parts
	def __len__(A):
		if A._drv or A._root:return len(A._parts)-1
		else:return len(A._parts)
	def __getitem__(A,idx):
		B=idx
		if B<0 or B>=len(A):raise IndexError(B)
		return A._pathcls._from_parsed_parts(A._drv,A._root,A._parts[:-B-1])
	def __repr__(A):return '<{}.parents>'.format(A._pathcls.__name__)
class PurePath:
	__slots__=_H,_I,_K,'_str','_hash','_pparts','_cached_cparts'
	def __new__(A,*B):
		if A is PurePath:A=PureWindowsPath if os.name==_E else PurePosixPath
		return A._from_parts(B)
	def __reduce__(A):return A.__class__,tuple(A._parts)
	@classmethod
	def _parse_args(C,args):
		B=[]
		for A in args:
			if isinstance(A,PurePath):B+=A._parts
			else:
				A=os.fspath(A)
				if isinstance(A,str):B.append(str(A))
				else:raise TypeError('argument should be a str object or an os.PathLike object returning str, not %r'%type(A))
		return C._flavour.parse_parts(B)
	@classmethod
	def _from_parts(B,args,init=_D):
		A=object.__new__(B);C,D,E=A._parse_args(args);A._drv=C;A._root=D;A._parts=E
		if init:A._init()
		return A
	@classmethod
	def _from_parsed_parts(B,drv,root,parts,init=_D):
		A=object.__new__(B);A._drv=drv;A._root=root;A._parts=parts
		if init:A._init()
		return A
	@classmethod
	def _format_parsed_parts(A,drv,root,parts):
		B=parts
		if drv or root:return drv+root+A._flavour.join(B[1:])
		else:return A._flavour.join(B)
	def _init(A):0
	def _make_child(A,args):B,C,D=A._parse_args(args);B,C,D=A._flavour.join_parsed_parts(A._drv,A._root,A._parts,B,C,D);return A._from_parsed_parts(B,C,D)
	def __str__(A):
		try:return A._str
		except AttributeError:A._str=A._format_parsed_parts(A._drv,A._root,A._parts)or _C;return A._str
	def __fspath__(A):return str(A)
	def as_posix(A):B=A._flavour;return str(A).replace(B.sep,_F)
	def __bytes__(A):return os.fsencode(A)
	def __repr__(A):return '{}({!r})'.format(A.__class__.__name__,A.as_posix())
	def as_uri(A):
		if not A.is_absolute():raise ValueError("relative path can't be expressed as a file URI")
		return A._flavour.make_uri(A)
	@property
	def _cparts(self):
		A=self
		try:return A._cached_cparts
		except AttributeError:A._cached_cparts=A._flavour.casefold_parts(A._parts);return A._cached_cparts
	def __eq__(B,other):
		A=other
		if not isinstance(A,PurePath):return NotImplemented
		return B._cparts==A._cparts and B._flavour is A._flavour
	def __hash__(A):
		try:return A._hash
		except AttributeError:A._hash=hash(tuple(A._cparts));return A._hash
	def __lt__(B,other):
		A=other
		if not isinstance(A,PurePath)or B._flavour is not A._flavour:return NotImplemented
		return B._cparts<A._cparts
	def __le__(B,other):
		A=other
		if not isinstance(A,PurePath)or B._flavour is not A._flavour:return NotImplemented
		return B._cparts<=A._cparts
	def __gt__(B,other):
		A=other
		if not isinstance(A,PurePath)or B._flavour is not A._flavour:return NotImplemented
		return B._cparts>A._cparts
	def __ge__(B,other):
		A=other
		if not isinstance(A,PurePath)or B._flavour is not A._flavour:return NotImplemented
		return B._cparts>=A._cparts
	drive=property(attrgetter(_H),doc='The drive prefix (letter or UNC path), if any.');root=property(attrgetter(_I),doc='The root of the path, if any.')
	@property
	def anchor(self):A=self._drv+self._root;return A
	@property
	def name(self):
		A=self;B=A._parts
		if len(B)==(1 if A._drv or A._root else 0):return''
		return B[-1]
	@property
	def suffix(self):
		A=self.name;B=A.rfind(_C)
		if 0<B<len(A)-1:return A[B:]
		else:return''
	@property
	def suffixes(self):
		A=self.name
		if A.endswith(_C):return[]
		A=A.lstrip(_C);return[_C+B for B in A.split(_C)[1:]]
	@property
	def stem(self):
		A=self.name;B=A.rfind(_C)
		if 0<B<len(A)-1:return A[:B]
		else:return A
	def with_name(A,name):
		B=name
		if not A.name:raise ValueError(_L%(A,))
		C,D,E=A._flavour.parse_parts((B,))
		if not B or B[-1]in[A._flavour.sep,A._flavour.altsep]or C or D or len(E)!=1:raise ValueError('Invalid name %r'%B)
		return A._from_parsed_parts(A._drv,A._root,A._parts[:-1]+[B])
	def with_suffix(B,suffix):
		F='Invalid suffix %r';A=suffix;D=B._flavour
		if D.sep in A or D.altsep and D.altsep in A:raise ValueError(F%(A,))
		if A and not A.startswith(_C)or A==_C:raise ValueError(F%A)
		C=B.name
		if not C:raise ValueError(_L%(B,))
		E=B.suffix
		if not E:C=C+A
		else:C=C[:-len(E)]+A
		return B._from_parsed_parts(B._drv,B._root,B._parts[:-1]+[C])
	def relative_to(A,*H):
		if not H:raise TypeError('need at least one argument')
		I=A._parts;J=A._drv;B=A._root
		if B:D=[J,B]+I[1:]
		else:D=I
		K,E,F=A._parse_args(H)
		if E:G=[K,E]+F[1:]
		else:G=F
		C=len(G);L=A._flavour.casefold_parts
		if B or J if C==0 else L(D[:C])!=L(G):M=A._format_parsed_parts(K,E,F);raise ValueError('{!r} does not start with {!r}'.format(str(A),str(M)))
		return A._from_parsed_parts('',B if C==1 else'',D[C:])
	@property
	def parts(self):
		A=self
		try:return A._pparts
		except AttributeError:A._pparts=tuple(A._parts);return A._pparts
	def joinpath(A,*B):return A._make_child(B)
	def __truediv__(A,key):
		try:return A._make_child((key,))
		except TypeError:return NotImplemented
	def __rtruediv__(A,key):
		try:return A._from_parts([key]+A._parts)
		except TypeError:return NotImplemented
	@property
	def parent(self):
		A=self;B=A._drv;C=A._root;D=A._parts
		if len(D)==1 and(B or C):return A
		return A._from_parsed_parts(B,C,D[:-1])
	@property
	def parents(self):return _PathParents(self)
	def is_absolute(A):
		if not A._root:return _A
		return not A._flavour.has_drv or bool(A._drv)
	def is_reserved(A):return A._flavour.is_reserved(A._parts)
	def match(B,path_pattern):
		C=path_pattern;D=B._flavour.casefold;C=D(C);E,F,A=B._flavour.parse_parts((C,))
		if not A:raise ValueError('empty pattern')
		if E and E!=D(B._drv):return _A
		if F and F!=D(B._root):return _A
		G=B._cparts
		if E or F:
			if len(A)!=len(G):return _A
			A=A[1:]
		elif len(A)>len(G):return _A
		for (H,I) in zip(reversed(G),reversed(A)):
			if not fnmatch.fnmatchcase(H,I):return _A
		return _D
os.PathLike.register(PurePath)
class PurePosixPath(PurePath):_flavour=_posix_flavour;__slots__=()
class PureWindowsPath(PurePath):_flavour=_windows_flavour;__slots__=()
class Path(PurePath):
	__slots__='_accessor','_closed'
	def __new__(A,*C,**D):
		if A is Path:A=WindowsPath if os.name==_E else PosixPath
		B=A._from_parts(C,init=_A)
		if not B._flavour.is_supported:raise NotImplementedError('cannot instantiate %r on your system'%(A.__name__,))
		B._init();return B
	def _init(A,template=_B):
		B=template;A._closed=_A
		if B is not _B:A._accessor=B._accessor
		else:A._accessor=_normal_accessor
	def _make_child_relpath(A,part):B=A._parts+[part];return A._from_parsed_parts(A._drv,A._root,B)
	def __enter__(A):
		if A._closed:A._raise_closed()
		return A
	def __exit__(A,t,v,tb):A._closed=_D
	def _raise_closed(A):raise ValueError('I/O operation on closed path')
	def _opener(A,name,flags,mode=438):return A._accessor.open(A,flags,mode)
	def _raw_open(A,flags,mode=511):
		if A._closed:A._raise_closed()
		return A._accessor.open(A,flags,mode)
	@classmethod
	def cwd(A):return A(os.getcwd())
	@classmethod
	def home(A):return A(A()._flavour.gethomedir(_B))
	def samefile(C,other_path):
		A=other_path;D=C.stat()
		try:B=A.stat()
		except AttributeError:B=os.stat(A)
		return os.path.samestat(D,B)
	def iterdir(A):
		if A._closed:A._raise_closed()
		for B in A._accessor.listdir(A):
			if B in{_C,'..'}:continue
			yield A._make_child_relpath(B)
			if A._closed:A._raise_closed()
	def glob(A,pattern):
		B=pattern
		if not B:raise ValueError('Unacceptable pattern: {!r}'.format(B))
		C,D,E=A._flavour.parse_parts((B,))
		if C or D:raise NotImplementedError(_M)
		F=_make_selector(tuple(E),A._flavour)
		for G in F.select_from(A):yield G
	def rglob(A,pattern):
		B,C,D=A._flavour.parse_parts((pattern,))
		if B or C:raise NotImplementedError(_M)
		E=_make_selector((_G,)+tuple(D),A._flavour)
		for F in E.select_from(A):yield F
	def absolute(A):
		if A._closed:A._raise_closed()
		if A.is_absolute():return A
		B=A._from_parts([os.getcwd()]+A._parts,init=_A);B._init(template=A);return B
	def resolve(A,strict=_A):
		if A._closed:A._raise_closed()
		B=A._flavour.resolve(A,strict=strict)
		if B is _B:A.stat();B=str(A.absolute())
		D=A._flavour.pathmod.normpath(B);C=A._from_parts((D,),init=_A);C._init(template=A);return C
	def stat(A):return A._accessor.stat(A)
	def owner(A):import pwd;return pwd.getpwuid(A.stat().st_uid).pw_name
	def group(A):import grp;return grp.getgrgid(A.stat().st_gid).gr_name
	def open(A,mode='r',buffering=-1,encoding=_B,errors=_B,newline=_B):
		if A._closed:A._raise_closed()
		return io.open(A,mode,buffering,encoding,errors,newline,opener=A._opener)
	def read_bytes(A):
		with A.open(mode='rb')as B:return B.read()
	def read_text(A,encoding=_B,errors=_B):
		with A.open(mode='r',encoding=encoding,errors=errors)as B:return B.read()
	def write_bytes(A,data):
		B=memoryview(data)
		with A.open(mode='wb')as C:return C.write(B)
	def write_text(B,data,encoding=_B,errors=_B):
		A=data
		if not isinstance(A,str):raise TypeError('data must be str, not %s'%A.__class__.__name__)
		with B.open(mode='w',encoding=encoding,errors=errors)as C:return C.write(A)
	def touch(A,mode=438,exist_ok=_D):
		B=exist_ok
		if A._closed:A._raise_closed()
		if B:
			try:A._accessor.utime(A,_B)
			except OSError:pass
			else:return
		C=os.O_CREAT|os.O_WRONLY
		if not B:C|=os.O_EXCL
		D=A._raw_open(C,mode);os.close(D)
	def mkdir(A,mode=511,parents=_A,exist_ok=_A):
		B=exist_ok
		if A._closed:A._raise_closed()
		try:A._accessor.mkdir(A,mode)
		except FileNotFoundError:
			if not parents or A.parent==A:raise
			A.parent.mkdir(parents=_D,exist_ok=_D);A.mkdir(mode,parents=_A,exist_ok=B)
		except OSError:
			if not B or not A.is_dir():raise
	def chmod(A,mode):
		if A._closed:A._raise_closed()
		A._accessor.chmod(A,mode)
	def lchmod(A,mode):
		if A._closed:A._raise_closed()
		A._accessor.lchmod(A,mode)
	def unlink(A,missing_ok=_A):
		if A._closed:A._raise_closed()
		try:A._accessor.unlink(A)
		except FileNotFoundError:
			if not missing_ok:raise
	def rmdir(A):
		if A._closed:A._raise_closed()
		A._accessor.rmdir(A)
	def lstat(A):
		if A._closed:A._raise_closed()
		return A._accessor.lstat(A)
	def link_to(A,target):
		if A._closed:A._raise_closed()
		A._accessor.link_to(A,target)
	def rename(A,target):
		B=target
		if A._closed:A._raise_closed()
		A._accessor.rename(A,B);return A.__class__(B)
	def replace(A,target):
		B=target
		if A._closed:A._raise_closed()
		A._accessor.replace(A,B);return A.__class__(B)
	def symlink_to(A,target,target_is_directory=_A):
		if A._closed:A._raise_closed()
		A._accessor.symlink(target,A,target_is_directory)
	def exists(A):
		try:A.stat()
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
		return _D
	def is_dir(A):
		try:return S_ISDIR(A.stat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def is_file(A):
		try:return S_ISREG(A.stat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def is_mount(A):
		if not A.exists()or not A.is_dir():return _A
		B=Path(A.parent)
		try:C=B.stat().st_dev
		except OSError:return _A
		D=A.stat().st_dev
		if D!=C:return _D
		E=A.stat().st_ino;F=B.stat().st_ino;return E==F
	def is_symlink(A):
		try:return S_ISLNK(A.lstat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def is_block_device(A):
		try:return S_ISBLK(A.stat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def is_char_device(A):
		try:return S_ISCHR(A.stat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def is_fifo(A):
		try:return S_ISFIFO(A.stat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def is_socket(A):
		try:return S_ISSOCK(A.stat().st_mode)
		except OSError as B:
			if not _ignore_error(B):raise
			return _A
		except ValueError:return _A
	def expanduser(A):
		if not(A._drv or A._root)and A._parts and A._parts[0][:1]=='~':B=A._flavour.gethomedir(A._parts[0][1:]);return A._from_parts([B]+A._parts[1:])
		return A
class PosixPath(Path,PurePosixPath):__slots__=()
class WindowsPath(Path,PureWindowsPath):
	__slots__=()
	def owner(A):raise NotImplementedError('Path.owner() is unsupported on this system')
	def group(A):raise NotImplementedError('Path.group() is unsupported on this system')
	def is_mount(A):raise NotImplementedError('Path.is_mount() is unsupported on this system')