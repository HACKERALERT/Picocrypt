_A='strict'
import codecs
def encode(input,errors=_A):return codecs.BOM_UTF8+codecs.utf_8_encode(input,errors)[0],len(input)
def decode(input,errors=_A):
	A=0
	if input[:3]==codecs.BOM_UTF8:input=input[3:];A=3
	B,C=codecs.utf_8_decode(input,errors,True);return B,C+A
class IncrementalEncoder(codecs.IncrementalEncoder):
	def __init__(A,errors=_A):codecs.IncrementalEncoder.__init__(A,errors);A.first=1
	def encode(A,input,final=False):
		if A.first:A.first=0;return codecs.BOM_UTF8+codecs.utf_8_encode(input,A.errors)[0]
		else:return codecs.utf_8_encode(input,A.errors)[0]
	def reset(A):codecs.IncrementalEncoder.reset(A);A.first=1
	def getstate(A):return A.first
	def setstate(A,state):A.first=state
class IncrementalDecoder(codecs.BufferedIncrementalDecoder):
	def __init__(A,errors=_A):codecs.BufferedIncrementalDecoder.__init__(A,errors);A.first=1
	def _buffer_decode(A,input,errors,final):
		C=final;B=errors
		if A.first:
			if len(input)<3:
				if codecs.BOM_UTF8.startswith(input):return'',0
				else:A.first=0
			else:
				A.first=0
				if input[:3]==codecs.BOM_UTF8:D,E=codecs.utf_8_decode(input[3:],B,C);return D,E+3
		return codecs.utf_8_decode(input,B,C)
	def reset(A):codecs.BufferedIncrementalDecoder.reset(A);A.first=1
	def getstate(A):B=codecs.BufferedIncrementalDecoder.getstate(A);return B[0],A.first
	def setstate(A,state):B=state;codecs.BufferedIncrementalDecoder.setstate(A,B);A.first=B[1]
class StreamWriter(codecs.StreamWriter):
	def reset(A):
		codecs.StreamWriter.reset(A)
		try:del A.encode
		except AttributeError:pass
	def encode(A,input,errors=_A):A.encode=codecs.utf_8_encode;return encode(input,errors)
class StreamReader(codecs.StreamReader):
	def reset(A):
		codecs.StreamReader.reset(A)
		try:del A.decode
		except AttributeError:pass
	def decode(A,input,errors=_A):
		B=errors
		if len(input)<3:
			if codecs.BOM_UTF8.startswith(input):return'',0
		elif input[:3]==codecs.BOM_UTF8:A.decode=codecs.utf_8_decode;C,D=codecs.utf_8_decode(input[3:],B);return C,D+3
		A.decode=codecs.utf_8_decode;return codecs.utf_8_decode(input,B)
def getregentry():return codecs.CodecInfo(name='utf-8-sig',encode=encode,decode=decode,incrementalencoder=IncrementalEncoder,incrementaldecoder=IncrementalDecoder,streamreader=StreamReader,streamwriter=StreamWriter)