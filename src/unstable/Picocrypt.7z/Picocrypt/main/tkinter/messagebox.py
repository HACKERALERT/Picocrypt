_F='warning'
_E='question'
_D='info'
_C='error'
_B='Spam'
_A=None
from tkinter.commondialog import Dialog
ERROR=_C
INFO=_D
QUESTION=_E
WARNING=_F
ABORTRETRYIGNORE='abortretryignore'
OK='ok'
OKCANCEL='okcancel'
RETRYCANCEL='retrycancel'
YESNO='yesno'
YESNOCANCEL='yesnocancel'
ABORT='abort'
RETRY='retry'
IGNORE='ignore'
OK='ok'
CANCEL='cancel'
YES='yes'
NO='no'
class Message(Dialog):command='tk_messageBox'
def _show(title=_A,message=_A,_icon=_A,_type=_A,**A):
	H='type';G='icon';F=_type;E=_icon;D=message;C=title
	if E and G not in A:A[G]=E
	if F and H not in A:A[H]=F
	if C:A['title']=C
	if D:A['message']=D
	B=Message(**A).show()
	if isinstance(B,bool):
		if B:return YES
		return NO
	return str(B)
def showinfo(title=_A,message=_A,**A):return _show(title,message,INFO,OK,**A)
def showwarning(title=_A,message=_A,**A):return _show(title,message,WARNING,OK,**A)
def showerror(title=_A,message=_A,**A):return _show(title,message,ERROR,OK,**A)
def askquestion(title=_A,message=_A,**A):return _show(title,message,QUESTION,YESNO,**A)
def askokcancel(title=_A,message=_A,**A):B=_show(title,message,QUESTION,OKCANCEL,**A);return B==OK
def askyesno(title=_A,message=_A,**A):B=_show(title,message,QUESTION,YESNO,**A);return B==YES
def askyesnocancel(title=_A,message=_A,**B):
	A=_show(title,message,QUESTION,YESNOCANCEL,**B);A=str(A)
	if A==CANCEL:return _A
	return A==YES
def askretrycancel(title=_A,message=_A,**A):B=_show(title,message,WARNING,RETRYCANCEL,**A);return B==RETRY
if __name__=='__main__':print(_D,showinfo(_B,'Egg Information'));print(_F,showwarning(_B,'Egg Warning'));print(_C,showerror(_B,'Egg Alert'));print(_E,askquestion(_B,'Question?'));print('proceed',askokcancel(_B,'Proceed?'));print('yes/no',askyesno(_B,'Got it?'));print('yes/no/cancel',askyesnocancel(_B,'Want it?'));print('try again',askretrycancel(_B,'Try again?'))