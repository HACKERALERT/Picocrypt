import os
from pathlib import Path
def isPath(f):return isinstance(f,(bytes,str,Path))
def isDirectory(f):return isPath(f)and os.path.isdir(f)
class deferred_error:
	def __init__(A,ex):A.ex=ex
	def __getattr__(A,elt):raise A.ex