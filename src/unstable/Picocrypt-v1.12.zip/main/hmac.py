_D=b'\x00'
_C='block_size'
_B=b''
_A=None
import warnings as _warnings
from _operator import _compare_digest as compare_digest
try:import _hashlib as _hashopenssl
except ImportError:_hashopenssl=_A;_openssl_md_meths=_A
else:_openssl_md_meths=frozenset(_hashopenssl.openssl_md_meth_names)
import hashlib as _hashlib
trans_5C=bytes((A^92 for A in range(256)))
trans_36=bytes((A^54 for A in range(256)))
digest_size=_A
class HMAC:
	blocksize=64
	def __init__(A,key,msg=_A,digestmod=''):
		D=digestmod;B=key
		if not isinstance(B,(bytes,bytearray)):raise TypeError('key: expected bytes or bytearray, but got %r'%type(B).__name__)
		if not D:raise TypeError("Missing required parameter 'digestmod'.")
		if callable(D):A.digest_cons=D
		elif isinstance(D,str):A.digest_cons=lambda d=_B:_hashlib.new(D,d)
		else:A.digest_cons=lambda d=_B:D.new(d)
		A.outer=A.digest_cons();A.inner=A.digest_cons();A.digest_size=A.inner.digest_size
		if hasattr(A.inner,_C):
			C=A.inner.block_size
			if C<16:_warnings.warn('block_size of %d seems too small; using our default of %d.'%(C,A.blocksize),RuntimeWarning,2);C=A.blocksize
		else:_warnings.warn('No block_size attribute on given digest object; Assuming %d.'%A.blocksize,RuntimeWarning,2);C=A.blocksize
		A.block_size=C
		if len(B)>C:B=A.digest_cons(B).digest()
		B=B.ljust(C,_D);A.outer.update(B.translate(trans_5C));A.inner.update(B.translate(trans_36))
		if msg is not _A:A.update(msg)
	@property
	def name(self):return'hmac-'+self.inner.name
	def update(A,msg):A.inner.update(msg)
	def copy(A):B=A.__class__.__new__(A.__class__);B.digest_cons=A.digest_cons;B.digest_size=A.digest_size;B.inner=A.inner.copy();B.outer=A.outer.copy();return B
	def _current(A):B=A.outer.copy();B.update(A.inner.digest());return B
	def digest(A):B=A._current();return B.digest()
	def hexdigest(A):B=A._current();return B.hexdigest()
def new(key,msg=_A,digestmod=''):return HMAC(key,msg,digestmod)
def digest(key,msg,digest):
	B=digest;A=key
	if _hashopenssl is not _A and isinstance(B,str)and B in _openssl_md_meths:return _hashopenssl.hmac_digest(A,msg,B)
	if callable(B):C=B
	elif isinstance(B,str):C=lambda d=_B:_hashlib.new(B,d)
	else:C=lambda d=_B:B.new(d)
	D=C();E=C();F=getattr(D,_C,64)
	if len(A)>F:A=C(A).digest()
	A=A+_D*(F-len(A));D.update(A.translate(trans_36));E.update(A.translate(trans_5C));D.update(msg);E.update(D.digest());return E.digest()