from __future__ import absolute_import
_A2='assertNotRegexpMatches'
_A1='assertRegexpMatches'
_A0='assertRaisesRegexp'
_z='moves.urllib_robotparser'
_y='moves.urllib_response'
_x='moves.urllib_request'
_w='moves.urllib_error'
_v='moves.urllib_parse'
_u='unquote_to_bytes'
_t='unquote'
_s='urllib.robotparser'
_r='.moves.urllib_parse'
_q='tkinter.simpledialog'
_p='tkinter.filedialog'
_o='cPickle'
_n='SimpleHTTPServer'
_m='CGIHTTPServer'
_l='BaseHTTPServer'
_k='_dummy_thread'
_j='zip_longest'
_i='zip'
_h='UserString'
_g='UserList'
_f='UserDict'
_e='quote'
_d='getcwdb'
_c='map'
_b='input'
_a='filterfalse'
_Z='filter'
_Y='cStringIO'
_X="not expecting type '%s'"
_W='robotparser'
_V='.moves.urllib'
_U='http.server'
_T='_thread'
_S='xrange'
_R='range'
_Q='getcwd'
_P='StringIO'
_O='utf-8'
_N='strict'
_M='urllib.response'
_L='urllib.error'
_K='os'
_J='collections'
_I='__builtin__'
_H='builtins'
_G='itertools'
_F='urlparse'
_E='urllib'
_D='urllib.parse'
_C='urllib2'
_B='urllib.request'
_A=None
import functools,itertools,operator,sys,types
__author__='Benjamin Peterson <benjamin@python.org>'
__version__='1.15.0'
PY2=sys.version_info[0]==2
PY3=sys.version_info[0]==3
PY34=sys.version_info[0:2]>=(3,4)
if PY3:string_types=str,;integer_types=int,;class_types=type,;text_type=str;binary_type=bytes;MAXSIZE=sys.maxsize
else:
	string_types=basestring,;integer_types=int,long;class_types=type,types.ClassType;text_type=unicode;binary_type=str
	if sys.platform.startswith('java'):MAXSIZE=int((1<<31)-1)
	else:
		class X:
			def __len__(self):return 1<<31
		try:len(X())
		except OverflowError:MAXSIZE=int((1<<31)-1)
		else:MAXSIZE=int((1<<63)-1)
		del X
def _add_doc(func,doc):'Add documentation to a function.';func.__doc__=doc
def _import_module(name):'Import module, returning the module after the last dot.';__import__(name);return sys.modules[name]
class _LazyDescr:
	def __init__(self,name):self.name=name
	def __get__(self,obj,tp):
		result=self._resolve();setattr(obj,self.name,result)
		try:delattr(obj.__class__,self.name)
		except AttributeError:pass
		return result
class MovedModule(_LazyDescr):
	def __init__(self,name,old,new=_A):
		super(MovedModule,self).__init__(name)
		if PY3:
			if new is _A:new=name
			self.mod=new
		else:self.mod=old
	def _resolve(self):return _import_module(self.mod)
	def __getattr__(self,attr):_module=self._resolve();value=getattr(_module,attr);setattr(self,attr,value);return value
class _LazyModule(types.ModuleType):
	def __init__(self,name):super(_LazyModule,self).__init__(name);self.__doc__=self.__class__.__doc__
	def __dir__(self):attrs=['__doc__','__name__'];attrs+=[attr.name for attr in self._moved_attributes];return attrs
	_moved_attributes=[]
class MovedAttribute(_LazyDescr):
	def __init__(self,name,old_mod,new_mod,old_attr=_A,new_attr=_A):
		super(MovedAttribute,self).__init__(name)
		if PY3:
			if new_mod is _A:new_mod=name
			self.mod=new_mod
			if new_attr is _A:
				if old_attr is _A:new_attr=name
				else:new_attr=old_attr
			self.attr=new_attr
		else:
			self.mod=old_mod
			if old_attr is _A:old_attr=name
			self.attr=old_attr
	def _resolve(self):module=_import_module(self.mod);return getattr(module,self.attr)
class _SixMetaPathImporter:
	'\n    A meta path importer to import six.moves and its submodules.\n\n    This class implements a PEP302 finder and loader. It should be compatible\n    with Python 2.5 and all existing versions of Python3\n    '
	def __init__(self,six_module_name):self.name=six_module_name;self.known_modules={}
	def _add_module(self,mod,*fullnames):
		for fullname in fullnames:self.known_modules[self.name+'.'+fullname]=mod
	def _get_module(self,fullname):return self.known_modules[self.name+'.'+fullname]
	def find_module(self,fullname,path=_A):
		if fullname in self.known_modules:return self
		return _A
	def __get_module(self,fullname):
		try:return self.known_modules[fullname]
		except KeyError:raise ImportError('This loader does not know module '+fullname)
	def load_module(self,fullname):
		try:return sys.modules[fullname]
		except KeyError:pass
		mod=self.__get_module(fullname)
		if isinstance(mod,MovedModule):mod=mod._resolve()
		else:mod.__loader__=self
		sys.modules[fullname]=mod;return mod
	def is_package(self,fullname):'\n        Return true, if the named module is a package.\n\n        We need this method to get correct spec objects with\n        Python 3.4 (see PEP451)\n        ';return hasattr(self.__get_module(fullname),'__path__')
	def get_code(self,fullname):'Return None\n\n        Required, if is_package is implemented';self.__get_module(fullname);return _A
	get_source=get_code
_importer=_SixMetaPathImporter(__name__)
class _MovedItems(_LazyModule):'Lazy loading of moved objects';__path__=[]
_moved_attributes=[MovedAttribute(_Y,_Y,'io',_P),MovedAttribute(_Z,_G,_H,'ifilter',_Z),MovedAttribute(_a,_G,_G,'ifilterfalse',_a),MovedAttribute(_b,_I,_H,'raw_input',_b),MovedAttribute('intern',_I,'sys'),MovedAttribute(_c,_G,_H,'imap',_c),MovedAttribute(_Q,_K,_K,'getcwdu',_Q),MovedAttribute(_d,_K,_K,_Q,_d),MovedAttribute('getoutput','commands','subprocess'),MovedAttribute(_R,_I,_H,_S,_R),MovedAttribute('reload_module',_I,'importlib'if PY34 else'imp','reload'),MovedAttribute('reduce',_I,'functools'),MovedAttribute('shlex_quote','pipes','shlex',_e),MovedAttribute(_P,_P,'io'),MovedAttribute(_f,_f,_J),MovedAttribute(_g,_g,_J),MovedAttribute(_h,_h,_J),MovedAttribute(_S,_I,_H,_S,_R),MovedAttribute(_i,_G,_H,'izip',_i),MovedAttribute(_j,_G,_G,'izip_longest',_j),MovedModule(_H,_I),MovedModule('configparser','ConfigParser'),MovedModule('collections_abc',_J,'collections.abc'if sys.version_info>=(3,3)else _J),MovedModule('copyreg','copy_reg'),MovedModule('dbm_gnu','gdbm','dbm.gnu'),MovedModule('dbm_ndbm','dbm','dbm.ndbm'),MovedModule(_k,'dummy_thread',_k if sys.version_info<(3,9)else _T),MovedModule('http_cookiejar','cookielib','http.cookiejar'),MovedModule('http_cookies','Cookie','http.cookies'),MovedModule('html_entities','htmlentitydefs','html.entities'),MovedModule('html_parser','HTMLParser','html.parser'),MovedModule('http_client','httplib','http.client'),MovedModule('email_mime_base','email.MIMEBase','email.mime.base'),MovedModule('email_mime_image','email.MIMEImage','email.mime.image'),MovedModule('email_mime_multipart','email.MIMEMultipart','email.mime.multipart'),MovedModule('email_mime_nonmultipart','email.MIMENonMultipart','email.mime.nonmultipart'),MovedModule('email_mime_text','email.MIMEText','email.mime.text'),MovedModule(_l,_l,_U),MovedModule(_m,_m,_U),MovedModule(_n,_n,_U),MovedModule(_o,_o,'pickle'),MovedModule('queue','Queue'),MovedModule('reprlib','repr'),MovedModule('socketserver','SocketServer'),MovedModule(_T,'thread',_T),MovedModule('tkinter','Tkinter'),MovedModule('tkinter_dialog','Dialog','tkinter.dialog'),MovedModule('tkinter_filedialog','FileDialog',_p),MovedModule('tkinter_scrolledtext','ScrolledText','tkinter.scrolledtext'),MovedModule('tkinter_simpledialog','SimpleDialog',_q),MovedModule('tkinter_tix','Tix','tkinter.tix'),MovedModule('tkinter_ttk','ttk','tkinter.ttk'),MovedModule('tkinter_constants','Tkconstants','tkinter.constants'),MovedModule('tkinter_dnd','Tkdnd','tkinter.dnd'),MovedModule('tkinter_colorchooser','tkColorChooser','tkinter.colorchooser'),MovedModule('tkinter_commondialog','tkCommonDialog','tkinter.commondialog'),MovedModule('tkinter_tkfiledialog','tkFileDialog',_p),MovedModule('tkinter_font','tkFont','tkinter.font'),MovedModule('tkinter_messagebox','tkMessageBox','tkinter.messagebox'),MovedModule('tkinter_tksimpledialog','tkSimpleDialog',_q),MovedModule('urllib_parse',__name__+_r,_D),MovedModule('urllib_error',__name__+'.moves.urllib_error',_L),MovedModule(_E,__name__+_V,__name__+_V),MovedModule('urllib_robotparser',_W,_s),MovedModule('xmlrpc_client','xmlrpclib','xmlrpc.client'),MovedModule('xmlrpc_server','SimpleXMLRPCServer','xmlrpc.server')]
if sys.platform=='win32':_moved_attributes+=[MovedModule('winreg','_winreg')]
for attr in _moved_attributes:
	setattr(_MovedItems,attr.name,attr)
	if isinstance(attr,MovedModule):_importer._add_module(attr,'moves.'+attr.name)
del attr
_MovedItems._moved_attributes=_moved_attributes
moves=_MovedItems(__name__+'.moves')
_importer._add_module(moves,'moves')
class Module_six_moves_urllib_parse(_LazyModule):'Lazy loading of moved objects in six.moves.urllib_parse'
_urllib_parse_moved_attributes=[MovedAttribute('ParseResult',_F,_D),MovedAttribute('SplitResult',_F,_D),MovedAttribute('parse_qs',_F,_D),MovedAttribute('parse_qsl',_F,_D),MovedAttribute('urldefrag',_F,_D),MovedAttribute('urljoin',_F,_D),MovedAttribute(_F,_F,_D),MovedAttribute('urlsplit',_F,_D),MovedAttribute('urlunparse',_F,_D),MovedAttribute('urlunsplit',_F,_D),MovedAttribute(_e,_E,_D),MovedAttribute('quote_plus',_E,_D),MovedAttribute(_t,_E,_D),MovedAttribute('unquote_plus',_E,_D),MovedAttribute(_u,_E,_D,_t,_u),MovedAttribute('urlencode',_E,_D),MovedAttribute('splitquery',_E,_D),MovedAttribute('splittag',_E,_D),MovedAttribute('splituser',_E,_D),MovedAttribute('splitvalue',_E,_D),MovedAttribute('uses_fragment',_F,_D),MovedAttribute('uses_netloc',_F,_D),MovedAttribute('uses_params',_F,_D),MovedAttribute('uses_query',_F,_D),MovedAttribute('uses_relative',_F,_D)]
for attr in _urllib_parse_moved_attributes:setattr(Module_six_moves_urllib_parse,attr.name,attr)
del attr
Module_six_moves_urllib_parse._moved_attributes=_urllib_parse_moved_attributes
_importer._add_module(Module_six_moves_urllib_parse(__name__+_r),_v,'moves.urllib.parse')
class Module_six_moves_urllib_error(_LazyModule):'Lazy loading of moved objects in six.moves.urllib_error'
_urllib_error_moved_attributes=[MovedAttribute('URLError',_C,_L),MovedAttribute('HTTPError',_C,_L),MovedAttribute('ContentTooShortError',_E,_L)]
for attr in _urllib_error_moved_attributes:setattr(Module_six_moves_urllib_error,attr.name,attr)
del attr
Module_six_moves_urllib_error._moved_attributes=_urllib_error_moved_attributes
_importer._add_module(Module_six_moves_urllib_error(__name__+'.moves.urllib.error'),_w,'moves.urllib.error')
class Module_six_moves_urllib_request(_LazyModule):'Lazy loading of moved objects in six.moves.urllib_request'
_urllib_request_moved_attributes=[MovedAttribute('urlopen',_C,_B),MovedAttribute('install_opener',_C,_B),MovedAttribute('build_opener',_C,_B),MovedAttribute('pathname2url',_E,_B),MovedAttribute('url2pathname',_E,_B),MovedAttribute('getproxies',_E,_B),MovedAttribute('Request',_C,_B),MovedAttribute('OpenerDirector',_C,_B),MovedAttribute('HTTPDefaultErrorHandler',_C,_B),MovedAttribute('HTTPRedirectHandler',_C,_B),MovedAttribute('HTTPCookieProcessor',_C,_B),MovedAttribute('ProxyHandler',_C,_B),MovedAttribute('BaseHandler',_C,_B),MovedAttribute('HTTPPasswordMgr',_C,_B),MovedAttribute('HTTPPasswordMgrWithDefaultRealm',_C,_B),MovedAttribute('AbstractBasicAuthHandler',_C,_B),MovedAttribute('HTTPBasicAuthHandler',_C,_B),MovedAttribute('ProxyBasicAuthHandler',_C,_B),MovedAttribute('AbstractDigestAuthHandler',_C,_B),MovedAttribute('HTTPDigestAuthHandler',_C,_B),MovedAttribute('ProxyDigestAuthHandler',_C,_B),MovedAttribute('HTTPHandler',_C,_B),MovedAttribute('HTTPSHandler',_C,_B),MovedAttribute('FileHandler',_C,_B),MovedAttribute('FTPHandler',_C,_B),MovedAttribute('CacheFTPHandler',_C,_B),MovedAttribute('UnknownHandler',_C,_B),MovedAttribute('HTTPErrorProcessor',_C,_B),MovedAttribute('urlretrieve',_E,_B),MovedAttribute('urlcleanup',_E,_B),MovedAttribute('URLopener',_E,_B),MovedAttribute('FancyURLopener',_E,_B),MovedAttribute('proxy_bypass',_E,_B),MovedAttribute('parse_http_list',_C,_B),MovedAttribute('parse_keqv_list',_C,_B)]
for attr in _urllib_request_moved_attributes:setattr(Module_six_moves_urllib_request,attr.name,attr)
del attr
Module_six_moves_urllib_request._moved_attributes=_urllib_request_moved_attributes
_importer._add_module(Module_six_moves_urllib_request(__name__+'.moves.urllib.request'),_x,'moves.urllib.request')
class Module_six_moves_urllib_response(_LazyModule):'Lazy loading of moved objects in six.moves.urllib_response'
_urllib_response_moved_attributes=[MovedAttribute('addbase',_E,_M),MovedAttribute('addclosehook',_E,_M),MovedAttribute('addinfo',_E,_M),MovedAttribute('addinfourl',_E,_M)]
for attr in _urllib_response_moved_attributes:setattr(Module_six_moves_urllib_response,attr.name,attr)
del attr
Module_six_moves_urllib_response._moved_attributes=_urllib_response_moved_attributes
_importer._add_module(Module_six_moves_urllib_response(__name__+'.moves.urllib.response'),_y,'moves.urllib.response')
class Module_six_moves_urllib_robotparser(_LazyModule):'Lazy loading of moved objects in six.moves.urllib_robotparser'
_urllib_robotparser_moved_attributes=[MovedAttribute('RobotFileParser',_W,_s)]
for attr in _urllib_robotparser_moved_attributes:setattr(Module_six_moves_urllib_robotparser,attr.name,attr)
del attr
Module_six_moves_urllib_robotparser._moved_attributes=_urllib_robotparser_moved_attributes
_importer._add_module(Module_six_moves_urllib_robotparser(__name__+'.moves.urllib.robotparser'),_z,'moves.urllib.robotparser')
class Module_six_moves_urllib(types.ModuleType):
	'Create a six.moves.urllib namespace that resembles the Python 3 namespace';__path__=[];parse=_importer._get_module(_v);error=_importer._get_module(_w);request=_importer._get_module(_x);response=_importer._get_module(_y);robotparser=_importer._get_module(_z)
	def __dir__(self):return['parse','error','request','response',_W]
_importer._add_module(Module_six_moves_urllib(__name__+_V),'moves.urllib')
def add_move(move):'Add an item to six.moves.';setattr(_MovedItems,move.name,move)
def remove_move(name):
	'Remove item from six.moves.'
	try:delattr(_MovedItems,name)
	except AttributeError:
		try:del moves.__dict__[name]
		except KeyError:raise AttributeError('no such move, %r'%(name,))
if PY3:_meth_func='__func__';_meth_self='__self__';_func_closure='__closure__';_func_code='__code__';_func_defaults='__defaults__';_func_globals='__globals__'
else:_meth_func='im_func';_meth_self='im_self';_func_closure='func_closure';_func_code='func_code';_func_defaults='func_defaults';_func_globals='func_globals'
try:advance_iterator=next
except NameError:
	def advance_iterator(it):return it.next()
next=advance_iterator
try:callable=callable
except NameError:
	def callable(obj):return any(('__call__'in klass.__dict__ for klass in type(obj).__mro__))
if PY3:
	def get_unbound_function(unbound):return unbound
	create_bound_method=types.MethodType
	def create_unbound_method(func,cls):return func
	Iterator=object
else:
	def get_unbound_function(unbound):return unbound.im_func
	def create_bound_method(func,obj):return types.MethodType(func,obj,obj.__class__)
	def create_unbound_method(func,cls):return types.MethodType(func,_A,cls)
	class Iterator:
		def next(self):return type(self).__next__(self)
	callable=callable
_add_doc(get_unbound_function,'Get the function out of a possibly unbound function')
get_method_function=operator.attrgetter(_meth_func)
get_method_self=operator.attrgetter(_meth_self)
get_function_closure=operator.attrgetter(_func_closure)
get_function_code=operator.attrgetter(_func_code)
get_function_defaults=operator.attrgetter(_func_defaults)
get_function_globals=operator.attrgetter(_func_globals)
if PY3:
	def iterkeys(d,**kw):return iter(d.keys(**kw))
	def itervalues(d,**kw):return iter(d.values(**kw))
	def iteritems(d,**kw):return iter(d.items(**kw))
	def iterlists(d,**kw):return iter(d.lists(**kw))
	viewkeys=operator.methodcaller('keys');viewvalues=operator.methodcaller('values');viewitems=operator.methodcaller('items')
else:
	def iterkeys(d,**kw):return d.iterkeys(**kw)
	def itervalues(d,**kw):return d.itervalues(**kw)
	def iteritems(d,**kw):return d.iteritems(**kw)
	def iterlists(d,**kw):return d.iterlists(**kw)
	viewkeys=operator.methodcaller('viewkeys');viewvalues=operator.methodcaller('viewvalues');viewitems=operator.methodcaller('viewitems')
_add_doc(iterkeys,'Return an iterator over the keys of a dictionary.')
_add_doc(itervalues,'Return an iterator over the values of a dictionary.')
_add_doc(iteritems,'Return an iterator over the (key, value) pairs of a dictionary.')
_add_doc(iterlists,'Return an iterator over the (key, [values]) pairs of a dictionary.')
if PY3:
	def b(s):return s.encode('latin-1')
	def u(s):return s
	unichr=chr;import struct;int2byte=struct.Struct('>B').pack;del struct;byte2int=operator.itemgetter(0);indexbytes=operator.getitem;iterbytes=iter;import io;StringIO=io.StringIO;BytesIO=io.BytesIO;del io;_assertCountEqual='assertCountEqual'
	if sys.version_info[1]<=1:_assertRaisesRegex=_A0;_assertRegex=_A1;_assertNotRegex=_A2
	else:_assertRaisesRegex='assertRaisesRegex';_assertRegex='assertRegex';_assertNotRegex='assertNotRegex'
else:
	def b(s):return s
	def u(s):return unicode(s.replace('\\\\','\\\\\\\\'),'unicode_escape')
	unichr=unichr;int2byte=chr
	def byte2int(bs):return ord(bs[0])
	def indexbytes(buf,i):return ord(buf[i])
	iterbytes=functools.partial(itertools.imap,ord);import StringIO;StringIO=BytesIO=StringIO.StringIO;_assertCountEqual='assertItemsEqual';_assertRaisesRegex=_A0;_assertRegex=_A1;_assertNotRegex=_A2
_add_doc(b,'Byte literal')
_add_doc(u,'Text literal')
def assertCountEqual(self,*args,**kwargs):return getattr(self,_assertCountEqual)(*args,**kwargs)
def assertRaisesRegex(self,*args,**kwargs):return getattr(self,_assertRaisesRegex)(*args,**kwargs)
def assertRegex(self,*args,**kwargs):return getattr(self,_assertRegex)(*args,**kwargs)
def assertNotRegex(self,*args,**kwargs):return getattr(self,_assertNotRegex)(*args,**kwargs)
if PY3:
	exec_=getattr(moves.builtins,'exec')
	def reraise(tp,value,tb=_A):
		try:
			if value is _A:value=tp()
			if value.__traceback__ is not tb:raise value.with_traceback(tb)
			raise value
		finally:value=_A;tb=_A
else:
	def exec_(_code_,_globs_=_A,_locs_=_A):
		'Execute code in a namespace.'
		if _globs_ is _A:
			frame=sys._getframe(1);_globs_=frame.f_globals
			if _locs_ is _A:_locs_=frame.f_locals
			del frame
		elif _locs_ is _A:_locs_=_globs_
		exec('exec _code_ in _globs_, _locs_')
	exec_('def reraise(tp, value, tb=None):\n    try:\n        raise tp, value, tb\n    finally:\n        tb = None\n')
if sys.version_info[:2]>(3,):exec_('def raise_from(value, from_value):\n    try:\n        raise value from from_value\n    finally:\n        value = None\n')
else:
	def raise_from(value,from_value):raise value
print_=getattr(moves.builtins,'print',_A)
if print_ is _A:
	def print_(*args,**kwargs):
		'The new-style print function for Python 2.4 and 2.5.';C=' ';B='\n';A=True;fp=kwargs.pop('file',sys.stdout)
		if fp is _A:return
		def write(data):
			if not isinstance(data,basestring):data=str(data)
			if isinstance(fp,file)and isinstance(data,unicode)and fp.encoding is not _A:
				errors=getattr(fp,'errors',_A)
				if errors is _A:errors=_N
				data=data.encode(fp.encoding,errors)
			fp.write(data)
		want_unicode=False;sep=kwargs.pop('sep',_A)
		if sep is not _A:
			if isinstance(sep,unicode):want_unicode=A
			elif not isinstance(sep,str):raise TypeError('sep must be None or a string')
		end=kwargs.pop('end',_A)
		if end is not _A:
			if isinstance(end,unicode):want_unicode=A
			elif not isinstance(end,str):raise TypeError('end must be None or a string')
		if kwargs:raise TypeError('invalid keyword arguments to print()')
		if not want_unicode:
			for arg in args:
				if isinstance(arg,unicode):want_unicode=A;break
		if want_unicode:newline=unicode(B);space=unicode(C)
		else:newline=B;space=C
		if sep is _A:sep=space
		if end is _A:end=newline
		for (i,arg) in enumerate(args):
			if i:write(sep)
			write(arg)
		write(end)
if sys.version_info[:2]<(3,3):
	_print=print_
	def print_(*args,**kwargs):
		fp=kwargs.get('file',sys.stdout);flush=kwargs.pop('flush',False);_print(*args,**kwargs)
		if flush and fp is not _A:fp.flush()
_add_doc(reraise,'Reraise an exception.')
if sys.version_info[0:2]<(3,4):
	def _update_wrapper(wrapper,wrapped,assigned=functools.WRAPPER_ASSIGNMENTS,updated=functools.WRAPPER_UPDATES):
		for attr in assigned:
			try:value=getattr(wrapped,attr)
			except AttributeError:continue
			else:setattr(wrapper,attr,value)
		for attr in updated:getattr(wrapper,attr).update(getattr(wrapped,attr,{}))
		wrapper.__wrapped__=wrapped;return wrapper
	_update_wrapper.__doc__=functools.update_wrapper.__doc__
	def wraps(wrapped,assigned=functools.WRAPPER_ASSIGNMENTS,updated=functools.WRAPPER_UPDATES):return functools.partial(_update_wrapper,wrapped=wrapped,assigned=assigned,updated=updated)
	wraps.__doc__=functools.wraps.__doc__
else:wraps=functools.wraps
def with_metaclass(meta,*bases):
	'Create a base class with a metaclass.'
	class metaclass(type):
		def __new__(cls,name,this_bases,d):
			if sys.version_info[:2]>=(3,7):
				resolved_bases=types.resolve_bases(bases)
				if resolved_bases is not bases:d['__orig_bases__']=bases
			else:resolved_bases=bases
			return meta(name,resolved_bases,d)
		@classmethod
		def __prepare__(cls,name,this_bases):return meta.__prepare__(name,bases)
	return type.__new__(metaclass,'temporary_class',(),{})
def add_metaclass(metaclass):
	'Class decorator for creating a class with a metaclass.'
	def wrapper(cls):
		A='__qualname__';orig_vars=cls.__dict__.copy();slots=orig_vars.get('__slots__')
		if slots is not _A:
			if isinstance(slots,str):slots=[slots]
			for slots_var in slots:orig_vars.pop(slots_var)
		orig_vars.pop('__dict__',_A);orig_vars.pop('__weakref__',_A)
		if hasattr(cls,A):orig_vars[A]=cls.__qualname__
		return metaclass(cls.__name__,cls.__bases__,orig_vars)
	return wrapper
def ensure_binary(s,encoding=_O,errors=_N):
	'Coerce **s** to six.binary_type.\n\n    For Python 2:\n      - `unicode` -> encoded to `str`\n      - `str` -> `str`\n\n    For Python 3:\n      - `str` -> encoded to `bytes`\n      - `bytes` -> `bytes`\n    '
	if isinstance(s,binary_type):return s
	if isinstance(s,text_type):return s.encode(encoding,errors)
	raise TypeError(_X%type(s))
def ensure_str(s,encoding=_O,errors=_N):
	'Coerce *s* to `str`.\n\n    For Python 2:\n      - `unicode` -> encoded to `str`\n      - `str` -> `str`\n\n    For Python 3:\n      - `str` -> `str`\n      - `bytes` -> decoded to `str`\n    '
	if type(s)is str:return s
	if PY2 and isinstance(s,text_type):return s.encode(encoding,errors)
	elif PY3 and isinstance(s,binary_type):return s.decode(encoding,errors)
	elif not isinstance(s,(text_type,binary_type)):raise TypeError(_X%type(s))
	return s
def ensure_text(s,encoding=_O,errors=_N):
	'Coerce *s* to six.text_type.\n\n    For Python 2:\n      - `unicode` -> `unicode`\n      - `str` -> `unicode`\n\n    For Python 3:\n      - `str` -> `str`\n      - `bytes` -> decoded to `str`\n    '
	if isinstance(s,binary_type):return s.decode(encoding,errors)
	elif isinstance(s,text_type):return s
	else:raise TypeError(_X%type(s))
def python_2_unicode_compatible(klass):
	'\n    A class decorator that defines __unicode__ and __str__ methods under Python 2.\n    Under Python 3 it does nothing.\n\n    To support Python 2 and 3 with a single code base, define a __str__ method\n    returning text and apply this decorator to the class.\n    '
	if PY2:
		if'__str__'not in klass.__dict__:raise ValueError("@python_2_unicode_compatible cannot be applied to %s because it doesn't define __str__()."%klass.__name__)
		klass.__unicode__=klass.__str__;klass.__str__=lambda self:self.__unicode__().encode(_O)
	return klass
__path__=[]
__package__=__name__
if globals().get('__spec__')is not _A:__spec__.submodule_search_locations=[]
if sys.meta_path:
	for (i,importer) in enumerate(sys.meta_path):
		if type(importer).__name__=='_SixMetaPathImporter'and importer.name==__name__:del sys.meta_path[i];break
	del i,importer
sys.meta_path.append(_importer)