_modes=None
class ModeDescriptor:
	def __init__(A,mode,bands,basemode,basetype):A.mode=mode;A.bands=bands;A.basemode=basemode;A.basetype=basetype
	def __str__(A):return A.mode
def getmode(mode):
	R='a';Q='Y';P='1';L='F';I='A';H='G';G='R';F='P';E='I';C='B';B='RGB';A='L';global _modes
	if not _modes:
		D={}
		for (J,(M,N,O)) in {P:(A,A,(P,)),A:(A,A,(A,)),E:(A,E,(E,)),L:(A,L,(L,)),F:(F,A,(F,)),B:(B,A,(G,H,C)),'RGBX':(B,A,(G,H,C,'X')),'RGBA':(B,A,(G,H,C,I)),'CMYK':(B,A,('C','M',Q,'K')),'YCbCr':(B,A,(Q,'Cb','Cr')),'LAB':(B,A,(A,I,C)),'HSV':(B,A,('H','S','V')),'RGBa':(B,A,(G,H,C,R)),'LA':(A,A,(A,I)),'La':(A,A,(A,R)),'PA':(B,A,(F,I))}.items():D[J]=ModeDescriptor(J,O,M,N)
		for K in ('I;16','I;16S','I;16L','I;16LS','I;16B','I;16BS','I;16N','I;16NS'):D[K]=ModeDescriptor(K,(E,),A,A)
		_modes=D
	return _modes[mode]