_B=b'\x00'
_A=None
from Crypto.Random import get_random_bytes
from Crypto.Util.py3compat import _copy_bytes
from Crypto.Util._raw_api import load_pycryptodome_raw_lib,create_string_buffer,get_raw_buffer,VoidPointer,SmartPointer,c_size_t,c_uint8_ptr,c_ulong,is_writeable_buffer
_raw_chacha20_lib=load_pycryptodome_raw_lib('Crypto.Cipher._chacha20','\n                    int chacha20_init(void **pState,\n                                      const uint8_t *key,\n                                      size_t keySize,\n                                      const uint8_t *nonce,\n                                      size_t nonceSize);\n\n                    int chacha20_destroy(void *state);\n\n                    int chacha20_encrypt(void *state,\n                                         const uint8_t in[],\n                                         uint8_t out[],\n                                         size_t len);\n\n                    int chacha20_seek(void *state,\n                                      unsigned long block_high,\n                                      unsigned long block_low,\n                                      unsigned offset);\n                    int hchacha20(  const uint8_t key[32],\n                                    const uint8_t nonce16[16],\n                                    uint8_t subkey[32]);\n                    ')
def _HChaCha20(key,nonce):
	A=nonce;assert len(key)==32;assert len(A)==16;B=bytearray(32);C=_raw_chacha20_lib.hchacha20(c_uint8_ptr(key),c_uint8_ptr(A),c_uint8_ptr(B))
	if C:raise ValueError('Error %d when deriving subkey with HChaCha20'%C)
	return B
class ChaCha20Cipher:
	block_size=1
	def __init__(A,key,nonce):
		C=key;B=nonce;A.nonce=_copy_bytes(_A,_A,B)
		if len(B)==24:C=_HChaCha20(C,B[:16]);B=_B*4+B[16:];A._name='XChaCha20'
		else:A._name='ChaCha20';B=A.nonce
		A._next=A.encrypt,A.decrypt;A._state=VoidPointer();D=_raw_chacha20_lib.chacha20_init(A._state.address_of(),c_uint8_ptr(C),c_size_t(len(C)),B,c_size_t(len(B)))
		if D:raise ValueError('Error %d instantiating a %s cipher'%(D,A._name))
		A._state=SmartPointer(A._state.get(),_raw_chacha20_lib.chacha20_destroy)
	def encrypt(A,plaintext,output=_A):
		if A.encrypt not in A._next:raise TypeError('Cipher object can only be used for decryption')
		A._next=A.encrypt,;return A._encrypt(plaintext,output)
	def _encrypt(D,plaintext,output):
		B=output;A=plaintext
		if B is _A:C=create_string_buffer(len(A))
		else:
			C=B
			if not is_writeable_buffer(B):raise TypeError('output must be a bytearray or a writeable memoryview')
			if len(A)!=len(B):raise ValueError('output must have the same length as the input  (%d bytes)'%len(A))
		E=_raw_chacha20_lib.chacha20_encrypt(D._state.get(),c_uint8_ptr(A),c_uint8_ptr(C),c_size_t(len(A)))
		if E:raise ValueError('Error %d while encrypting with %s'%(E,D._name))
		if B is _A:return get_raw_buffer(C)
		else:return _A
	def decrypt(A,ciphertext,output=_A):
		if A.decrypt not in A._next:raise TypeError('Cipher object can only be used for encryption')
		A._next=A.decrypt,
		try:return A._encrypt(ciphertext,output)
		except ValueError as B:raise ValueError(str(B).replace('enc','dec'))
	def seek(B,position):
		A=position;A,D=divmod(A,64);E=A&4294967295;F=A>>32;C=_raw_chacha20_lib.chacha20_seek(B._state.get(),c_ulong(F),c_ulong(E),D)
		if C:raise ValueError('Error %d while seeking with %s'%(C,B._name))
def _derive_Poly1305_key_pair(key,nonce):
	A=nonce
	if len(key)!=32:raise ValueError('Poly1305 with ChaCha20 requires a 32-byte key')
	if A is _A:B=A=get_random_bytes(12)
	elif len(A)==8:B=b'\x00\x00\x00\x00'+A
	elif len(A)==12:B=A
	else:raise ValueError('Poly1305 with ChaCha20 requires an 8- or 12-byte nonce')
	C=new(key=key,nonce=B).encrypt(_B*32);return C[:16],C[16:],A
def new(**A):
	try:C=A.pop('key')
	except KeyError as D:raise TypeError('Missing parameter %s'%D)
	B=A.pop('nonce',_A)
	if B is _A:B=get_random_bytes(8)
	if len(C)!=32:raise ValueError('ChaCha20/XChaCha20 key must be 32 bytes long')
	if len(B)not in(8,12,24):raise ValueError('Nonce must be 8/12 bytes(ChaCha20) or 24 bytes (XChaCha20)')
	if A:raise TypeError('Unknown parameters: '+str(A))
	return ChaCha20Cipher(C,B)
block_size=1
key_size=32