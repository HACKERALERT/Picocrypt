__all__=['new','get_random_bytes']
from os import urandom
class _UrandomRNG:
	def read(A,n):return urandom(n)
	def flush(A):0
	def reinit(A):0
	def close(A):0
def new(*A,**B):return _UrandomRNG()
def atfork():0
get_random_bytes=urandom