_Q='Java'
_P='java'
_O='32bit'
_N='MSDOS'
_M='WindowsPE'
_L='64bit'
_K='SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion'
_J='2003Server'
_I='Vista'
_H=True
_G='dos'
_F='win16'
_E='unknown'
_D='win32'
_C='.'
_B='Windows'
_A=None
__copyright__='\n    Copyright (c) 1999-2000, Marc-Andre Lemburg; mailto:mal@lemburg.com\n    Copyright (c) 2000-2010, eGenix.com Software GmbH; mailto:info@egenix.com\n\n    Permission to use, copy, modify, and distribute this software and its\n    documentation for any purpose and without fee or royalty is hereby granted,\n    provided that the above copyright notice appear in all copies and that\n    both that copyright notice and this permission notice appear in\n    supporting documentation or portions thereof, including modifications,\n    that you make.\n\n    EGENIX.COM SOFTWARE GMBH DISCLAIMS ALL WARRANTIES WITH REGARD TO\n    THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND\n    FITNESS, IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,\n    INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING\n    FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,\n    NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION\n    WITH THE USE OR PERFORMANCE OF THIS SOFTWARE !\n\n'
__version__='1.0.8'
import collections,os,re,sys
_ver_stages={'dev':10,'alpha':20,'a':20,'beta':30,'b':30,'c':40,'RC':50,'rc':50,'pl':200,'p':200}
_component_re=re.compile('([0-9]+|[._+-])')
def _comparable_version(version):
	B=[]
	for A in _component_re.split(version):
		if A not in'._+-':
			try:A=int(A,10);C=100
			except ValueError:C=_ver_stages.get(A,0)
			B.extend((C,A))
	return B
_libc_search=re.compile(b'(__libc_init)|(GLIBC_([0-9.]+))|(libc(_\\w+)?\\.so(?:\\.(\\d[0-9.]*))?)',re.ASCII)
def libc_ver(executable=_A,lib='',version='',chunksize=16384):
	T='libc';O='glibc';K=chunksize;E=executable;C=lib;A=version
	if E is _A:
		try:
			P=os.confstr('CS_GNU_LIBC_VERSION');L=P.split(maxsplit=1)
			if len(L)==2:return tuple(L)
		except (AttributeError,ValueError,OSError):pass
		E=sys.executable
	G=_comparable_version
	if hasattr(os.path,'realpath'):E=os.path.realpath(E)
	with open(E,'rb')as M:
		B=M.read(K);F=0
		while F<len(B):
			if b'libc'in B or b'GLIBC'in B:D=_libc_search.search(B,F)
			else:D=_A
			if not D or D.end()==len(B):
				N=M.read(K)
				if N:B=B[max(F,len(B)-1000):]+N;F=0;continue
				if not D:break
			Q,R,I,S,H,J=[A.decode('latin1')if A is not _A else A for A in D.groups()]
			if Q and not C:C=T
			elif R:
				if C!=O:C=O;A=I
				elif G(I)>G(A):A=I
			elif S:
				if C!=O:
					C=T
					if J and(not A or G(J)>G(A)):A=J
					if H and A[-len(H):]!=H:A=A+H
			F=D.end()
	return C,A
def _norm_version(version,build=''):
	C=build;A=version;B=A.split(_C)
	if C:B.append(C)
	try:E=map(int,B)
	except ValueError:D=B
	else:D=list(map(str,E))
	A=_C.join(D[:3]);return A
_ver_output=re.compile('(?:([\\w ]+) ([\\w.]+) .*\\[.* ([\\d.]+)\\])')
def _syscmd_ver(system='',release='',version='',supported_platforms=(_D,_F,_G)):
	C=system;B=release;A=version
	if sys.platform not in supported_platforms:return C,B,A
	import subprocess as D
	for G in ('ver','command /c ver','cmd /c ver'):
		try:E=D.check_output(G,stderr=D.DEVNULL,text=_H,shell=_H)
		except (OSError,D.CalledProcessError)as H:continue
		else:break
	else:return C,B,A
	E=E.strip();F=_ver_output.match(E)
	if F is not _A:
		C,B,A=F.groups()
		if B[-1]==_C:B=B[:-1]
		if A[-1]==_C:A=A[:-1]
		A=_norm_version(A)
	return C,B,A
_WIN32_CLIENT_RELEASES={(5,0):'2000',(5,1):'XP',(5,2):_J,(5,_A):'post2003',(6,0):_I,(6,1):'7',(6,2):'8',(6,3):'8.1',(6,_A):'post8.1',(10,0):'10',(10,_A):'post10'}
_WIN32_SERVER_RELEASES={(5,2):_J,(6,0):'2008Server',(6,1):'2008ServerR2',(6,2):'2012Server',(6,3):'2012ServerR2',(6,_A):'post2012ServerR2'}
def win32_is_iot():return win32_edition()in('IoTUAP','NanoServer','WindowsCoreHeadless','IoTEdgeOS')
def win32_edition():
	try:
		try:import winreg as A
		except ImportError:import _winreg as A
	except ImportError:pass
	else:
		try:
			B=_K
			with A.OpenKeyEx(A.HKEY_LOCAL_MACHINE,B)as C:return A.QueryValueEx(C,'EditionId')[0]
		except OSError:pass
	return _A
def win32_ver(release='',version='',csd='',ptype=''):
	G=ptype;F=version;B=csd;A=release
	try:from sys import getwindowsversion as H
	except ImportError:return A,F,B,G
	D=H();C,min,I=D.platform_version or D[:3];F='{0}.{1}.{2}'.format(C,min,I);A=_WIN32_CLIENT_RELEASES.get((C,min))or _WIN32_CLIENT_RELEASES.get((C,_A))or A
	if D[:2]==(C,min):
		try:B='SP{}'.format(D.service_pack_major)
		except AttributeError:
			if B[:13]=='Service Pack ':B='SP'+B[13:]
	if getattr(D,'product_type',_A)==3:A=_WIN32_SERVER_RELEASES.get((C,min))or _WIN32_SERVER_RELEASES.get((C,_A))or A
	try:
		try:import winreg as E
		except ImportError:import _winreg as E
	except ImportError:pass
	else:
		try:
			J=_K
			with E.OpenKeyEx(E.HKEY_LOCAL_MACHINE,J)as K:G=E.QueryValueEx(K,'CurrentType')[0]
		except OSError:pass
	return A,F,B,G
def _mac_ver_xml():
	B='/System/Library/CoreServices/SystemVersion.plist'
	if not os.path.exists(B):return _A
	try:import plistlib as C
	except ImportError:return _A
	with open(B,'rb')as D:E=C.load(D)
	F=E['ProductVersion'];G='','','';A=os.uname().machine
	if A in('ppc','Power Macintosh'):A='PowerPC'
	return F,G,A
def mac_ver(release='',versioninfo=('','',''),machine=''):
	A=_mac_ver_xml()
	if A is not _A:return A
	return release,versioninfo,machine
def _java_getprop(name,default):
	A=default;from java.lang import System as C
	try:
		B=C.getProperty(name)
		if B is _A:return A
		return B
	except AttributeError:return A
def java_ver(release='',vendor='',vminfo=('','',''),osinfo=('','','')):
	D=osinfo;C=vminfo;B=vendor;A=release
	try:import java.lang
	except ImportError:return A,B,C,D
	B=_java_getprop('java.vendor',B);A=_java_getprop('java.version',A);E,F,G=C;E=_java_getprop('java.vm.name',E);G=_java_getprop('java.vm.vendor',G);F=_java_getprop('java.vm.version',F);C=E,F,G;H,I,J=D;J=_java_getprop('java.os.arch',J);H=_java_getprop('java.os.name',H);I=_java_getprop('java.os.version',I);D=H,I,J;return A,B,C,D
def system_alias(system,release,version):
	F='Solaris';C=version;B=release;A=system
	if A=='SunOS':
		if B<'5':return A,B,C
		D=B.split(_C)
		if D:
			try:E=int(D[0])
			except ValueError:pass
			else:E=E-3;D[0]=str(E);B=_C.join(D)
		if B<'6':A=F
		else:A=F
	elif A=='IRIX64':
		A='IRIX'
		if C:C=C+' (64bit)'
		else:C=_L
	elif A in(_D,_F):A=_B
	return A,B,C
def _platform(*D):
	B='-';A=B.join((A.strip()for A in filter(len,D)));A=A.replace(' ','_');A=A.replace('/',B);A=A.replace('\\',B);A=A.replace(':',B);A=A.replace(';',B);A=A.replace('"',B);A=A.replace('(',B);A=A.replace(')',B);A=A.replace(_E,'')
	while 1:
		C=A.replace('--',B)
		if C==A:break
		A=C
	while A[-1]==B:A=A[:-1]
	return A
def _node(default=''):
	A=default
	try:import socket as B
	except ImportError:return A
	try:return B.gethostname()
	except OSError:return A
def _follow_symlinks(filepath):
	A=filepath;A=os.path.abspath(A)
	while os.path.islink(A):A=os.path.normpath(os.path.join(os.path.dirname(A),os.readlink(A)))
	return A
def _syscmd_uname(option,default=''):
	A=default
	if sys.platform in(_G,_D,_F):return A
	import subprocess as B
	try:C=B.check_output(('uname',option),stderr=B.DEVNULL,text=_H)
	except (OSError,B.CalledProcessError):return A
	return C.strip()or A
def _syscmd_file(target,default=''):
	B=default;A=target
	if sys.platform in(_G,_D,_F):return B
	import subprocess as C;A=_follow_symlinks(A);E=dict(os.environ,LC_ALL='C')
	try:D=C.check_output(['file','-b',A],stderr=C.DEVNULL,env=E)
	except (OSError,C.CalledProcessError):return B
	if not D:return B
	return D.decode('latin-1')
_default_architecture={_D:('',_M),_F:('',_B),_G:('',_N)}
def architecture(executable=sys.executable,bits='',linkage=''):
	K='COFF';J='PE';I='ELF';D=executable;C=linkage;B=bits
	if not B:import struct as G;H=G.calcsize('P');B=str(H*8)+'bit'
	if D:A=_syscmd_file(D,'')
	else:A=''
	if not A and D==sys.executable:
		if sys.platform in _default_architecture:
			E,F=_default_architecture[sys.platform]
			if E:B=E
			if F:C=F
		return B,C
	if'executable'not in A and'shared object'not in A:return B,C
	if'32-bit'in A:B=_O
	elif'N32'in A:B='n32bit'
	elif'64-bit'in A:B=_L
	if I in A:C=I
	elif J in A:
		if _B in A:C=_M
		else:C=J
	elif K in A:C=K
	elif'MS-DOS'in A:C=_N
	else:0
	return B,C
uname_result=collections.namedtuple('uname_result','system node release version machine processor')
_uname_cache=_A
def uname():
	N='Microsoft';M='PROCESSOR_ARCHITEW6432';global _uname_cache;G=0
	if _uname_cache is not _A:return _uname_cache
	D=''
	try:A,F,B,C,E=os.uname()
	except AttributeError:G=1
	if G or not list(filter(_A,(A,F,B,C,E))):
		if G:A=sys.platform;B='';C='';F=_node();E=''
		H=1
		if A==_D:
			B,C,O,P=win32_ver()
			if B and C:H=0
			if not E:
				if M in os.environ:E=os.environ.get(M,'')
				else:E=os.environ.get('PROCESSOR_ARCHITECTURE','')
			if not D:D=os.environ.get('PROCESSOR_IDENTIFIER',E)
		if H:
			A,B,C=_syscmd_ver(A)
			if A=='Microsoft Windows':A=_B
			elif A==N and B==_B:
				A=_B
				if'6.0'==C[:3]:B=_I
				else:B=''
		if A in(_D,_F):
			if not C:
				if A==_D:C=_O
				else:C='16bit'
			A=_B
		elif A[:4]==_P:
			B,I,J,Q=java_ver();A=_Q;C=', '.join(J)
			if not C:C=I
	if A=='OpenVMS':
		if not B or B=='0':B=C;C=''
		try:import vms_lib as K
		except ImportError:pass
		else:
			R,L=K.getsyi('SYI$_CPU',0)
			if L>=128:D='Alpha'
			else:D='VAX'
	if not D:D=_syscmd_uname('-p','')
	if A==_E:A=''
	if F==_E:F=''
	if B==_E:B=''
	if C==_E:C=''
	if E==_E:E=''
	if D==_E:D=''
	if A==N and B==_B:A=_B;B=_I
	_uname_cache=uname_result(A,F,B,C,E,D);return _uname_cache
def system():return uname().system
def node():return uname().node
def release():return uname().release
def version():return uname().version
def machine():return uname().machine
def processor():return uname().processor
_sys_version_parser=re.compile('([\\w.+]+)\\s*\\(#?([^,]+)(?:,\\s*([\\w ]*)(?:,\\s*([\\w :]*))?)?\\)\\s*\\[([^\\]]+)\\]?',re.ASCII)
_ironpython_sys_version_parser=re.compile('IronPython\\s*([\\d\\.]+)(?: \\(([\\d\\.]+)\\))? on (.NET [\\d\\.]+)',re.ASCII)
_ironpython26_sys_version_parser=re.compile('([\\d.]+)\\s*\\(IronPython\\s*[\\d.]+\\s*\\(([\\d.]+)\\) on ([\\w.]+ [\\d.]+(?: \\(\\d+-bit\\))?)\\)')
_pypy_sys_version_parser=re.compile('([\\w.+]+)\\s*\\(#?([^,]+),\\s*([\\w ]+),\\s*([\\w :]+)\\)\\s*\\[PyPy [^\\]]+\\]?')
_sys_version_cache={}
def _sys_version(sys_version=_A):
	O='PyPy';N='IronPython';A=sys_version
	if A is _A:A=sys.version
	E=_sys_version_cache.get(A,_A)
	if E is not _A:return E
	if N in A:
		F=N
		if A.startswith(N):B=_ironpython_sys_version_parser.match(A)
		else:B=_ironpython26_sys_version_parser.match(A)
		if B is _A:raise ValueError('failed to parse IronPython sys.version: %s'%repr(A))
		D,P,G=B.groups();H='';C=''
	elif sys.platform.startswith(_P):
		F='Jython';B=_sys_version_parser.match(A)
		if B is _A:raise ValueError('failed to parse Jython sys.version: %s'%repr(A))
		D,H,C,I,M=B.groups()
		if C is _A:C=''
		G=sys.platform
	elif O in A:
		F=O;B=_pypy_sys_version_parser.match(A)
		if B is _A:raise ValueError('failed to parse PyPy sys.version: %s'%repr(A))
		D,H,C,I=B.groups();G=''
	else:
		B=_sys_version_parser.match(A)
		if B is _A:raise ValueError('failed to parse CPython sys.version: %s'%repr(A))
		D,H,C,I,G=B.groups();F='CPython'
		if C is _A:C=''
		elif I:C=C+' '+I
	if hasattr(sys,'_git'):M,J,K=sys._git
	elif hasattr(sys,'_mercurial'):M,J,K=sys._mercurial
	else:J='';K=''
	L=D.split(_C)
	if len(L)==2:L.append('0');D=_C.join(L)
	E=F,D,J,K,H,C,G;_sys_version_cache[A]=E;return E
def python_implementation():return _sys_version()[0]
def python_version():return _sys_version()[1]
def python_version_tuple():return tuple(_sys_version()[1].split(_C))
def python_branch():return _sys_version()[2]
def python_revision():return _sys_version()[3]
def python_build():return _sys_version()[4:6]
def python_compiler():return _sys_version()[6]
_platform_cache={}
def platform(aliased=0,terse=0):
	G=aliased;E=terse;I=_platform_cache.get((G,E),_A)
	if I is not _A:return I
	A,S,B,D,H,F=uname()
	if H==F:F=''
	if G:A,B,D=system_alias(A,B,D)
	if A=='Darwin':
		J=mac_ver()[0]
		if J:A='macOS';B=J
	if A==_B:
		T,U,L,V=win32_ver(D)
		if E:C=_platform(A,B)
		else:C=_platform(A,B,D,L)
	elif A in('Linux',):M,N=libc_ver(sys.executable);C=_platform(A,B,H,F,'with',M+N)
	elif A==_Q:
		W,X,Y,(K,O,P)=java_ver()
		if E or not K:C=_platform(A,B,D)
		else:C=_platform(A,B,D,'on',K,O,P)
	elif E:C=_platform(A,B)
	else:Q,R=architecture(sys.executable);C=_platform(A,B,H,F,Q,R)
	_platform_cache[(G,E)]=C;return C
if __name__=='__main__':terse='terse'in sys.argv or'--terse'in sys.argv;aliased=not'nonaliased'in sys.argv and not'--nonaliased'in sys.argv;print(platform(aliased,terse));sys.exit(0)