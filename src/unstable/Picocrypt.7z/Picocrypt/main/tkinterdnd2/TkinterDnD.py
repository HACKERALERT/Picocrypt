_E='tkdnd::drop_target'
_D='unregister'
_C='register'
_B='tkdnd::drag_source'
_A=None
try:import Tkinter as tkinter,Tix as tix
except ImportError:import tkinter;from tkinter import tix
TkdndVersion=_A
def _require(tkroot):
	E='tkdnd';C=tkroot;global TkdndVersion
	try:
		import os.path,platform as A
		if A.system()=='Darwin':B='osx64'
		elif A.system()=='Linux':B='linux64'
		elif A.system()=='Windows':B='win64'
		else:raise RuntimeError('Plaform not supported.')
		D=os.path.join(os.path.dirname(__file__),E,B);C.tk.call('lappend','auto_path',D);TkdndVersion=C.tk.call('package','require',E)
	except tkinter.TclError:raise RuntimeError('Unable to load tkdnd library.')
	return TkdndVersion
class DnDEvent:0
class DnDWrapper:
	_subst_format_dnd='%A','%a','%b','%C','%c','{%CST}','{%CTT}','%D','%e','{%L}','{%m}','{%ST}','%T','{%t}','{%TT}','%W','%X','%Y';_subst_format_str_dnd=' '.join(_subst_format_dnd);tkinter.BaseWidget._subst_format_dnd=_subst_format_dnd;tkinter.BaseWidget._subst_format_str_dnd=_subst_format_str_dnd
	def _substitute_dnd(C,*D):
		if len(D)!=len(C._subst_format_dnd):return D
		def E(s):
			try:return int(s)
			except ValueError:return s
		def B(s):
			try:return C.tk.splitlist(s)
			except ValueError:return s
		G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,F,V,W=D;A=DnDEvent();A.action=G;A.actions=B(H);A.button=E(I);A.code=J;A.codes=B(K);A.commonsourcetypes=B(L);A.commontargettypes=B(M);A.data=N;A.name=O;A.types=B(P);A.modifiers=B(Q);A.supportedsourcetypes=B(R);A.sourcetypes=B(T);A.type=S;A.supportedtargettypes=B(U)
		try:A.widget=C.nametowidget(F)
		except KeyError:A.widget=F
		A.x_root=E(V);A.y_root=E(W);return A,
	tkinter.BaseWidget._substitute_dnd=_substitute_dnd
	def _dnd_bind(A,what,sequence,func,add,needcleanup=True):
		D=func;C=sequence;B=what
		if isinstance(D,str):A.tk.call(B+(C,D))
		elif D:E=A._register(D,A._substitute_dnd,needcleanup);F='%s%s %s'%(add and'+'or'',E,A._subst_format_str_dnd);A.tk.call(B+(C,F));return E
		elif C:return A.tk.call(B+(C,))
		else:return A.tk.splitlist(A.tk.call(B))
	tkinter.BaseWidget._dnd_bind=_dnd_bind
	def dnd_bind(A,sequence=_A,func=_A,add=_A):return A._dnd_bind(('bind',A._w),sequence,func,add)
	tkinter.BaseWidget.dnd_bind=dnd_bind
	def drag_source_register(C,button=_A,*B):
		A=button
		if A is _A:A=1
		else:
			try:A=int(A)
			except ValueError:B=(A,)+B;A=1
		C.tk.call(_B,_C,C._w,B,A)
	tkinter.BaseWidget.drag_source_register=drag_source_register
	def drag_source_unregister(A):A.tk.call(_B,_D,A._w)
	tkinter.BaseWidget.drag_source_unregister=drag_source_unregister
	def drop_target_register(A,*B):A.tk.call(_E,_C,A._w,B)
	tkinter.BaseWidget.drop_target_register=drop_target_register
	def drop_target_unregister(A):A.tk.call(_E,_D,A._w)
	tkinter.BaseWidget.drop_target_unregister=drop_target_unregister
	def platform_independent_types(A,*B):return A.tk.split(A.tk.call('tkdnd::platform_independent_types',B))
	tkinter.BaseWidget.platform_independent_types=platform_independent_types
	def platform_specific_types(A,*B):return A.tk.split(A.tk.call('tkdnd::platform_specific_types',B))
	tkinter.BaseWidget.platform_specific_types=platform_specific_types
	def get_dropfile_tempdir(A):return A.tk.call('tkdnd::GetDropFileTempDirectory')
	tkinter.BaseWidget.get_dropfile_tempdir=get_dropfile_tempdir
	def set_dropfile_tempdir(A,tempdir):A.tk.call('tkdnd::SetDropFileTempDirectory',tempdir)
	tkinter.BaseWidget.set_dropfile_tempdir=set_dropfile_tempdir
class Tk(tkinter.Tk,DnDWrapper):
	def __init__(A,*B,**C):tkinter.Tk.__init__(A,*B,**C);A.TkdndVersion=_require(A)
class TixTk(tix.Tk,DnDWrapper):
	def __init__(A,*B,**C):tix.Tk.__init__(A,*B,**C);A.TkdndVersion=_require(A)