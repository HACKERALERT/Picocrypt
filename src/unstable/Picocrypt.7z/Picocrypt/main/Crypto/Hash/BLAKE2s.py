_C='digest_bits'
_B=False
_A='digest_bytes'
from binascii import unhexlify
from Crypto.Util.py3compat import bord,tobytes
from Crypto.Random import get_random_bytes
from Crypto.Util._raw_api import load_pycryptodome_raw_lib,VoidPointer,SmartPointer,create_string_buffer,get_raw_buffer,c_size_t,c_uint8_ptr
_raw_blake2s_lib=load_pycryptodome_raw_lib('Crypto.Hash._BLAKE2s','\n                        int blake2s_init(void **state,\n                                         const uint8_t *key,\n                                         size_t key_size,\n                                         size_t digest_size);\n                        int blake2s_destroy(void *state);\n                        int blake2s_update(void *state,\n                                           const uint8_t *buf,\n                                           size_t len);\n                        int blake2s_digest(const void *state,\n                                           uint8_t digest[32]);\n                        int blake2s_copy(const void *src, void *dst);\n                        ')
class BLAKE2s_Hash:
	block_size=32
	def __init__(A,data,key,digest_bytes,update_after_digest):
		C=key;B=digest_bytes;A.digest_size=B;A._update_after_digest=update_after_digest;A._digest_done=_B
		if B in(16,20,28,32)and not C:A.oid='1.3.6.1.4.1.1722.12.2.2.'+str(B)
		D=VoidPointer();E=_raw_blake2s_lib.blake2s_init(D.address_of(),c_uint8_ptr(C),c_size_t(len(C)),c_size_t(B))
		if E:raise ValueError('Error %d while instantiating BLAKE2s'%E)
		A._state=SmartPointer(D.get(),_raw_blake2s_lib.blake2s_destroy)
		if data:A.update(data)
	def update(A,data):
		if A._digest_done and not A._update_after_digest:raise TypeError("You can only call 'digest' or 'hexdigest' on this object")
		B=_raw_blake2s_lib.blake2s_update(A._state.get(),c_uint8_ptr(data),c_size_t(len(data)))
		if B:raise ValueError('Error %d while hashing BLAKE2s data'%B)
		return A
	def digest(A):
		B=create_string_buffer(32);C=_raw_blake2s_lib.blake2s_digest(A._state.get(),B)
		if C:raise ValueError('Error %d while creating BLAKE2s digest'%C)
		A._digest_done=True;return get_raw_buffer(B)[:A.digest_size]
	def hexdigest(A):return ''.join(['%02x'%bord(B)for B in tuple(A.digest())])
	def verify(B,mac_tag):
		A=get_random_bytes(16);C=new(digest_bits=160,key=A,data=mac_tag);D=new(digest_bits=160,key=A,data=B.digest())
		if C.digest()!=D.digest():raise ValueError('MAC check failed')
	def hexverify(A,hex_mac_tag):A.verify(unhexlify(tobytes(hex_mac_tag)))
	def new(B,**A):
		if _A not in A and _C not in A:A[_A]=B.digest_size
		return new(**A)
def new(**A):
	C=None;F=A.pop('data',C);G=A.pop('update_after_digest',_B);B=A.pop(_A,C);D=A.pop(_C,C)
	if C not in(B,D):raise TypeError('Only one digest parameter must be provided')
	if(C,C)==(B,D):B=32
	if B is not C:
		if not 1<=B<=32:raise ValueError("'digest_bytes' not in range 1..32")
	else:
		if not 8<=D<=256 or D%8:raise ValueError("'digest_bytes' not in range 8..256, with steps of 8")
		B=D//8
	E=A.pop('key',b'')
	if len(E)>32:raise ValueError('BLAKE2s key cannot exceed 32 bytes')
	if A:raise TypeError('Unknown parameters: '+str(A))
	return BLAKE2s_Hash(F,E,B,G)