_A='latin-1'
import sys,abc
if sys.version_info[0]==2:
	def b(s):return s
	def bchr(s):return chr(s)
	def bstr(s):return str(s)
	def bord(s):return ord(s)
	def tobytes(s,encoding=_A):
		if isinstance(s,unicode):return s.encode(encoding)
		elif isinstance(s,str):return s
		elif isinstance(s,bytearray):return bytes(s)
		else:return ''.join(s)
	def tostr(bs):return bs
	def byte_string(s):return isinstance(s,str)
	from StringIO import StringIO as BytesIO;from sys import maxint;iter_range=xrange
	def is_native_int(x):return isinstance(x,(int,long))
	def is_string(x):return isinstance(x,basestring)
	ABC=abc.ABCMeta('ABC',(object,),{'__slots__':()});FileNotFoundError=IOError
else:
	def b(s):return s.encode(_A)
	def bchr(s):return bytes([s])
	def bstr(s):
		if isinstance(s,str):return bytes(s,_A)
		else:return bytes(s)
	def bord(s):return s
	def tobytes(s,encoding=_A):
		if isinstance(s,bytes):return s
		elif isinstance(s,bytearray):return bytes(s)
		elif isinstance(s,str):return s.encode(encoding)
		else:return bytes([s])
	def tostr(bs):return bs.decode(_A)
	def byte_string(s):return isinstance(s,bytes)
	from io import BytesIO;from sys import maxsize as maxint;iter_range=range
	def is_native_int(x):return isinstance(x,int)
	def is_string(x):return isinstance(x,str)
	from abc import ABC;FileNotFoundError=FileNotFoundError
def _copy_bytes(start,end,seq):
	C=end;B=start;A=seq
	if isinstance(A,memoryview):return A[B:C].tobytes()
	elif isinstance(A,bytearray):return bytes(A[B:C])
	else:return A[B:C]
del sys
del abc