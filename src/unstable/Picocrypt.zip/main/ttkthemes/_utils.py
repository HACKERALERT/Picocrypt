import contextlib,os
from shutil import rmtree
from tempfile import gettempdir
@contextlib.contextmanager
def temporary_chdir(new_dir):
	A=os.getcwd();os.chdir(new_dir)
	try:yield
	finally:os.chdir(A)
def get_file_directory():return os.path.dirname(os.path.realpath(__file__))
def get_temp_directory():
	A=os.path.join(gettempdir(),'ttkthemes')
	if not os.path.exists(A):os.makedirs(A)
	return A
def get_themes_directory(theme_name=None,png=False):
	B=theme_name;A=os.path.join(get_file_directory(),'themes')
	if B is None:return A
	if B in os.listdir(A):return A
	dir='png'if png is True else'gif';return os.path.join(get_file_directory(),dir)
def create_directory(directory):
	A=directory
	if os.path.exists(A):rmtree(A)
	os.makedirs(A);return A