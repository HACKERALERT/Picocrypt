_A='.'
import codecs,sys
from .  import aliases
_cache={}
_unknown='--unknown--'
_import_tail=['*']
_aliases=aliases.aliases
class CodecRegistryError(LookupError,SystemError):0
def normalize_encoding(encoding):
	E=False;A=encoding
	if isinstance(A,bytes):A=str(A,'ascii')
	B=[];C=E
	for D in A:
		if D.isalnum()or D==_A:
			if C and B:B.append('_')
			B.append(D);C=E
		else:C=True
	return ''.join(B)
def search_function(encoding):
	D=encoding;B=None;A=_cache.get(D,_unknown)
	if A is not _unknown:return A
	E=normalize_encoding(D);G=_aliases.get(E)or _aliases.get(E.replace(_A,'_'))
	if G is not B:H=[G,E]
	else:H=[E]
	for F in H:
		if not F or _A in F:continue
		try:C=__import__('encodings.'+F,fromlist=_import_tail,level=0)
		except ImportError:pass
		else:break
	else:C=B
	try:J=C.getregentry
	except AttributeError:C=B
	if C is B:_cache[D]=B;return B
	A=J()
	if not isinstance(A,codecs.CodecInfo):
		if not 4<=len(A)<=7:raise CodecRegistryError('module "%s" (%s) failed to register'%(C.__name__,C.__file__))
		if not callable(A[0])or not callable(A[1])or A[2]is not B and not callable(A[2])or A[3]is not B and not callable(A[3])or len(A)>4 and A[4]is not B and not callable(A[4])or len(A)>5 and A[5]is not B and not callable(A[5]):raise CodecRegistryError('incompatible codecs in module "%s" (%s)'%(C.__name__,C.__file__))
		if len(A)<7 or A[6]is B:A+=(B,)*(6-len(A))+(C.__name__.split(_A,1)[1],)
		A=codecs.CodecInfo(*A)
	_cache[D]=A
	try:K=C.getaliases()
	except AttributeError:pass
	else:
		for I in K:
			if I not in _aliases:_aliases[I]=F
	return A
codecs.register(search_function)
if sys.platform=='win32':
	def _alias_mbcs(encoding):
		try:
			import _winapi as A;B='cp%s'%A.GetACP()
			if encoding==B:import encodings.mbcs;return encodings.mbcs.getregentry()
		except ImportError:pass
	codecs.register(_alias_mbcs)