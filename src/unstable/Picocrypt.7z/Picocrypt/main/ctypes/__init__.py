'create and manipulate C data types in Python'
_J='comtypes.server.inprocserver'
_I='%s(%s)'
_H='unexpected keyword argument(s) %s'
_G='use_last_error'
_F='use_errno'
_E='posix'
_D='l'
_C=False
_B='nt'
_A=None
import os as _os,sys as _sys
__version__='1.1.0'
from _ctypes import Union,Structure,Array,_Pointer,CFuncPtr as _CFuncPtr,__version__ as _ctypes_version,RTLD_LOCAL,RTLD_GLOBAL,ArgumentError
from struct import calcsize as _calcsize
if __version__!=_ctypes_version:raise Exception('Version number mismatch',__version__,_ctypes_version)
if _os.name==_B:from _ctypes import FormatError
DEFAULT_MODE=RTLD_LOCAL
if _os.name==_E and _sys.platform=='darwin':
	if int(_os.uname().release.split('.')[0])<8:DEFAULT_MODE=RTLD_GLOBAL
from _ctypes import FUNCFLAG_CDECL as _FUNCFLAG_CDECL,FUNCFLAG_PYTHONAPI as _FUNCFLAG_PYTHONAPI,FUNCFLAG_USE_ERRNO as _FUNCFLAG_USE_ERRNO,FUNCFLAG_USE_LASTERROR as _FUNCFLAG_USE_LASTERROR
def create_string_buffer(init,size=_A):
	'create_string_buffer(aBytes) -> character array\n    create_string_buffer(anInteger) -> character array\n    create_string_buffer(aBytes, anInteger) -> character array\n    ';A='ctypes.create_string_buffer'
	if isinstance(init,bytes):
		if size is _A:size=len(init)+1
		_sys.audit(A,init,size);buftype=c_char*size;buf=buftype();buf.value=init;return buf
	elif isinstance(init,int):_sys.audit(A,_A,init);buftype=c_char*init;buf=buftype();return buf
	raise TypeError(init)
def c_buffer(init,size=_A):return create_string_buffer(init,size)
_c_functype_cache={}
def CFUNCTYPE(restype,*argtypes,**kw):
	'CFUNCTYPE(restype, *argtypes,\n                 use_errno=False, use_last_error=False) -> function prototype.\n\n    restype: the result type\n    argtypes: a sequence specifying the argument types\n\n    The function prototype can be called in different ways to create a\n    callable object:\n\n    prototype(integer address) -> foreign function\n    prototype(callable) -> create and return a C callable function from callable\n    prototype(integer index, method name[, paramflags]) -> foreign function calling a COM method\n    prototype((ordinal number, dll object)[, paramflags]) -> foreign function exported by ordinal\n    prototype((function name, dll object)[, paramflags]) -> foreign function exported by name\n    ';flags=_FUNCFLAG_CDECL
	if kw.pop(_F,_C):flags|=_FUNCFLAG_USE_ERRNO
	if kw.pop(_G,_C):flags|=_FUNCFLAG_USE_LASTERROR
	if kw:raise ValueError(_H%kw.keys())
	try:return _c_functype_cache[(restype,argtypes,flags)]
	except KeyError:
		class CFunctionType(_CFuncPtr):_argtypes_=argtypes;_restype_=restype;_flags_=flags
		_c_functype_cache[(restype,argtypes,flags)]=CFunctionType;return CFunctionType
if _os.name==_B:
	from _ctypes import LoadLibrary as _dlopen,FUNCFLAG_STDCALL as _FUNCFLAG_STDCALL;_win_functype_cache={}
	def WINFUNCTYPE(restype,*argtypes,**kw):
		flags=_FUNCFLAG_STDCALL
		if kw.pop(_F,_C):flags|=_FUNCFLAG_USE_ERRNO
		if kw.pop(_G,_C):flags|=_FUNCFLAG_USE_LASTERROR
		if kw:raise ValueError(_H%kw.keys())
		try:return _win_functype_cache[(restype,argtypes,flags)]
		except KeyError:
			class WinFunctionType(_CFuncPtr):_argtypes_=argtypes;_restype_=restype;_flags_=flags
			_win_functype_cache[(restype,argtypes,flags)]=WinFunctionType;return WinFunctionType
	if WINFUNCTYPE.__doc__:WINFUNCTYPE.__doc__=CFUNCTYPE.__doc__.replace('CFUNCTYPE','WINFUNCTYPE')
elif _os.name==_E:from _ctypes import dlopen as _dlopen
from _ctypes import sizeof,byref,addressof,alignment,resize,get_errno,set_errno,_SimpleCData
def _check_size(typ,typecode=_A):
	from struct import calcsize
	if typecode is _A:typecode=typ._type_
	actual,required=sizeof(typ),calcsize(typecode)
	if actual!=required:raise SystemError('sizeof(%s) wrong: %d instead of %d'%(typ,actual,required))
class py_object(_SimpleCData):
	_type_='O'
	def __repr__(self):
		try:return super().__repr__()
		except ValueError:return'%s(<NULL>)'%type(self).__name__
_check_size(py_object,'P')
class c_short(_SimpleCData):_type_='h'
_check_size(c_short)
class c_ushort(_SimpleCData):_type_='H'
_check_size(c_ushort)
class c_long(_SimpleCData):_type_=_D
_check_size(c_long)
class c_ulong(_SimpleCData):_type_='L'
_check_size(c_ulong)
if _calcsize('i')==_calcsize(_D):c_int=c_long;c_uint=c_ulong
else:
	class c_int(_SimpleCData):_type_='i'
	_check_size(c_int)
	class c_uint(_SimpleCData):_type_='I'
	_check_size(c_uint)
class c_float(_SimpleCData):_type_='f'
_check_size(c_float)
class c_double(_SimpleCData):_type_='d'
_check_size(c_double)
class c_longdouble(_SimpleCData):_type_='g'
if sizeof(c_longdouble)==sizeof(c_double):c_longdouble=c_double
if _calcsize(_D)==_calcsize('q'):c_longlong=c_long;c_ulonglong=c_ulong
else:
	class c_longlong(_SimpleCData):_type_='q'
	_check_size(c_longlong)
	class c_ulonglong(_SimpleCData):_type_='Q'
	_check_size(c_ulonglong)
class c_ubyte(_SimpleCData):_type_='B'
c_ubyte.__ctype_le__=c_ubyte.__ctype_be__=c_ubyte
_check_size(c_ubyte)
class c_byte(_SimpleCData):_type_='b'
c_byte.__ctype_le__=c_byte.__ctype_be__=c_byte
_check_size(c_byte)
class c_char(_SimpleCData):_type_='c'
c_char.__ctype_le__=c_char.__ctype_be__=c_char
_check_size(c_char)
class c_char_p(_SimpleCData):
	_type_='z'
	def __repr__(self):return _I%(self.__class__.__name__,c_void_p.from_buffer(self).value)
_check_size(c_char_p,'P')
class c_void_p(_SimpleCData):_type_='P'
c_voidp=c_void_p
_check_size(c_void_p)
class c_bool(_SimpleCData):_type_='?'
from _ctypes import POINTER,pointer,_pointer_type_cache
class c_wchar_p(_SimpleCData):
	_type_='Z'
	def __repr__(self):return _I%(self.__class__.__name__,c_void_p.from_buffer(self).value)
class c_wchar(_SimpleCData):_type_='u'
def _reset_cache():
	_pointer_type_cache.clear();_c_functype_cache.clear()
	if _os.name==_B:_win_functype_cache.clear()
	POINTER(c_wchar).from_param=c_wchar_p.from_param;POINTER(c_char).from_param=c_char_p.from_param;_pointer_type_cache[_A]=c_void_p
def create_unicode_buffer(init,size=_A):
	'create_unicode_buffer(aString) -> character array\n    create_unicode_buffer(anInteger) -> character array\n    create_unicode_buffer(aString, anInteger) -> character array\n    ';A='ctypes.create_unicode_buffer'
	if isinstance(init,str):
		if size is _A:
			if sizeof(c_wchar)==2:size=sum((2 if ord(c)>65535 else 1 for c in init))+1
			else:size=len(init)+1
		_sys.audit(A,init,size);buftype=c_wchar*size;buf=buftype();buf.value=init;return buf
	elif isinstance(init,int):_sys.audit(A,_A,init);buftype=c_wchar*init;buf=buftype();return buf
	raise TypeError(init)
def SetPointerType(pointer,cls):
	if _pointer_type_cache.get(cls,_A)is not _A:raise RuntimeError('This type already exists in the cache')
	if id(pointer)not in _pointer_type_cache:raise RuntimeError("What's this???")
	pointer.set_type(cls);_pointer_type_cache[cls]=pointer;del _pointer_type_cache[id(pointer)]
def ARRAY(typ,len):return typ*len
class CDLL:
	"An instance of this class represents a loaded dll/shared\n    library, exporting functions using the standard C calling\n    convention (named 'cdecl' on Windows).\n\n    The exported functions can be accessed as attributes, or by\n    indexing with the function name.  Examples:\n\n    <obj>.qsort -> callable object\n    <obj>['qsort'] -> callable object\n\n    Calling the functions releases the Python GIL during the call and\n    reacquires it afterwards.\n    ";_func_flags_=_FUNCFLAG_CDECL;_func_restype_=c_int;_name='<uninitialized>';_handle=0;_FuncPtr=_A
	def __init__(self,name,mode=DEFAULT_MODE,handle=_A,use_errno=_C,use_last_error=_C,winmode=_A):
		self._name=name;flags=self._func_flags_
		if use_errno:flags|=_FUNCFLAG_USE_ERRNO
		if use_last_error:flags|=_FUNCFLAG_USE_LASTERROR
		if _sys.platform.startswith('aix'):
			'When the name contains ".a(" and ends with ")",\n               e.g., "libFOO.a(libFOO.so)" - this is taken to be an\n               archive(member) syntax for dlopen(), and the mode is adjusted.\n               Otherwise, name is presented to dlopen() as a file argument.\n            '
			if name and name.endswith(')')and'.a('in name:mode|=_os.RTLD_MEMBER|_os.RTLD_NOW
		if _os.name==_B:
			if winmode is not _A:mode=winmode
			else:
				import nt;mode=nt._LOAD_LIBRARY_SEARCH_DEFAULT_DIRS
				if'/'in name or'\\'in name:self._name=nt._getfullpathname(self._name);mode|=nt._LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR
		class _FuncPtr(_CFuncPtr):_flags_=flags;_restype_=self._func_restype_
		self._FuncPtr=_FuncPtr
		if handle is _A:self._handle=_dlopen(self._name,mode)
		else:self._handle=handle
	def __repr__(self):return"<%s '%s', handle %x at %#x>"%(self.__class__.__name__,self._name,self._handle&_sys.maxsize*2+1,id(self)&_sys.maxsize*2+1)
	def __getattr__(self,name):
		A='__'
		if name.startswith(A)and name.endswith(A):raise AttributeError(name)
		func=self.__getitem__(name);setattr(self,name,func);return func
	def __getitem__(self,name_or_ordinal):
		func=self._FuncPtr((name_or_ordinal,self))
		if not isinstance(name_or_ordinal,int):func.__name__=name_or_ordinal
		return func
class PyDLL(CDLL):'This class represents the Python library itself.  It allows\n    accessing Python API functions.  The GIL is not released, and\n    Python exceptions are handled correctly.\n    ';_func_flags_=_FUNCFLAG_CDECL|_FUNCFLAG_PYTHONAPI
if _os.name==_B:
	class WinDLL(CDLL):'This class represents a dll exporting functions using the\n        Windows stdcall calling convention.\n        ';_func_flags_=_FUNCFLAG_STDCALL
	from _ctypes import _check_HRESULT,_SimpleCData
	class HRESULT(_SimpleCData):_type_=_D;_check_retval_=_check_HRESULT
	class OleDLL(CDLL):'This class represents a dll exporting functions using the\n        Windows stdcall calling convention, and returning HRESULT.\n        HRESULT error values are automatically raised as OSError\n        exceptions.\n        ';_func_flags_=_FUNCFLAG_STDCALL;_func_restype_=HRESULT
class LibraryLoader:
	def __init__(self,dlltype):self._dlltype=dlltype
	def __getattr__(self,name):
		if name[0]=='_':raise AttributeError(name)
		dll=self._dlltype(name);setattr(self,name,dll);return dll
	def __getitem__(self,name):return getattr(self,name)
	def LoadLibrary(self,name):return self._dlltype(name)
cdll=LibraryLoader(CDLL)
pydll=LibraryLoader(PyDLL)
if _os.name==_B:pythonapi=PyDLL('python dll',_A,_sys.dllhandle)
elif _sys.platform=='cygwin':pythonapi=PyDLL('libpython%d.%d.dll'%_sys.version_info[:2])
else:pythonapi=PyDLL(_A)
if _os.name==_B:
	windll=LibraryLoader(WinDLL);oledll=LibraryLoader(OleDLL);GetLastError=windll.kernel32.GetLastError;from _ctypes import get_last_error,set_last_error
	def WinError(code=_A,descr=_A):
		if code is _A:code=GetLastError()
		if descr is _A:descr=FormatError(code).strip()
		return OSError(_A,descr,_A,code)
if sizeof(c_uint)==sizeof(c_void_p):c_size_t=c_uint;c_ssize_t=c_int
elif sizeof(c_ulong)==sizeof(c_void_p):c_size_t=c_ulong;c_ssize_t=c_long
elif sizeof(c_ulonglong)==sizeof(c_void_p):c_size_t=c_ulonglong;c_ssize_t=c_longlong
from _ctypes import _memmove_addr,_memset_addr,_string_at_addr,_cast_addr
memmove=CFUNCTYPE(c_void_p,c_void_p,c_void_p,c_size_t)(_memmove_addr)
memset=CFUNCTYPE(c_void_p,c_void_p,c_int,c_size_t)(_memset_addr)
def PYFUNCTYPE(restype,*argtypes):
	class CFunctionType(_CFuncPtr):_argtypes_=argtypes;_restype_=restype;_flags_=_FUNCFLAG_CDECL|_FUNCFLAG_PYTHONAPI
	return CFunctionType
_cast=PYFUNCTYPE(py_object,c_void_p,py_object,py_object)(_cast_addr)
def cast(obj,typ):return _cast(obj,obj,typ)
_string_at=PYFUNCTYPE(py_object,c_void_p,c_int)(_string_at_addr)
def string_at(ptr,size=-1):'string_at(addr[, size]) -> string\n\n    Return the string at addr.';return _string_at(ptr,size)
try:from _ctypes import _wstring_at_addr
except ImportError:pass
else:
	_wstring_at=PYFUNCTYPE(py_object,c_void_p,c_int)(_wstring_at_addr)
	def wstring_at(ptr,size=-1):'wstring_at(addr[, size]) -> string\n\n        Return the string at addr.';return _wstring_at(ptr,size)
if _os.name==_B:
	def DllGetClassObject(rclsid,riid,ppv):
		try:ccom=__import__(_J,globals(),locals(),['*'])
		except ImportError:return-2147221231
		else:return ccom.DllGetClassObject(rclsid,riid,ppv)
	def DllCanUnloadNow():
		try:ccom=__import__(_J,globals(),locals(),['*'])
		except ImportError:return 0
		return ccom.DllCanUnloadNow()
from ctypes._endian import BigEndianStructure,LittleEndianStructure
c_int8=c_byte
c_uint8=c_ubyte
for kind in [c_short,c_int,c_long,c_longlong]:
	if sizeof(kind)==2:c_int16=kind
	elif sizeof(kind)==4:c_int32=kind
	elif sizeof(kind)==8:c_int64=kind
for kind in [c_ushort,c_uint,c_ulong,c_ulonglong]:
	if sizeof(kind)==2:c_uint16=kind
	elif sizeof(kind)==4:c_uint32=kind
	elif sizeof(kind)==8:c_uint64=kind
del kind
_reset_cache()