_A=None
from ._widget import ThemedWidget
import tkinter as tk
from tkinter import ttk
class ThemedStyle(ttk.Style,ThemedWidget):
	def __init__(A,*D,**B):
		C=B.pop('theme',_A);E=B.pop('gif_override',False);ttk.Style.__init__(A,*D,**B);ThemedWidget.__init__(A,A.tk,E)
		if C is not _A and C in A.get_themes():A.set_theme(C)
	def theme_use(A,theme_name=_A):
		B=theme_name
		if B is not _A:A.set_theme(B)
		return ttk.Style.theme_use(A)
	def theme_names(A):return A.get_themes()