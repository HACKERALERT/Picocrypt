_I=b'\x00'
_H=b'-_'
_G=True
_F=b'z'
_E='big'
_D=b'+/'
_C=b''
_B=False
_A=None
import re,struct,binascii
__all__=['encode','decode','encodebytes','decodebytes','b64encode','b64decode','b32encode','b32decode','b16encode','b16decode','b85encode','b85decode','a85encode','a85decode','standard_b64encode','standard_b64decode','urlsafe_b64encode','urlsafe_b64decode']
bytes_types=bytes,bytearray
def _bytes_from_decode_data(s):
	if isinstance(s,str):
		try:return s.encode('ascii')
		except UnicodeEncodeError:raise ValueError('string argument should contain only ASCII characters')
	if isinstance(s,bytes_types):return s
	try:return memoryview(s).tobytes()
	except TypeError:raise TypeError('argument should be a bytes-like object or ASCII string, not %r'%s.__class__.__name__) from _A
def b64encode(s,altchars=_A):
	A=altchars;B=binascii.b2a_base64(s,newline=_B)
	if A is not _A:assert len(A)==2,repr(A);return B.translate(bytes.maketrans(_D,A))
	return B
def b64decode(s,altchars=_A,validate=_B):
	A=altchars;s=_bytes_from_decode_data(s)
	if A is not _A:A=_bytes_from_decode_data(A);assert len(A)==2,repr(A);s=s.translate(bytes.maketrans(A,_D))
	if validate and not re.fullmatch(b'[A-Za-z0-9+/]*={0,2}',s):raise binascii.Error('Non-base64 digit found')
	return binascii.a2b_base64(s)
def standard_b64encode(s):return b64encode(s)
def standard_b64decode(s):return b64decode(s)
_urlsafe_encode_translation=bytes.maketrans(_D,_H)
_urlsafe_decode_translation=bytes.maketrans(_H,_D)
def urlsafe_b64encode(s):return b64encode(s).translate(_urlsafe_encode_translation)
def urlsafe_b64decode(s):s=_bytes_from_decode_data(s);s=s.translate(_urlsafe_decode_translation);return b64decode(s)
_b32alphabet=b'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'
_b32tab2=_A
_b32rev=_A
def b32encode(s):
	global _b32tab2
	if _b32tab2 is _A:E=[bytes((A,))for A in _b32alphabet];_b32tab2=[A+B for A in E for B in E];E=_A
	if not isinstance(s,bytes_types):s=memoryview(s).tobytes()
	A=len(s)%5
	if A:s=s+_I*(5-A)
	B=bytearray();G=int.from_bytes;C=_b32tab2
	for F in range(0,len(s),5):D=G(s[F:F+5],_E);B+=C[D>>30]+C[D>>20&1023]+C[D>>10&1023]+C[D&1023]
	if A==1:B[-6:]=b'======'
	elif A==2:B[-4:]=b'===='
	elif A==3:B[-3:]=b'==='
	elif A==4:B[-1:]=b'='
	return bytes(B)
def b32decode(s,casefold=_B,map01=_A):
	L='Incorrect padding';A=map01;global _b32rev
	if _b32rev is _A:_b32rev={B:A for(A,B)in enumerate(_b32alphabet)}
	s=_bytes_from_decode_data(s)
	if len(s)%8:raise binascii.Error(L)
	if A is not _A:A=_bytes_from_decode_data(A);assert len(A)==1,repr(A);s=s.translate(bytes.maketrans(b'01',b'O'+A))
	if casefold:s=s.upper()
	E=len(s);s=s.rstrip(b'=');C=E-len(s);D=bytearray();G=_b32rev
	for F in range(0,len(s),8):
		H=s[F:F+8];B=0
		try:
			for I in H:B=(B<<5)+G[I]
		except KeyError:raise binascii.Error('Non-base32 digit found') from _A
		D+=B.to_bytes(5,_E)
	if E%8 or C not in{0,1,3,4,6}:raise binascii.Error(L)
	if C and D:B<<=5*C;J=B.to_bytes(5,_E);K=(43-5*C)//8;D[-5:]=J[:K]
	return bytes(D)
def b16encode(s):return binascii.hexlify(s).upper()
def b16decode(s,casefold=_B):
	s=_bytes_from_decode_data(s)
	if casefold:s=s.upper()
	if re.search(b'[^0-9A-F]',s):raise binascii.Error('Non-base16 digit found')
	return binascii.unhexlify(s)
_a85chars=_A
_a85chars2=_A
_A85START=b'<~'
_A85END=b'~>'
def _85encode(b,chars,chars2,pad=_B,foldnuls=_B,foldspaces=_B):
	D=chars2;C=chars
	if not isinstance(b,bytes_types):b=memoryview(b).tobytes()
	B=-len(b)%4
	if B:b=b+_I*B
	E=struct.Struct('!%dI'%(len(b)//4)).unpack(b);A=[_F if foldnuls and not A else b'y'if foldspaces and A==538976288 else D[A//614125]+D[A//85%7225]+C[A%85]for A in E]
	if B and not pad:
		if A[-1]==_F:A[-1]=C[0]*5
		A[-1]=A[-1][:-B]
	return _C.join(A)
def a85encode(b,*,foldspaces=_B,wrapcol=0,pad=_B,adobe=_B):
	C=adobe;B=wrapcol;global _a85chars,_a85chars2
	if _a85chars2 is _A:_a85chars=[bytes((A,))for A in range(33,118)];_a85chars2=[A+B for A in _a85chars for B in _a85chars]
	A=_85encode(b,_a85chars,_a85chars2,pad,_G,foldspaces)
	if C:A=_A85START+A
	if B:
		B=max(2 if C else 1,B);D=[A[C:C+B]for C in range(0,len(A),B)]
		if C:
			if len(D[-1])+2>B:D.append(_C)
		A=b'\n'.join(D)
	if C:A+=_A85END
	return A
def a85decode(b,*,foldspaces=_B,adobe=_B,ignorechars=b' \t\n\r\x0b'):
	K=b'u';b=_bytes_from_decode_data(b)
	if adobe:
		if not b.endswith(_A85END):raise ValueError('Ascii85 encoded byte sequences must end with {!r}'.format(_A85END))
		if b.startswith(_A85START):b=b[2:-2]
		else:b=b[:-2]
	H=struct.Struct('!I').pack;F=[];C=F.append;B=[];I=B.append;J=B.clear
	for A in b+K*4:
		if b'!'[0]<=A<=K[0]:
			I(A)
			if len(B)==5:
				D=0
				for A in B:D=85*D+(A-33)
				try:C(H(D))
				except struct.error:raise ValueError('Ascii85 overflow') from _A
				J()
		elif A==_F[0]:
			if B:raise ValueError('z inside Ascii85 5-tuple')
			C(b'\x00\x00\x00\x00')
		elif foldspaces and A==b'y'[0]:
			if B:raise ValueError('y inside Ascii85 5-tuple')
			C(b'    ')
		elif A in ignorechars:continue
		else:raise ValueError('Non-Ascii85 digit found: %c'%A)
	E=_C.join(F);G=4-len(B)
	if G:E=E[:-G]
	return E
_b85alphabet=b'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~'
_b85chars=_A
_b85chars2=_A
_b85dec=_A
def b85encode(b,pad=_B):
	global _b85chars,_b85chars2
	if _b85chars2 is _A:_b85chars=[bytes((A,))for A in _b85alphabet];_b85chars2=[A+B for A in _b85chars for B in _b85chars]
	return _85encode(b,_b85chars,_b85chars2,pad)
def b85decode(b):
	global _b85dec
	if _b85dec is _A:
		_b85dec=[_A]*256
		for (A,B) in enumerate(_b85alphabet):_b85dec[B]=A
	b=_bytes_from_decode_data(b);C=-len(b)%5;b=b+b'~'*C;F=[];H=struct.Struct('!I').pack
	for A in range(0,len(b),5):
		G=b[A:A+5];D=0
		try:
			for B in G:D=D*85+_b85dec[B]
		except TypeError:
			for (I,B) in enumerate(G):
				if _b85dec[B]is _A:raise ValueError('bad base85 character at position %d'%(A+I)) from _A
			raise
		try:F.append(H(D))
		except struct.error:raise ValueError('base85 overflow in hunk starting at byte %d'%A) from _A
	E=_C.join(F)
	if C:E=E[:-C]
	return E
MAXLINESIZE=76
MAXBINSIZE=MAXLINESIZE//4*3
def encode(input,output):
	while _G:
		A=input.read(MAXBINSIZE)
		if not A:break
		while len(A)<MAXBINSIZE:
			B=input.read(MAXBINSIZE-len(A))
			if not B:break
			A+=B
		C=binascii.b2a_base64(A);output.write(C)
def decode(input,output):
	while _G:
		A=input.readline()
		if not A:break
		B=binascii.a2b_base64(A);output.write(B)
def _input_type_check(s):
	try:B=memoryview(s)
	except TypeError as C:A='expected bytes-like object, not %s'%s.__class__.__name__;raise TypeError(A) from C
	if B.format not in('c','b','B'):A='expected single byte elements, not %r from %s'%(B.format,s.__class__.__name__);raise TypeError(A)
	if B.ndim!=1:A='expected 1-D data, not %d-D data from %s'%(B.ndim,s.__class__.__name__);raise TypeError(A)
def encodebytes(s):
	_input_type_check(s);A=[]
	for B in range(0,len(s),MAXBINSIZE):C=s[B:B+MAXBINSIZE];A.append(binascii.b2a_base64(C))
	return _C.join(A)
def encodestring(s):import warnings as A;A.warn('encodestring() is a deprecated alias since 3.1, use encodebytes()',DeprecationWarning,2);return encodebytes(s)
def decodebytes(s):_input_type_check(s);return binascii.a2b_base64(s)
def decodestring(s):import warnings as A;A.warn('decodestring() is a deprecated alias since Python 3.1, use decodebytes()',DeprecationWarning,2);return decodebytes(s)
def main():
	import sys as A,getopt as E
	try:F,D=E.getopt(A.argv[1:],'deut')
	except E.error as G:A.stdout=A.stderr;print(G);print("usage: %s [-d|-e|-u|-t] [file|-]\n        -d, -u: decode\n        -e: encode (default)\n        -t: encode and decode string 'Aladdin:open sesame'"%A.argv[0]);A.exit(2)
	B=encode
	for (C,I) in F:
		if C=='-e':B=encode
		if C=='-d':B=decode
		if C=='-u':B=decode
		if C=='-t':test();return
	if D and D[0]!='-':
		with open(D[0],'rb')as H:B(H,A.stdout.buffer)
	else:B(A.stdin.buffer,A.stdout.buffer)
def test():A=b'Aladdin:open sesame';print(repr(A));B=encodebytes(A);print(repr(B));C=decodebytes(B);print(repr(C));assert A==C
if __name__=='__main__':main()