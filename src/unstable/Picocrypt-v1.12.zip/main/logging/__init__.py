_U="The 'warn' method is deprecated, use 'warning' instead"
_T='logger not derived from logging.Logger: '
_S='Style must be one of: %s'
_R='${asctime}'
_Q='invalid format: no fields'
_P='WARN'
_O='FATAL'
_N='(unknown function)'
_M='(unknown file)'
_L='<%s %s (%s)>'
_K='WARNING'
_J='NOTSET'
_I='INFO'
_H='ERROR'
_G='DEBUG'
_F='CRITICAL'
_E='.'
_D='\n'
_C=False
_B=True
_A=None
import sys,os,time,io,re,traceback,warnings,weakref,collections.abc
from string import Template,Formatter as StrFormatter
__all__=['BASIC_FORMAT','BufferingFormatter',_F,_G,_H,_O,'FileHandler','Filter','Formatter','Handler',_I,'LogRecord','Logger','LoggerAdapter',_J,'NullHandler','StreamHandler',_P,_K,'addLevelName','basicConfig','captureWarnings','critical','debug','disable','error','exception','fatal','getLevelName','getLogger','getLoggerClass','info','log','makeLogRecord','setLoggerClass','shutdown','warn','warning','getLogRecordFactory','setLogRecordFactory','lastResort','raiseExceptions']
import threading
__author__='Vinay Sajip <vinay_sajip@red-dove.com>'
__status__='production'
__version__='0.5.1.2'
__date__='07 February 2010'
_startTime=time.time()
raiseExceptions=_B
logThreads=_B
logMultiprocessing=_B
logProcesses=_B
CRITICAL=50
FATAL=CRITICAL
ERROR=40
WARNING=30
WARN=WARNING
INFO=20
DEBUG=10
NOTSET=0
_levelToName={CRITICAL:_F,ERROR:_H,WARNING:_K,INFO:_I,DEBUG:_G,NOTSET:_J}
_nameToLevel={_F:CRITICAL,_O:FATAL,_H:ERROR,_P:WARNING,_K:WARNING,_I:INFO,_G:DEBUG,_J:NOTSET}
def getLevelName(level):
	B=level;A=_levelToName.get(B)
	if A is not _A:return A
	A=_nameToLevel.get(B)
	if A is not _A:return A
	return'Level %s'%B
def addLevelName(level,levelName):
	B=levelName;A=level;_acquireLock()
	try:_levelToName[A]=B;_nameToLevel[B]=A
	finally:_releaseLock()
if hasattr(sys,'_getframe'):currentframe=lambda:sys._getframe(3)
else:
	def currentframe():
		try:raise Exception
		except Exception:return sys.exc_info()[2].tb_frame.f_back
_srcfile=os.path.normcase(addLevelName.__code__.co_filename)
def _checkLevel(level):
	A=level
	if isinstance(A,int):B=A
	elif str(A)==A:
		if A not in _nameToLevel:raise ValueError('Unknown level: %r'%A)
		B=_nameToLevel[A]
	else:raise TypeError('Level not an integer or a valid string: %r'%A)
	return B
_lock=threading.RLock()
def _acquireLock():
	if _lock:_lock.acquire()
def _releaseLock():
	if _lock:_lock.release()
if not hasattr(os,'register_at_fork'):
	def _register_at_fork_reinit_lock(instance):0
else:
	_at_fork_reinit_lock_weakset=weakref.WeakSet()
	def _register_at_fork_reinit_lock(instance):
		_acquireLock()
		try:_at_fork_reinit_lock_weakset.add(instance)
		finally:_releaseLock()
	def _after_at_fork_child_reinit_locks():
		for A in _at_fork_reinit_lock_weakset:
			try:A.createLock()
			except Exception as B:print('Ignoring exception from logging atfork',instance,'._reinit_lock() method:',B,file=sys.stderr)
		_releaseLock()
	os.register_at_fork(before=_acquireLock,after_in_child=_after_at_fork_child_reinit_locks,after_in_parent=_releaseLock)
class LogRecord:
	def __init__(A,name,level,pathname,lineno,msg,args,exc_info,func=_A,sinfo=_A,**G):
		E=level;C=pathname;B=args;D=time.time();A.name=name;A.msg=msg
		if B and len(B)==1 and isinstance(B[0],collections.abc.Mapping)and B[0]:B=B[0]
		A.args=B;A.levelname=getLevelName(E);A.levelno=E;A.pathname=C
		try:A.filename=os.path.basename(C);A.module=os.path.splitext(A.filename)[0]
		except (TypeError,ValueError,AttributeError):A.filename=C;A.module='Unknown module'
		A.exc_info=exc_info;A.exc_text=_A;A.stack_info=sinfo;A.lineno=lineno;A.funcName=func;A.created=D;A.msecs=(D-int(D))*1000;A.relativeCreated=(A.created-_startTime)*1000
		if logThreads:A.thread=threading.get_ident();A.threadName=threading.current_thread().name
		else:A.thread=_A;A.threadName=_A
		if not logMultiprocessing:A.processName=_A
		else:
			A.processName='MainProcess';F=sys.modules.get('multiprocessing')
			if F is not _A:
				try:A.processName=F.current_process().name
				except Exception:pass
		if logProcesses and hasattr(os,'getpid'):A.process=os.getpid()
		else:A.process=_A
	def __repr__(A):return'<LogRecord: %s, %s, %s, %s, "%s">'%(A.name,A.levelno,A.pathname,A.lineno,A.msg)
	def getMessage(A):
		B=str(A.msg)
		if A.args:B=B%A.args
		return B
_logRecordFactory=LogRecord
def setLogRecordFactory(factory):global _logRecordFactory;_logRecordFactory=factory
def getLogRecordFactory():return _logRecordFactory
def makeLogRecord(dict):A=_logRecordFactory(_A,_A,'',0,'',(),_A,_A);A.__dict__.update(dict);return A
_str_formatter=StrFormatter()
del StrFormatter
class PercentStyle:
	default_format='%(message)s';asctime_format='%(asctime)s';asctime_search='%(asctime)';validation_pattern=re.compile('%\\(\\w+\\)[#0+ -]*(\\*|\\d+)?(\\.(\\*|\\d+))?[diouxefgcrsa%]',re.I)
	def __init__(A,fmt):A._fmt=fmt or A.default_format
	def usesTime(A):return A._fmt.find(A.asctime_search)>=0
	def validate(A):
		if not A.validation_pattern.search(A._fmt):raise ValueError("Invalid format '%s' for '%s' style"%(A._fmt,A.default_format[0]))
	def _format(A,record):return A._fmt%record.__dict__
	def format(A,record):
		try:return A._format(record)
		except KeyError as B:raise ValueError('Formatting field not found in record: %s'%B)
class StrFormatStyle(PercentStyle):
	default_format='{message}';asctime_format='{asctime}';asctime_search='{asctime';fmt_spec=re.compile('^(.?[<>=^])?[+ -]?#?0?(\\d+|{\\w+})?[,_]?(\\.(\\d+|{\\w+}))?[bcdefgnosx%]?$',re.I);field_spec=re.compile('^(\\d+|\\w+)(\\.\\w+|\\[[^]]+\\])*$')
	def _format(A,record):return A._fmt.format(**record.__dict__)
	def validate(B):
		E=set()
		try:
			for (_,A,C,D) in _str_formatter.parse(B._fmt):
				if A:
					if not B.field_spec.match(A):raise ValueError('invalid field name/expression: %r'%A)
					E.add(A)
				if D and D not in'rsa':raise ValueError('invalid conversion: %r'%D)
				if C and not B.fmt_spec.match(C):raise ValueError('bad specifier: %r'%C)
		except ValueError as F:raise ValueError('invalid format: %s'%F)
		if not E:raise ValueError(_Q)
class StringTemplateStyle(PercentStyle):
	default_format='${message}';asctime_format=_R;asctime_search=_R
	def __init__(A,fmt):A._fmt=fmt or A.default_format;A._tpl=Template(A._fmt)
	def usesTime(A):B=A._fmt;return B.find('$asctime')>=0 or B.find(A.asctime_format)>=0
	def validate(D):
		G='braced';F='named';E=Template.pattern;B=set()
		for C in E.finditer(D._fmt):
			A=C.groupdict()
			if A[F]:B.add(A[F])
			elif A[G]:B.add(A[G])
			elif C.group(0)=='$':raise ValueError("invalid format: bare '$' not allowed")
		if not B:raise ValueError(_Q)
	def _format(A,record):return A._tpl.substitute(**record.__dict__)
BASIC_FORMAT='%(levelname)s:%(name)s:%(message)s'
_STYLES={'%':(PercentStyle,BASIC_FORMAT),'{':(StrFormatStyle,'{levelname}:{name}:{message}'),'$':(StringTemplateStyle,'${levelname}:${name}:${message}')}
class Formatter:
	converter=time.localtime
	def __init__(A,fmt=_A,datefmt=_A,style='%',validate=_B):
		B=style
		if B not in _STYLES:raise ValueError(_S%','.join(_STYLES.keys()))
		A._style=_STYLES[B][0](fmt)
		if validate:A._style.validate()
		A._fmt=A._style._fmt;A.datefmt=datefmt
	default_time_format='%Y-%m-%d %H:%M:%S';default_msec_format='%s,%03d'
	def formatTime(A,record,datefmt=_A):
		C=datefmt;B=record;D=A.converter(B.created)
		if C:E=time.strftime(C,D)
		else:F=time.strftime(A.default_time_format,D);E=A.default_msec_format%(F,B.msecs)
		return E
	def formatException(D,ei):
		B=io.StringIO();C=ei[2];traceback.print_exception(ei[0],ei[1],C,_A,B);A=B.getvalue();B.close()
		if A[-1:]==_D:A=A[:-1]
		return A
	def usesTime(A):return A._style.usesTime()
	def formatMessage(A,record):return A._style.format(record)
	def formatStack(A,stack_info):return stack_info
	def format(C,record):
		A=record;A.message=A.getMessage()
		if C.usesTime():A.asctime=C.formatTime(A,C.datefmt)
		B=C.formatMessage(A)
		if A.exc_info:
			if not A.exc_text:A.exc_text=C.formatException(A.exc_info)
		if A.exc_text:
			if B[-1:]!=_D:B=B+_D
			B=B+A.exc_text
		if A.stack_info:
			if B[-1:]!=_D:B=B+_D
			B=B+C.formatStack(A.stack_info)
		return B
_defaultFormatter=Formatter()
class BufferingFormatter:
	def __init__(A,linefmt=_A):
		B=linefmt
		if B:A.linefmt=B
		else:A.linefmt=_defaultFormatter
	def formatHeader(A,records):return''
	def formatFooter(A,records):return''
	def format(C,records):
		B=records;A=''
		if len(B)>0:
			A=A+C.formatHeader(B)
			for D in B:A=A+C.linefmt.format(D)
			A=A+C.formatFooter(B)
		return A
class Filter:
	def __init__(A,name=''):A.name=name;A.nlen=len(name)
	def filter(A,record):
		B=record
		if A.nlen==0:return _B
		elif A.name==B.name:return _B
		elif B.name.find(A.name,0,A.nlen)!=0:return _C
		return B.name[A.nlen]==_E
class Filterer:
	def __init__(A):A.filters=[]
	def addFilter(A,filter):
		if not filter in A.filters:A.filters.append(filter)
	def removeFilter(A,filter):
		if filter in A.filters:A.filters.remove(filter)
	def filter(E,record):
		B=record;C=_B
		for A in E.filters:
			if hasattr(A,'filter'):D=A.filter(B)
			else:D=A(B)
			if not D:C=_C;break
		return C
_handlers=weakref.WeakValueDictionary()
_handlerList=[]
def _removeHandlerRef(wr):
	B,C,A=_acquireLock,_releaseLock,_handlerList
	if B and C and A:
		B()
		try:
			if wr in A:A.remove(wr)
		finally:C()
def _addHandlerRef(handler):
	_acquireLock()
	try:_handlerList.append(weakref.ref(handler,_removeHandlerRef))
	finally:_releaseLock()
class Handler(Filterer):
	def __init__(A,level=NOTSET):Filterer.__init__(A);A._name=_A;A.level=_checkLevel(level);A.formatter=_A;_addHandlerRef(A);A.createLock()
	def get_name(A):return A._name
	def set_name(A,name):
		B=name;_acquireLock()
		try:
			if A._name in _handlers:del _handlers[A._name]
			A._name=B
			if B:_handlers[B]=A
		finally:_releaseLock()
	name=property(get_name,set_name)
	def createLock(A):A.lock=threading.RLock();_register_at_fork_reinit_lock(A)
	def acquire(A):
		if A.lock:A.lock.acquire()
	def release(A):
		if A.lock:A.lock.release()
	def setLevel(A,level):A.level=_checkLevel(level)
	def format(A,record):
		if A.formatter:B=A.formatter
		else:B=_defaultFormatter
		return B.format(record)
	def emit(A,record):raise NotImplementedError('emit must be implemented by Handler subclasses')
	def handle(A,record):
		B=record;C=A.filter(B)
		if C:
			A.acquire()
			try:A.emit(B)
			finally:A.release()
		return C
	def setFormatter(A,fmt):A.formatter=fmt
	def flush(A):0
	def close(A):
		_acquireLock()
		try:
			if A._name and A._name in _handlers:del _handlers[A._name]
		finally:_releaseLock()
	def handleError(F,record):
		B=record
		if raiseExceptions and sys.stderr:
			D,E,C=sys.exc_info()
			try:
				sys.stderr.write('--- Logging error ---\n');traceback.print_exception(D,E,C,_A,sys.stderr);sys.stderr.write('Call stack:\n');A=C.tb_frame
				while A and os.path.dirname(A.f_code.co_filename)==__path__[0]:A=A.f_back
				if A:traceback.print_stack(A,file=sys.stderr)
				else:sys.stderr.write('Logged from file %s, line %s\n'%(B.filename,B.lineno))
				try:sys.stderr.write('Message: %r\nArguments: %s\n'%(B.msg,B.args))
				except RecursionError:raise
				except Exception:sys.stderr.write('Unable to print the message and arguments - possible formatting error.\nUse the traceback above to help find the error.\n')
			except OSError:pass
			finally:del D,E,C
	def __repr__(A):B=getLevelName(A.level);return'<%s (%s)>'%(A.__class__.__name__,B)
class StreamHandler(Handler):
	terminator=_D
	def __init__(B,stream=_A):
		A=stream;Handler.__init__(B)
		if A is _A:A=sys.stderr
		B.stream=A
	def flush(A):
		A.acquire()
		try:
			if A.stream and hasattr(A.stream,'flush'):A.stream.flush()
		finally:A.release()
	def emit(A,record):
		B=record
		try:C=A.format(B);D=A.stream;D.write(C+A.terminator);A.flush()
		except RecursionError:raise
		except Exception:A.handleError(B)
	def setStream(A,stream):
		B=stream
		if B is A.stream:C=_A
		else:
			C=A.stream;A.acquire()
			try:A.flush();A.stream=B
			finally:A.release()
		return C
	def __repr__(B):
		C=getLevelName(B.level);A=getattr(B.stream,'name','');A=str(A)
		if A:A+=' '
		return'<%s %s(%s)>'%(B.__class__.__name__,A,C)
class FileHandler(StreamHandler):
	def __init__(A,filename,mode='a',encoding=_A,delay=_C):
		C=delay;B=filename;B=os.fspath(B);A.baseFilename=os.path.abspath(B);A.mode=mode;A.encoding=encoding;A.delay=C
		if C:Handler.__init__(A);A.stream=_A
		else:StreamHandler.__init__(A,A._open())
	def close(A):
		A.acquire()
		try:
			try:
				if A.stream:
					try:A.flush()
					finally:
						B=A.stream;A.stream=_A
						if hasattr(B,'close'):B.close()
			finally:StreamHandler.close(A)
		finally:A.release()
	def _open(A):return open(A.baseFilename,A.mode,encoding=A.encoding)
	def emit(A,record):
		if A.stream is _A:A.stream=A._open()
		StreamHandler.emit(A,record)
	def __repr__(A):B=getLevelName(A.level);return _L%(A.__class__.__name__,A.baseFilename,B)
class _StderrHandler(StreamHandler):
	def __init__(A,level=NOTSET):Handler.__init__(A,level)
	@property
	def stream(self):return sys.stderr
_defaultLastResort=_StderrHandler(WARNING)
lastResort=_defaultLastResort
class PlaceHolder:
	def __init__(A,alogger):A.loggerMap={alogger:_A}
	def append(A,alogger):
		B=alogger
		if B not in A.loggerMap:A.loggerMap[B]=_A
def setLoggerClass(klass):
	A=klass
	if A!=Logger:
		if not issubclass(A,Logger):raise TypeError(_T+A.__name__)
	global _loggerClass;_loggerClass=A
def getLoggerClass():return _loggerClass
class Manager:
	def __init__(A,rootnode):A.root=rootnode;A.disable=0;A.emittedNoHandlerWarning=_C;A.loggerDict={};A.loggerClass=_A;A.logRecordFactory=_A
	@property
	def disable(self):return self._disable
	@disable.setter
	def disable(self,value):self._disable=_checkLevel(value)
	def getLogger(B,name):
		C=name;A=_A
		if not isinstance(C,str):raise TypeError('A logger name must be a string')
		_acquireLock()
		try:
			if C in B.loggerDict:
				A=B.loggerDict[C]
				if isinstance(A,PlaceHolder):D=A;A=(B.loggerClass or _loggerClass)(C);A.manager=B;B.loggerDict[C]=A;B._fixupChildren(D,A);B._fixupParents(A)
			else:A=(B.loggerClass or _loggerClass)(C);A.manager=B;B.loggerDict[C]=A;B._fixupParents(A)
		finally:_releaseLock()
		return A
	def setLoggerClass(B,klass):
		A=klass
		if A!=Logger:
			if not issubclass(A,Logger):raise TypeError(_T+A.__name__)
		B.loggerClass=A
	def setLogRecordFactory(A,factory):A.logRecordFactory=factory
	def _fixupParents(B,alogger):
		C=alogger;F=C.name;D=F.rfind(_E);A=_A
		while D>0 and not A:
			G=F[:D]
			if G not in B.loggerDict:B.loggerDict[G]=PlaceHolder(C)
			else:
				E=B.loggerDict[G]
				if isinstance(E,Logger):A=E
				else:assert isinstance(E,PlaceHolder);E.append(C)
			D=F.rfind(_E,0,D-1)
		if not A:A=B.root
		C.parent=A
	def _fixupChildren(E,ph,alogger):
		A=alogger;C=A.name;D=len(C)
		for B in ph.loggerMap.keys():
			if B.parent.name[:D]!=C:A.parent=B.parent;B.parent=A
	def _clear_cache(A):
		_acquireLock()
		for B in A.loggerDict.values():
			if isinstance(B,Logger):B._cache.clear()
		A.root._cache.clear();_releaseLock()
class Logger(Filterer):
	def __init__(A,name,level=NOTSET):Filterer.__init__(A);A.name=name;A.level=_checkLevel(level);A.parent=_A;A.propagate=_B;A.handlers=[];A.disabled=_C;A._cache={}
	def setLevel(A,level):A.level=_checkLevel(level);A.manager._clear_cache()
	def debug(A,msg,*B,**C):
		if A.isEnabledFor(DEBUG):A._log(DEBUG,msg,B,**C)
	def info(A,msg,*B,**C):
		if A.isEnabledFor(INFO):A._log(INFO,msg,B,**C)
	def warning(A,msg,*B,**C):
		if A.isEnabledFor(WARNING):A._log(WARNING,msg,B,**C)
	def warn(A,msg,*B,**C):warnings.warn(_U,DeprecationWarning,2);A.warning(msg,*B,**C)
	def error(A,msg,*B,**C):
		if A.isEnabledFor(ERROR):A._log(ERROR,msg,B,**C)
	def exception(A,msg,*B,exc_info=_B,**C):A.error(msg,*B,exc_info=exc_info,**C)
	def critical(A,msg,*B,**C):
		if A.isEnabledFor(CRITICAL):A._log(CRITICAL,msg,B,**C)
	fatal=critical
	def log(B,level,msg,*C,**D):
		A=level
		if not isinstance(A,int):
			if raiseExceptions:raise TypeError('level must be an integer')
			else:return
		if B.isEnabledFor(A):B._log(A,msg,C,**D)
	def findCaller(I,stack_info=_C,stacklevel=1):
		E=stacklevel;A=currentframe()
		if A is not _A:A=A.f_back
		G=A
		while A and E>1:A=A.f_back;E-=1
		if not A:A=G
		F=_M,0,_N,_A
		while hasattr(A,'f_code'):
			D=A.f_code;H=os.path.normcase(D.co_filename)
			if H==_srcfile:A=A.f_back;continue
			B=_A
			if stack_info:
				C=io.StringIO();C.write('Stack (most recent call last):\n');traceback.print_stack(A,file=C);B=C.getvalue()
				if B[-1]==_D:B=B[:-1]
				C.close()
			F=D.co_filename,A.f_lineno,D.co_name,B;break
		return F
	def makeRecord(D,name,level,fn,lno,msg,args,exc_info,func=_A,extra=_A,sinfo=_A):
		B=extra;C=_logRecordFactory(name,level,fn,lno,msg,args,exc_info,func,sinfo)
		if B is not _A:
			for A in B:
				if A in['message','asctime']or A in C.__dict__:raise KeyError('Attempt to overwrite %r in LogRecord'%A)
				C.__dict__[A]=B[A]
		return C
	def _log(B,level,msg,args,exc_info=_A,extra=_A,stack_info=_C,stacklevel=1):
		A=exc_info;F=_A
		if _srcfile:
			try:C,D,E,F=B.findCaller(stack_info,stacklevel)
			except ValueError:C,D,E=_M,0,_N
		else:C,D,E=_M,0,_N
		if A:
			if isinstance(A,BaseException):A=type(A),A,A.__traceback__
			elif not isinstance(A,tuple):A=sys.exc_info()
		G=B.makeRecord(B.name,level,C,D,msg,args,A,E,extra,F);B.handle(G)
	def handle(A,record):
		B=record
		if not A.disabled and A.filter(B):A.callHandlers(B)
	def addHandler(A,hdlr):
		_acquireLock()
		try:
			if not hdlr in A.handlers:A.handlers.append(hdlr)
		finally:_releaseLock()
	def removeHandler(A,hdlr):
		_acquireLock()
		try:
			if hdlr in A.handlers:A.handlers.remove(hdlr)
		finally:_releaseLock()
	def hasHandlers(C):
		A=C;B=_C
		while A:
			if A.handlers:B=_B;break
			if not A.propagate:break
			else:A=A.parent
		return B
	def callHandlers(B,record):
		C=record;A=B;D=0
		while A:
			for E in A.handlers:
				D=D+1
				if C.levelno>=E.level:E.handle(C)
			if not A.propagate:A=_A
			else:A=A.parent
		if D==0:
			if lastResort:
				if C.levelno>=lastResort.level:lastResort.handle(C)
			elif raiseExceptions and not B.manager.emittedNoHandlerWarning:sys.stderr.write('No handlers could be found for logger "%s"\n'%B.name);B.manager.emittedNoHandlerWarning=_B
	def getEffectiveLevel(B):
		A=B
		while A:
			if A.level:return A.level
			A=A.parent
		return NOTSET
	def isEnabledFor(A,level):
		B=level
		if A.disabled:return _C
		try:return A._cache[B]
		except KeyError:
			_acquireLock()
			try:
				if A.manager.disable>=B:C=A._cache[B]=_C
				else:C=A._cache[B]=B>=A.getEffectiveLevel()
			finally:_releaseLock()
			return C
	def getChild(A,suffix):
		B=suffix
		if A.root is not A:B=_E.join((A.name,B))
		return A.manager.getLogger(B)
	def __repr__(A):B=getLevelName(A.getEffectiveLevel());return _L%(A.__class__.__name__,A.name,B)
	def __reduce__(A):
		if getLogger(A.name)is not A:import pickle as B;raise B.PicklingError('logger cannot be pickled')
		return getLogger,(A.name,)
class RootLogger(Logger):
	def __init__(A,level):Logger.__init__(A,'root',level)
	def __reduce__(A):return getLogger,()
_loggerClass=Logger
class LoggerAdapter:
	def __init__(A,logger,extra):A.logger=logger;A.extra=extra
	def process(B,msg,kwargs):A=kwargs;A['extra']=B.extra;return msg,A
	def debug(A,msg,*B,**C):A.log(DEBUG,msg,*B,**C)
	def info(A,msg,*B,**C):A.log(INFO,msg,*B,**C)
	def warning(A,msg,*B,**C):A.log(WARNING,msg,*B,**C)
	def warn(A,msg,*B,**C):warnings.warn(_U,DeprecationWarning,2);A.warning(msg,*B,**C)
	def error(A,msg,*B,**C):A.log(ERROR,msg,*B,**C)
	def exception(A,msg,*B,exc_info=_B,**C):A.log(ERROR,msg,*B,exc_info=exc_info,**C)
	def critical(A,msg,*B,**C):A.log(CRITICAL,msg,*B,**C)
	def log(A,level,msg,*E,**C):
		D=level;B=msg
		if A.isEnabledFor(D):B,C=A.process(B,C);A.logger.log(D,B,*E,**C)
	def isEnabledFor(A,level):return A.logger.isEnabledFor(level)
	def setLevel(A,level):A.logger.setLevel(level)
	def getEffectiveLevel(A):return A.logger.getEffectiveLevel()
	def hasHandlers(A):return A.logger.hasHandlers()
	def _log(A,level,msg,args,exc_info=_A,extra=_A,stack_info=_C):return A.logger._log(level,msg,args,exc_info=exc_info,extra=extra,stack_info=stack_info)
	@property
	def manager(self):return self.logger.manager
	@manager.setter
	def manager(self,value):self.logger.manager=value
	@property
	def name(self):return self.logger.name
	def __repr__(A):B=A.logger;C=getLevelName(B.getEffectiveLevel());return _L%(A.__class__.__name__,B.name,C)
root=RootLogger(WARNING)
Logger.root=root
Logger.manager=Manager(Logger.root)
def basicConfig(**A):
	H='filename';G='stream';_acquireLock()
	try:
		I=A.pop('force',_C)
		if I:
			for B in root.handlers[:]:root.removeHandler(B);B.close()
		if len(root.handlers)==0:
			C=A.pop('handlers',_A)
			if C is _A:
				if G in A and H in A:raise ValueError("'stream' and 'filename' should not be specified together")
			elif G in A or H in A:raise ValueError("'stream' or 'filename' should not be specified together with 'handlers'")
			if C is _A:
				E=A.pop(H,_A);J=A.pop('filemode','a')
				if E:B=FileHandler(E,J)
				else:K=A.pop(G,_A);B=StreamHandler(K)
				C=[B]
			L=A.pop('datefmt',_A);D=A.pop('style','%')
			if D not in _STYLES:raise ValueError(_S%','.join(_STYLES.keys()))
			M=A.pop('format',_STYLES[D][1]);N=Formatter(M,L,D)
			for B in C:
				if B.formatter is _A:B.setFormatter(N)
				root.addHandler(B)
			F=A.pop('level',_A)
			if F is not _A:root.setLevel(F)
			if A:O=', '.join(A.keys());raise ValueError('Unrecognised argument(s): %s'%O)
	finally:_releaseLock()
def getLogger(name=_A):
	if name:return Logger.manager.getLogger(name)
	else:return root
def critical(msg,*A,**B):
	if len(root.handlers)==0:basicConfig()
	root.critical(msg,*A,**B)
fatal=critical
def error(msg,*A,**B):
	if len(root.handlers)==0:basicConfig()
	root.error(msg,*A,**B)
def exception(msg,*A,exc_info=_B,**B):error(msg,*A,exc_info=exc_info,**B)
def warning(msg,*A,**B):
	if len(root.handlers)==0:basicConfig()
	root.warning(msg,*A,**B)
def warn(msg,*A,**B):warnings.warn("The 'warn' function is deprecated, use 'warning' instead",DeprecationWarning,2);warning(msg,*A,**B)
def info(msg,*A,**B):
	if len(root.handlers)==0:basicConfig()
	root.info(msg,*A,**B)
def debug(msg,*A,**B):
	if len(root.handlers)==0:basicConfig()
	root.debug(msg,*A,**B)
def log(level,msg,*A,**B):
	if len(root.handlers)==0:basicConfig()
	root.log(level,msg,*A,**B)
def disable(level=CRITICAL):root.manager.disable=level;root.manager._clear_cache()
def shutdown(handlerList=_handlerList):
	for B in reversed(handlerList[:]):
		try:
			A=B()
			if A:
				try:A.acquire();A.flush();A.close()
				except (OSError,ValueError):pass
				finally:A.release()
		except:
			if raiseExceptions:raise
import atexit
atexit.register(shutdown)
class NullHandler(Handler):
	def handle(A,record):0
	def emit(A,record):0
	def createLock(A):A.lock=_A
_warnings_showwarning=_A
def _showwarning(message,category,filename,lineno,file=_A,line=_A):
	E=lineno;D=filename;C=category;B=message
	if file is not _A:
		if _warnings_showwarning is not _A:_warnings_showwarning(B,C,D,E,file,line)
	else:
		F=warnings.formatwarning(B,C,D,E,line);A=getLogger('py.warnings')
		if not A.handlers:A.addHandler(NullHandler())
		A.warning('%s',F)
def captureWarnings(capture):
	global _warnings_showwarning
	if capture:
		if _warnings_showwarning is _A:_warnings_showwarning=warnings.showwarning;warnings.showwarning=_showwarning
	elif _warnings_showwarning is not _A:warnings.showwarning=_warnings_showwarning;_warnings_showwarning=_A