from __future__ import absolute_import,division,print_function
class Argon2Error(Exception):0
class VerificationError(Argon2Error):0
class VerifyMismatchError(VerificationError):0
class HashingError(Argon2Error):0
class InvalidHash(ValueError):0