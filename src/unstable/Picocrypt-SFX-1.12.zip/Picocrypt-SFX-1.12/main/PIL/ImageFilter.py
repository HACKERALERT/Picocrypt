_D='cannot filter palette images'
_C='Only 3 or 4 output channels are supported'
_B=False
_A=None
import functools
class Filter:0
class MultibandFilter(Filter):0
class BuiltinFilter(MultibandFilter):
	def filter(B,image):
		A=image
		if A.mode=='P':raise ValueError(_D)
		return A.filter(*B.filterargs)
class Kernel(BuiltinFilter):
	name='Kernel'
	def __init__(D,size,kernel,scale=_A,offset=0):
		C=scale;B=kernel;A=size
		if C is _A:C=functools.reduce(lambda a,b:a+b,B)
		if A[0]*A[1]!=len(B):raise ValueError('not enough coefficients in kernel')
		D.filterargs=A,C,offset,B
class RankFilter(Filter):
	name='Rank'
	def __init__(A,size,rank):A.size=size;A.rank=rank
	def filter(A,image):
		B=image
		if B.mode=='P':raise ValueError(_D)
		B=B.expand(A.size//2,A.size//2);return B.rankfilter(A.size,A.rank)
class MedianFilter(RankFilter):
	name='Median'
	def __init__(B,size=3):A=size;B.size=A;B.rank=A*A//2
class MinFilter(RankFilter):
	name='Min'
	def __init__(A,size=3):A.size=size;A.rank=0
class MaxFilter(RankFilter):
	name='Max'
	def __init__(B,size=3):A=size;B.size=A;B.rank=A*A-1
class ModeFilter(Filter):
	name='Mode'
	def __init__(A,size=3):A.size=size
	def filter(A,image):return image.modefilter(A.size)
class GaussianBlur(MultibandFilter):
	name='GaussianBlur'
	def __init__(A,radius=2):A.radius=radius
	def filter(A,image):return image.gaussian_blur(A.radius)
class BoxBlur(MultibandFilter):
	name='BoxBlur'
	def __init__(A,radius):A.radius=radius
	def filter(A,image):return image.box_blur(A.radius)
class UnsharpMask(MultibandFilter):
	name='UnsharpMask'
	def __init__(A,radius=2,percent=150,threshold=3):A.radius=radius;A.percent=percent;A.threshold=threshold
	def filter(A,image):return image.unsharp_mask(A.radius,A.percent,A.threshold)
class BLUR(BuiltinFilter):name='Blur';filterargs=(5,5),16,0,(1,1,1,1,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,1)
class CONTOUR(BuiltinFilter):name='Contour';filterargs=(3,3),1,255,(-1,-1,-1,-1,8,-1,-1,-1,-1)
class DETAIL(BuiltinFilter):name='Detail';filterargs=(3,3),6,0,(0,-1,0,-1,10,-1,0,-1,0)
class EDGE_ENHANCE(BuiltinFilter):name='Edge-enhance';filterargs=(3,3),2,0,(-1,-1,-1,-1,10,-1,-1,-1,-1)
class EDGE_ENHANCE_MORE(BuiltinFilter):name='Edge-enhance More';filterargs=(3,3),1,0,(-1,-1,-1,-1,9,-1,-1,-1,-1)
class EMBOSS(BuiltinFilter):name='Emboss';filterargs=(3,3),1,128,(-1,0,0,0,1,0,0,0,0)
class FIND_EDGES(BuiltinFilter):name='Find Edges';filterargs=(3,3),1,0,(-1,-1,-1,-1,8,-1,-1,-1,-1)
class SHARPEN(BuiltinFilter):name='Sharpen';filterargs=(3,3),16,0,(-2,-2,-2,-2,32,-2,-2,-2,-2)
class SMOOTH(BuiltinFilter):name='Smooth';filterargs=(3,3),13,0,(1,1,1,1,5,1,1,1,1)
class SMOOTH_MORE(BuiltinFilter):name='Smooth More';filterargs=(5,5),100,0,(1,1,1,1,1,1,5,5,5,1,1,5,44,5,1,1,5,5,5,1,1,1,1,1,1)
class Color3DLUT(MultibandFilter):
	name='Color 3D LUT'
	def __init__(D,size,table,channels=3,target_mode=_A,**J):
		L=True;C=channels;B=size;A=table
		if C not in(3,4):raise ValueError(_C)
		D.size=B=D._check_size(B);D.channels=C;D.mode=target_mode;G=J.get('_copy_table',L);E=B[0]*B[1]*B[2];H=_B;F=_A
		if hasattr(A,'shape'):
			try:import numpy as F
			except ImportError:pass
		if F and isinstance(A,F.ndarray):
			if G:A=A.copy()
			if A.shape in[(E*C,),(E,C),(B[2],B[1],B[0],C)]:A=A.reshape(E*C)
			else:H=L
		else:
			if G:A=list(A)
			if A and isinstance(A[0],(list,tuple)):
				A,K=[],A
				for I in K:
					if len(I)!=C:raise ValueError('The elements of the table should have a length of {}.'.format(C))
					A.extend(I)
		if H or len(A)!=E*C:raise ValueError(f"The table should have either channels * size**3 float items or size**3 items of channels-sized tuples with floats. Table should be: {C}x{B[0]}x{B[1]}x{B[2]}. Actual length: {len(A)}")
		D.table=A
	@staticmethod
	def _check_size(size):
		A=size
		try:_,_,_=A
		except ValueError as B:raise ValueError('Size should be either an integer or a tuple of three integers.') from B
		except TypeError:A=A,A,A
		A=[int(B)for B in A]
		for C in A:
			if not 2<=C<=65:raise ValueError('Size should be in [2, 65] range.')
		return A
	@classmethod
	def generate(F,size,callback,channels=3,target_mode=_A):
		A=channels;B,C,D=F._check_size(size)
		if A not in(3,4):raise ValueError(_C)
		G=[0]*(B*C*D*A);E=0
		for H in range(D):
			for I in range(C):
				for J in range(B):G[E:E+A]=callback(J/(B-1),I/(C-1),H/(D-1));E+=A
		return F((B,C,D),G,channels=A,target_mode=target_mode,_copy_table=_B)
	def transform(A,callback,with_normals=_B,channels=_A,target_mode=_A):
		K=channels;J=callback
		if K not in(_A,3,4):raise ValueError(_C)
		D=A.channels;C=K or D;E,F,G=A.size;L=[0]*(E*F*G*C);H=0;I=0
		for M in range(G):
			for N in range(F):
				for O in range(E):
					B=A.table[H:H+D]
					if with_normals:B=J(O/(E-1),N/(F-1),M/(G-1),*B)
					else:B=J(*B)
					L[I:I+C]=B;H+=D;I+=C
		return type(A)(A.size,L,channels=C,target_mode=target_mode or A.mode,_copy_table=_B)
	def __repr__(A):
		B=[f"{A.__class__.__name__} from {A.table.__class__.__name__}",'size={:d}x{:d}x{:d}'.format(*A.size),f"channels={A.channels:d}"]
		if A.mode:B.append(f"target_mode={A.mode}")
		return '<{}>'.format(' '.join(B))
	def filter(A,image):B=image;from .  import Image;return B.color_lut_3d(A.mode or B.mode,Image.LINEAR,A.channels,A.size[0],A.size[1],A.size[2],A.table)