_H='white'
_G=True
_F='background'
_E='themebg'
_D='toplevel'
_C=False
_B='theme'
_A=None
import tkinter as tk
from tkinter import ttk
from ._widget import ThemedWidget
class ThemedTk(tk.Tk,ThemedWidget):
	__tk_toplevel_init=tk.Toplevel.__init__
	def __init__(A,*E,**B):
		C=B.pop(_B,_A);G=B.pop('fonts',_C);A._toplevel=B.pop(_D,_A);A._themebg=B.pop(_E,_A);D=B.pop(_F,_A)
		if isinstance(D,bool):A._themebg=A._themebg or D
		F=B.pop('gif_override',_C);tk.Tk.__init__(A,*E,**B);ThemedWidget.__init__(A,A.tk,F)
		if C is not _A and C in A.get_themes():A.set_theme(C,A._toplevel,A._themebg)
	def set_theme(A,theme_name,toplevel=_A,themebg=_A):
		C=themebg;B=toplevel
		if A._toplevel is not _A and B is _A:B=A._toplevel
		if A._themebg is not _A and C is _A:C=A._themebg
		ThemedWidget.set_theme(A,theme_name);D=A._get_bg_color()
		if C is _G:A.config(background=D)
		if B is _G:A._setup_toplevel_hook(D)
	def _get_bg_color(A):return ttk.Style(A).lookup('TFrame',_F,default=_H)
	def _setup_toplevel_hook(A,color):
		def __toplevel__(*B,**A):A.setdefault(_F,color);ThemedTk.__tk_toplevel_init(*B,**A)
		tk.Toplevel.__init__=__toplevel__
	def config(A,kw=_A,**B):
		C=B.pop(_E,A._themebg);D=B.pop(_D,A._toplevel);E=B.pop(_B,A.current_theme);F=A._get_bg_color()
		if C!=A._themebg:
			if C is _C:A.configure(bg=_H)
			else:A.configure(bg=F)
			A._themebg=C
		if D!=A._toplevel:
			if D is _G:A._setup_toplevel_hook(F)
			else:tk.Toplevel.__init__=ThemedTk.__tk_toplevel_init
			A._toplevel=D
		if E!=A.current_theme:A.set_theme(E)
		return tk.Tk.config(A,kw,**B)
	def cget(A,k):
		if k==_E:return A._themebg
		elif k==_D:return A._toplevel
		elif k==_B:return A.current_theme
		return tk.Tk.cget(A,k)
	def configure(A,kw=_A,**B):return A.config(kw,**B)
	def __getitem__(A,k):return A.cget(k)
	def __setitem__(A,k,v):return A.config(**{k:v})