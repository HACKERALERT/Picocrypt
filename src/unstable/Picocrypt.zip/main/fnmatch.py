import os,posixpath,re,functools
__all__=['filter','fnmatch','fnmatchcase','translate']
def fnmatch(name,pat):B=pat;A=name;A=os.path.normcase(A);B=os.path.normcase(B);return fnmatchcase(A,B)
@functools.lru_cache(maxsize=256,typed=True)
def _compile_pattern(pat):
	E='ISO-8859-1';A=pat
	if isinstance(A,bytes):C=str(A,E);D=translate(C);B=bytes(D,E)
	else:B=translate(A)
	return re.compile(B).match
def filter(names,pat):
	D=names;B=pat;C=[];B=os.path.normcase(B);E=_compile_pattern(B)
	if os.path is posixpath:
		for A in D:
			if E(A):C.append(A)
	else:
		for A in D:
			if E(os.path.normcase(A)):C.append(A)
	return C
def fnmatchcase(name,pat):A=_compile_pattern(pat);return A(name)is not None
def translate(pat):
	P='^';O='\\\\';N=']';M='[';L='-';K='\\';J='!';E=pat;B,G=0,len(E);D=''
	while B<G:
		H=E[B];B=B+1
		if H=='*':D=D+'.*'
		elif H=='?':D=D+'.'
		elif H==M:
			A=B
			if A<G and E[A]==J:A=A+1
			if A<G and E[A]==N:A=A+1
			while A<G and E[A]!=N:A=A+1
			if A>=G:D=D+'\\['
			else:
				C=E[B:A]
				if'--'not in C:C=C.replace(K,O)
				else:
					I=[];F=B+2 if E[B]==J else B+1
					while True:
						F=E.find(L,F,A)
						if F<0:break
						I.append(E[B:F]);B=F+1;F=F+3
					I.append(E[B:A]);C=L.join((A.replace(K,O).replace(L,'\\-')for A in I))
				C=re.sub('([&~|])','\\\\\\1',C);B=A+1
				if C[0]==J:C=P+C[1:]
				elif C[0]in(P,M):C=K+C
				D='%s[%s]'%(D,C)
		else:D=D+re.escape(H)
	return'(?s:%s)\\Z'%D