_F='getrandbits'
_E='random'
_D='big'
_C=0.0
_B=None
_A=1.0
from warnings import warn as _warn
from math import log as _log,exp as _exp,pi as _pi,e as _e,ceil as _ceil
from math import sqrt as _sqrt,acos as _acos,cos as _cos,sin as _sin
from os import urandom as _urandom
from _collections_abc import Set as _Set,Sequence as _Sequence
from itertools import accumulate as _accumulate,repeat as _repeat
from bisect import bisect as _bisect
import os as _os
try:from _sha512 import sha512 as _sha512
except ImportError:from hashlib import sha512 as _sha512
__all__=['Random','seed',_E,'uniform','randint','choice','sample','randrange','shuffle','normalvariate','lognormvariate','expovariate','vonmisesvariate','gammavariate','triangular','gauss','betavariate','paretovariate','weibullvariate','getstate','setstate',_F,'choices','SystemRandom']
NV_MAGICCONST=4*_exp(-0.5)/_sqrt(2.0)
TWOPI=2.0*_pi
LOG4=_log(4.0)
SG_MAGICCONST=_A+_log(4.5)
BPF=53
RECIP_BPF=2**(-BPF)
import _random
class Random(_random.Random):
	VERSION=3
	def __init__(A,x=_B):A.seed(x);A.gauss_next=_B
	def __init_subclass__(A,/,**C):
		for B in A.__mro__:
			if'_randbelow'in B.__dict__:break
			if _F in B.__dict__:A._randbelow=A._randbelow_with_getrandbits;break
			if _E in B.__dict__:A._randbelow=A._randbelow_without_getrandbits;break
	def seed(C,a=_B,version=2):
		B=version
		if B==1 and isinstance(a,(str,bytes)):
			a=a.decode('latin-1')if isinstance(a,bytes)else a;A=ord(a[0])<<7 if a else 0
			for D in map(ord,a):A=(1000003*A^D)&0xffffffffffffffff
			A^=len(a);a=-2 if A==-1 else A
		if B==2 and isinstance(a,(str,bytes,bytearray)):
			if isinstance(a,str):a=a.encode()
			a+=_sha512(a).digest();a=int.from_bytes(a,_D)
		super().seed(a);C.gauss_next=_B
	def getstate(A):return A.VERSION,super().getstate(),A.gauss_next
	def setstate(C,state):
		D=state;A=D[0]
		if A==3:A,B,C.gauss_next=D;super().setstate(B)
		elif A==2:
			A,B,C.gauss_next=D
			try:B=tuple((A%2**32 for A in B))
			except ValueError as E:raise TypeError from E
			super().setstate(B)
		else:raise ValueError('state with version %s passed to Random.setstate() of version %s'%(A,C.VERSION))
	def __getstate__(A):return A.getstate()
	def __setstate__(A,state):A.setstate(state)
	def __reduce__(A):return A.__class__,(),A.getstate()
	def randrange(E,start,stop=_B,step=1,_int=int):
		K='empty range for randrange()';J=start;G=_int;F=stop;D=step;B=G(J)
		if B!=J:raise ValueError('non-integer arg 1 for randrange()')
		if F is _B:
			if B>0:return E._randbelow(B)
			raise ValueError(K)
		H=G(F)
		if H!=F:raise ValueError('non-integer stop for randrange()')
		C=H-B
		if D==1 and C>0:return B+E._randbelow(C)
		if D==1:raise ValueError('empty range for randrange() (%d, %d, %d)'%(B,H,C))
		A=G(D)
		if A!=D:raise ValueError('non-integer step for randrange()')
		if A>0:I=(C+A-1)//A
		elif A<0:I=(C+A+1)//A
		else:raise ValueError('zero step for randrange()')
		if I<=0:raise ValueError(K)
		return B+A*E._randbelow(I)
	def randint(A,a,b):return A.randrange(a,b+1)
	def _randbelow_with_getrandbits(D,n):
		B=D.getrandbits;C=n.bit_length();A=B(C)
		while A>=n:A=B(C)
		return A
	def _randbelow_without_getrandbits(D,n,int=int,maxsize=1<<BPF):
		A=maxsize;B=D.random
		if n>=A:_warn('Underlying random() generator does not supply \nenough bits to choose from a population range this large.\nTo remove the range limitation, add a getrandbits() method.');return int(B()*n)
		if n==0:raise ValueError('Boundary cannot be zero')
		E=A%n;F=(A-E)/A;C=B()
		while C>=F:C=B()
		return int(C*A)%n
	_randbelow=_randbelow_with_getrandbits
	def choice(A,seq):
		try:B=A._randbelow(len(seq))
		except ValueError:raise IndexError('Cannot choose from an empty sequence') from _B
		return seq[B]
	def shuffle(D,x,random=_B):
		C=random
		if C is _B:
			E=D._randbelow
			for A in reversed(range(1,len(x))):B=E(A+1);x[A],x[B]=x[B],x[A]
		else:
			F=int
			for A in reversed(range(1,len(x))):B=F(C()*(A+1));x[A],x[B]=x[B],x[A]
	def sample(J,population,k):
		A=population
		if isinstance(A,_Set):A=tuple(A)
		if not isinstance(A,_Sequence):raise TypeError('Population must be a sequence or set.  For dicts, use list(d).')
		E=J._randbelow;C=len(A)
		if not 0<=k<=C:raise ValueError('Sample larger than population or is negative')
		F=[_B]*k;H=21
		if k>5:H+=4**_ceil(_log(k*3,4))
		if C<=H:
			G=list(A)
			for D in range(k):B=E(C-D);F[D]=G[B];G[B]=G[C-D-1]
		else:
			I=set();K=I.add
			for D in range(k):
				B=E(C)
				while B in I:B=E(C)
				K(B);F[D]=A[B]
		return F
	def choices(F,population,weights=_B,*,cum_weights=_B,k=1):
		D=weights;C=population;A=cum_weights;E=F.random;B=len(C)
		if A is _B:
			if D is _B:G=int;B+=_C;return[C[G(E()*B)]for A in _repeat(_B,k)]
			A=list(_accumulate(D))
		elif D is not _B:raise TypeError('Cannot specify both weights and cumulative weights')
		if len(A)!=B:raise ValueError('The number of weights does not match the population')
		H=_bisect;I=A[-1]+_C;J=B-1;return[C[H(A,E()*I,0,J)]for B in _repeat(_B,k)]
	def uniform(A,a,b):return a+(b-a)*A.random()
	def triangular(E,low=_C,high=_A,mode=_B):
		B=high;A=low;C=E.random()
		try:D=0.5 if mode is _B else(mode-A)/(B-A)
		except ZeroDivisionError:return A
		if C>D:C=_A-C;D=_A-D;A,B=B,A
		return A+(B-A)*_sqrt(C*D)
	def normalvariate(D,mu,sigma):
		B=D.random
		while 1:
			E=B();C=_A-B();A=NV_MAGICCONST*(E-0.5)/C;F=A*A/4.0
			if F<=-_log(C):break
		return mu+A*sigma
	def lognormvariate(A,mu,sigma):return _exp(A.normalvariate(mu,sigma))
	def expovariate(A,lambd):return-_log(_A-A.random())/lambd
	def vonmisesvariate(K,mu,kappa):
		E=kappa;A=K.random
		if E<=1e-06:return TWOPI*A()
		D=0.5/E;F=D+_sqrt(_A+D*D)
		while 1:
			L=A();B=_cos(_pi*L);C=B/(F+B);G=A()
			if G<_A-C*C or G<=(_A-C)*_exp(C):break
		H=_A/F;I=(H+B)/(_A+H*B);M=A()
		if M>0.5:J=(mu+_acos(I))%TWOPI
		else:J=(mu-_acos(I))%TWOPI
		return J
	def gammavariate(L,alpha,beta):
		E=beta;A=alpha
		if A<=_C or E<=_C:raise ValueError('gammavariate: alpha and beta must be > 0.0')
		D=L.random
		if A>_A:
			G=_sqrt(2.0*A-_A);M=A-LOG4;N=A+G
			while 1:
				B=D()
				if not 1e-07<B<0.9999999:continue
				O=_A-D();H=_log(B/(_A-B))/G;C=A*_exp(H);I=B*B*O;J=M+N*H-C
				if J+SG_MAGICCONST-4.5*I>=_C or J>=_log(I):return C*E
		elif A==_A:return-_log(_A-D())*E
		else:
			while 1:
				P=D();K=(_e+A)/_e;F=K*P
				if F<=_A:C=F**(_A/A)
				else:C=-_log((K-F)/A)
				B=D()
				if F>_A:
					if B<=C**(A-_A):break
				elif B<=_exp(-C):break
			return C*E
	def gauss(A,mu,sigma):
		C=A.random;B=A.gauss_next;A.gauss_next=_B
		if B is _B:D=C()*TWOPI;E=_sqrt(-2.0*_log(_A-C()));B=_cos(D)*E;A.gauss_next=_sin(D)*E
		return mu+B*sigma
	def betavariate(B,alpha,beta):
		A=B.gammavariate(alpha,_A)
		if A==0:return _C
		else:return A/(A+B.gammavariate(beta,_A))
	def paretovariate(A,alpha):B=_A-A.random();return _A/B**(_A/alpha)
	def weibullvariate(A,alpha,beta):B=_A-A.random();return alpha*(-_log(B))**(_A/beta)
class SystemRandom(Random):
	def random(A):return(int.from_bytes(_urandom(7),_D)>>3)*RECIP_BPF
	def getrandbits(C,k):
		if k<=0:raise ValueError('number of bits must be greater than zero')
		A=(k+7)//8;B=int.from_bytes(_urandom(A),_D);return B>>A*8-k
	def seed(A,*B,**C):return _B
	def _notimplemented(A,*B,**C):raise NotImplementedError('System entropy source does not have state.')
	getstate=setstate=_notimplemented
def _test_generator(n,func,args):
	import time as F;print(n,'times',func.__name__);G=_C;B=_C;C=10000000000.0;D=-10000000000.0;H=F.perf_counter()
	for K in range(n):A=func(*args);G+=A;B=B+A*A;C=min(A,C);D=max(A,D)
	I=F.perf_counter();print(round(I-H,3),'sec,',end=' ');E=G/n;J=_sqrt(B/n-E*E);print('avg %g, stddev %g, min %g, max %g\n'%(E,J,C,D))
def _test(N=2000):_test_generator(N,random,());_test_generator(N,normalvariate,(_C,_A));_test_generator(N,lognormvariate,(_C,_A));_test_generator(N,vonmisesvariate,(_C,_A));_test_generator(N,gammavariate,(0.01,_A));_test_generator(N,gammavariate,(0.1,_A));_test_generator(N,gammavariate,(0.1,2.0));_test_generator(N,gammavariate,(0.5,_A));_test_generator(N,gammavariate,(0.9,_A));_test_generator(N,gammavariate,(_A,_A));_test_generator(N,gammavariate,(2.0,_A));_test_generator(N,gammavariate,(20.0,_A));_test_generator(N,gammavariate,(200.0,_A));_test_generator(N,gauss,(_C,_A));_test_generator(N,betavariate,(3.0,3.0));_test_generator(N,triangular,(_C,_A,_A/3.0))
_inst=Random()
seed=_inst.seed
random=_inst.random
uniform=_inst.uniform
triangular=_inst.triangular
randint=_inst.randint
choice=_inst.choice
randrange=_inst.randrange
sample=_inst.sample
shuffle=_inst.shuffle
choices=_inst.choices
normalvariate=_inst.normalvariate
lognormvariate=_inst.lognormvariate
expovariate=_inst.expovariate
vonmisesvariate=_inst.vonmisesvariate
gammavariate=_inst.gammavariate
gauss=_inst.gauss
betavariate=_inst.betavariate
paretovariate=_inst.paretovariate
weibullvariate=_inst.weibullvariate
getstate=_inst.getstate
setstate=_inst.setstate
getrandbits=_inst.getrandbits
if hasattr(_os,'fork'):_os.register_at_fork(after_in_child=_inst.seed)
if __name__=='__main__':_test()