_H='__class__'
_G='__dict__'
_F='__path__'
_E='{}.__spec__ is None'
_D='{}.__spec__ is not set'
_C='The import system now takes care of this automatically.'
_B='.'
_A=None
from .  import abc
from ._bootstrap import module_from_spec
from ._bootstrap import _resolve_name
from ._bootstrap import spec_from_loader
from ._bootstrap import _find_spec
from ._bootstrap_external import MAGIC_NUMBER
from ._bootstrap_external import _RAW_MAGIC_NUMBER
from ._bootstrap_external import cache_from_source
from ._bootstrap_external import decode_source
from ._bootstrap_external import source_from_cache
from ._bootstrap_external import spec_from_file_location
from contextlib import contextmanager
import _imp,functools,sys,types,warnings
def source_hash(source_bytes):return _imp.source_hash(_RAW_MAGIC_NUMBER,source_bytes)
def resolve_name(name,package):
	C=package;A=name
	if not A.startswith(_B):return A
	elif not C:raise ValueError(f"no package specified for {repr(A)} (required for relative module names)")
	B=0
	for D in A:
		if D!=_B:break
		B+=1
	return _resolve_name(A[B:],C,B)
def _find_spec_from_path(name,path=_A):
	A=name
	if A not in sys.modules:return _find_spec(A,path)
	else:
		B=sys.modules[A]
		if B is _A:return _A
		try:C=B.__spec__
		except AttributeError:raise ValueError(_D.format(A)) from _A
		else:
			if C is _A:raise ValueError(_E.format(A))
			return C
def find_spec(name,package=_A):
	B=name;A=resolve_name(B,package)if B.startswith(_B)else B
	if A not in sys.modules:
		C=A.rpartition(_B)[0]
		if C:
			G=__import__(C,fromlist=[_F])
			try:D=G.__path__
			except AttributeError as H:raise ModuleNotFoundError(f"__path__ attribute not found on {C!r} while trying to find {A!r}",name=A) from H
		else:D=_A
		return _find_spec(A,D)
	else:
		E=sys.modules[A]
		if E is _A:return _A
		try:F=E.__spec__
		except AttributeError:raise ValueError(_D.format(B)) from _A
		else:
			if F is _A:raise ValueError(_E.format(B))
			return F
@contextmanager
def _module_to_load(name):
	A=name;C=A in sys.modules;B=sys.modules.get(A)
	if not C:B=type(sys)(A);B.__initializing__=True;sys.modules[A]=B
	try:yield B
	except Exception:
		if not C:
			try:del sys.modules[A]
			except KeyError:pass
	finally:B.__initializing__=False
def set_package(fxn):
	@functools.wraps(fxn)
	def A(*B,**C):
		warnings.warn(_C,DeprecationWarning,stacklevel=2);A=fxn(*B,**C)
		if getattr(A,'__package__',_A)is _A:
			A.__package__=A.__name__
			if not hasattr(A,_F):A.__package__=A.__package__.rpartition(_B)[0]
		return A
	return A
def set_loader(fxn):
	@functools.wraps(fxn)
	def A(self,*B,**C):
		warnings.warn(_C,DeprecationWarning,stacklevel=2);A=fxn(self,*B,**C)
		if getattr(A,'__loader__',_A)is _A:A.__loader__=self
		return A
	return A
def module_for_loader(fxn):
	warnings.warn(_C,DeprecationWarning,stacklevel=2)
	@functools.wraps(fxn)
	def A(self,fullname,*D,**E):
		C=self;A=fullname
		with _module_to_load(A)as B:
			B.__loader__=C
			try:F=C.is_package(A)
			except (ImportError,AttributeError):pass
			else:
				if F:B.__package__=A
				else:B.__package__=A.rpartition(_B)[0]
			return fxn(C,B,*D,**E)
	return A
class _LazyModule(types.ModuleType):
	def __getattribute__(A,attr):
		A.__class__=types.ModuleType;C=A.__spec__.name;E=A.__spec__.loader_state[_G];H=A.__spec__.loader_state[_H];F=A.__dict__;D={}
		for (B,G) in F.items():
			if B not in E:D[B]=G
			elif id(F[B])!=id(E[B]):D[B]=G
		A.__spec__.loader.exec_module(A)
		if C in sys.modules:
			if id(A)!=id(sys.modules[C]):raise ValueError(f"module object for {C!r} substituted in sys.modules during a lazy load")
		A.__dict__.update(D);return getattr(A,attr)
	def __delattr__(A,attr):A.__getattribute__(attr);delattr(A,attr)
class LazyLoader(abc.Loader):
	@staticmethod
	def __check_eager_loader(loader):
		if not hasattr(loader,'exec_module'):raise TypeError('loader must define exec_module()')
	@classmethod
	def factory(A,loader):B=loader;A.__check_eager_loader(B);return lambda *C,**D:A(B(*C,**D))
	def __init__(A,loader):B=loader;A.__check_eager_loader(B);A.loader=B
	def create_module(A,spec):return A.loader.create_module(spec)
	def exec_module(C,module):A=module;A.__spec__.loader=C.loader;A.__loader__=C.loader;B={};B[_G]=A.__dict__.copy();B[_H]=A.__class__;A.__spec__.loader_state=B;A.__class__=_LazyModule